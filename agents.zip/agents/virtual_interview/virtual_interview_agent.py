"""
AI Recruit - Virtual Interview Agent
Specialized AI agent for conducting adaptive virtual interviews with intelligent questioning and assessment.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import json
import os
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Union, Literal
from enum import Enum
import asyncio

from langchain_core.messages import HumanMessage, SystemMessage


class DateTimeEncoder(json.JSONEncoder):
    """Custom JSON encoder to handle datetime objects."""
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from database.session import get_db
from database.models import (
    InterviewSession as DBInterviewSession, 
    InterviewQuestion as DBInterviewQuestion, 
    InterviewResponse as DBInterviewResponse
)
try:
    from crewai import Agent, Task, Crew, Process
except ImportError:
    Agent = Task = Crew = Process = None

try:
    import instructor
except ImportError:
    instructor = None

from core.config import Settings

logger = logging.getLogger(__name__)

# Log import warnings after logger is available
if Agent is None:
    logger.warning("CrewAI not available, some features may be limited")
if instructor is None:
    logger.warning("Instructor not available, falling back to basic LLM responses")


class InterviewStatus(str, Enum):
    """Interview session status enumeration."""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"


class QuestionType(str, Enum):
    """Types of interview questions."""
    TECHNICAL_SKILL = "technical_skill"
    BEHAVIORAL = "behavioral"
    SITUATIONAL = "situational"
    PROBLEM_SOLVING = "problem_solving"
    EXPERIENCE_BASED = "experience_based"
    CULTURAL_FIT = "cultural_fit"
    COMMUNICATION = "communication"
    LEADERSHIP = "leadership"
    FOLLOW_UP = "follow_up"
    CLARIFICATION = "clarification"


class SkillCategory(str, Enum):
    """Skill categories for assessment."""
    TECHNICAL = "technical"
    SOFT_SKILLS = "soft_skills"
    DOMAIN_KNOWLEDGE = "domain_knowledge"
    PROBLEM_SOLVING = "problem_solving"
    COMMUNICATION = "communication"
    LEADERSHIP = "leadership"
    ADAPTABILITY = "adaptability"


class AIInterviewQuestion(BaseModel):
    """Model for AI-generated interview questions with metadata."""
    question_id: str = Field(..., description="Unique identifier for the question")
    question_text: str = Field(..., description="The actual question text")
    question_type: QuestionType = Field(..., description="Type/category of the question")
    skill_focus: List[str] = Field(default_factory=list, description="Skills this question evaluates")
    difficulty_level: Literal["entry", "junior", "mid", "senior", "expert"] = Field(..., description="Difficulty level")
    expected_duration_minutes: int = Field(..., description="expected time to answer")
    follow_up_potential: bool = Field(default=True, description="Whether this question can have follow-ups")
    context: Optional[str] = Field(None, description="Context or background for the question")
    evaluation_criteria: List[str] = Field(default_factory=list, description="What to evaluate in the response")


class AIInterviewResponse(BaseModel):
    """Model for candidate responses in AI processing."""
    response_id: str = Field(..., description="Unique identifier for the response")
    question_id: str = Field(..., description="ID of the question being answered")
    response_text: str = Field(..., description="Candidate's response")
    response_time_seconds: int = Field(..., description="Time taken to respond")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="When response was given")


class SkillAssessment(BaseModel):
    """Assessment of a specific skill based on responses."""
    skill_name: str = Field(..., description="Name of the skill")
    category: SkillCategory = Field(..., description="Skill category")
    proficiency_level: Literal["novice", "beginner", "intermediate", "advanced", "expert"] = Field(..., description="Assessed proficiency level")
    confidence_score: float = Field(..., ge=0, le=1, description="Confidence in assessment")
    evidence: List[str] = Field(default_factory=list, description="Evidence supporting this assessment")
    areas_for_improvement: List[str] = Field(default_factory=list, description="Areas needing improvement")
    strengths: List[str] = Field(default_factory=list, description="Identified strengths")
    questions_evaluated: List[str] = Field(default_factory=list, description="Question IDs used for this assessment")


class InterviewStrategy(BaseModel):
    """Dynamic interview strategy based on ongoing assessment."""
    next_question_type: QuestionType = Field(..., description="Type of next question to ask")
    focus_areas: List[str] = Field(default_factory=list, description="Skills/areas to focus on")
    difficulty_adjustment: Literal["increase", "decrease", "maintain"] = Field(..., description="How to adjust difficulty")
    estimated_remaining_time: int = Field(..., description="Estimated remaining time in minutes")
    questions_remaining: int = Field(..., description="Estimated questions remaining")
    confidence_threshold_met: Dict[str, bool] = Field(default_factory=dict, description="Which skills have met confidence threshold")
    reasoning: str = Field(..., description="Reasoning behind this strategy")


class QuestionGeneration(BaseModel):
    """Generated interview question with context."""
    question: AIInterviewQuestion = Field(..., description="The generated question")
    strategy_reasoning: str = Field(..., description="Why this question was chosen")
    expected_insights: List[str] = Field(default_factory=list, description="What insights this question should provide")
    potential_follow_ups: List[str] = Field(default_factory=list, description="Potential follow-up questions")


class ResponseEvaluation(BaseModel):
    """Evaluation of a candidate's response."""
    response_id: str = Field(..., description="ID of the response being evaluated")
    question_id: str = Field(..., description="ID of the question that was answered")
    
    # Content analysis
    content_quality: float = Field(..., ge=0, le=1, description="Quality of content in response")
    technical_accuracy: float = Field(..., ge=0, le=1, description="Technical accuracy of response")
    completeness: float = Field(..., ge=0, le=1, description="How complete the response is")
    clarity: float = Field(..., ge=0, le=1, description="Clarity of communication")
    
    # Skill indicators
    skills_demonstrated: List[str] = Field(default_factory=list, description="Skills demonstrated in response")
    skill_levels: Dict[str, str] = Field(default_factory=dict, description="Assessed skill levels")
    
    # Insights
    positive_indicators: List[str] = Field(default_factory=list, description="Positive indicators in response")
    concerns: List[str] = Field(default_factory=list, description="Areas of concern")
    follow_up_needed: bool = Field(default=False, description="Whether follow-up questions are needed")
    follow_up_topics: List[str] = Field(default_factory=list, description="Topics for follow-up")
    
    # Overall assessment
    overall_score: float = Field(..., ge=0, le=1, description="Overall response score")
    confidence: float = Field(..., ge=0, le=1, description="Confidence in evaluation")


class InterviewAssessment(BaseModel):
    """Comprehensive final interview assessment."""
    session_id: str = Field(..., description="Interview session ID")
    
    # Overall scores
    overall_score: float = Field(..., ge=0, le=1, description="Overall interview performance")
    technical_competency: float = Field(..., ge=0, le=1, description="Technical competency score")
    communication_skills: float = Field(..., ge=0, le=1, description="Communication skills score")
    problem_solving: float = Field(..., ge=0, le=1, description="Problem solving ability")
    cultural_fit: float = Field(..., ge=0, le=1, description="Cultural fit assessment")
    
    # Detailed assessments
    skill_assessments: List[SkillAssessment] = Field(default_factory=list, description="Detailed skill assessments")
    
    # Recommendations
    hiring_recommendation: Literal["strong_hire", "hire", "maybe", "no_hire", "strong_no_hire"] = Field(..., description="Hiring recommendation")
    confidence_level: float = Field(..., ge=0, le=1, description="Confidence in recommendation")
    
    # Detailed analysis
    strengths: List[str] = Field(default_factory=list, description="Candidate strengths")
    weaknesses: List[str] = Field(default_factory=list, description="Areas for improvement")
    interview_highlights: List[str] = Field(default_factory=list, description="Key highlights from interview")
    concerns: List[str] = Field(default_factory=list, description="Areas of concern")
    
    # Role fit
    role_alignment: float = Field(..., ge=0, le=1, description="How well candidate aligns with role")
    experience_match: float = Field(..., ge=0, le=1, description="Experience match to requirements")
    growth_potential: float = Field(..., ge=0, le=1, description="Assessed growth potential")
    
    # Supporting data
    total_questions_asked: int = Field(..., description="Total questions in interview")
    interview_duration_minutes: int = Field(..., description="Total interview duration")
    response_quality_average: float = Field(..., ge=0, le=1, description="Average response quality")
    
    # Narrative summary
    executive_summary: str = Field(..., description="Executive summary of interview")
    detailed_analysis: str = Field(..., description="Detailed analysis and reasoning")
    next_steps: List[str] = Field(default_factory=list, description="Recommended next steps")


class VirtualInterviewAgent:
    """
    Specialized AI agent for conducting adaptive virtual interviews.
    Uses advanced LLM reasoning to dynamically adjust questioning strategy
    and provide comprehensive candidate assessment.
    """
    
    def __init__(self, llm: BaseChatModel, settings: Settings):
        self.llm = llm
        self.settings = settings
        
        # Configure environment for CrewAI to use correct LLM provider
        self._configure_llm_environment()
        
        # Agent configuration
        self.max_questions = 15  # Maximum questions per interview
        self.target_duration_minutes = 45  # Target interview duration
        self.confidence_threshold = 0.8  # Confidence threshold for skill assessment
        
        # Active interview sessions
        self.active_sessions: Dict[str, Dict] = {}
        
        # CrewAI agents for specialized tasks
        self.question_generation_agent = None
        self.response_evaluation_agent = None
        self.strategy_agent = None
        self.assessment_agent = None
        
        self._initialized = False
    
    def _configure_llm_environment(self):
        """Configure environment variables for CrewAI to use the correct LLM provider."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔧 Configuring CrewAI environment for Virtual Interview Agent: {provider}")
            
            if provider == "azure_openai":
                # Set Azure OpenAI environment variables for CrewAI
                endpoint = config.get("endpoint", "")
                api_key = config.get("api_key", "")
                api_version = config.get("api_version", "2024-02-15-preview")
                deployment_name = config.get("deployment_name", "")
                
                # Set environment variables for Azure OpenAI
                os.environ["OPENAI_API_TYPE"] = "azure"
                os.environ["OPENAI_API_VERSION"] = api_version
                os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint
                os.environ["AZURE_OPENAI_API_KEY"] = api_key
                os.environ["AZURE_API_KEY"] = api_key
                os.environ["OPENAI_API_KEY"] = api_key
                os.environ["AZURE_OPENAI_BASE"] = endpoint
                os.environ["AZURE_API_BASE"] = endpoint
                os.environ["AZURE_OPENAI_RESOURCE"] = endpoint.split("//")[1].split(".")[0] if "//" in endpoint else ""
                os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = deployment_name
                os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment_name
                os.environ["AZURE_OPENAI_API_VERSION"] = api_version
                os.environ["AZURE_OPENAI_CHAT_COMPLETIONS_DEPLOYMENT"] = deployment_name
                os.environ["AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT"] = deployment_name
                
            elif provider == "openai":
                os.environ["OPENAI_API_KEY"] = config["api_key"]
                if "organization" in config:
                    os.environ["OPENAI_ORGANIZATION"] = config["organization"]
                    
            elif provider == "anthropic":
                os.environ["ANTHROPIC_API_KEY"] = config["api_key"]
                
            logger.info("✅ CrewAI environment configured for Virtual Interview Agent")
            
        except Exception as e:
            logger.error(f"❌ Failed to configure CrewAI environment: {str(e)}")
            raise
    
    async def initialize(self):
        """Initialize the Virtual Interview Agent and all sub-agents."""
        try:
            logger.info("🤖 Initializing Virtual Interview Agent")
            
            if Agent is None:
                logger.warning("⚠️ CrewAI not available, using basic LLM mode")
                self._initialized = True
                return
            
            # Initialize specialized agents
            await self._initialize_crew_agents()
            
            self._initialized = True
            logger.info("✅ Virtual Interview Agent initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Virtual Interview Agent: {str(e)}")
            raise
    
    async def _initialize_crew_agents(self):
        """Initialize CrewAI agents for specialized interview tasks."""
        try:
            # Question Generation Agent
            self.question_generation_agent = Agent(
                role='Interview Question Generator',
                goal='Generate contextually appropriate interview questions based on job requirements and candidate profile',
                backstory="""You are an expert interview question generator with deep knowledge of various roles 
                and industries. You create questions that effectively evaluate candidate skills while being fair and relevant.""",
                verbose=True,
                allow_delegation=False
            )
            
            # Response Evaluation Agent
            self.response_evaluation_agent = Agent(
                role='Response Evaluator',
                goal='Analyze and evaluate candidate responses for technical accuracy, communication skills, and role fit',
                backstory="""You are an experienced interviewer and assessor who can quickly identify candidate 
                strengths and weaknesses from their responses. You provide detailed, fair, and actionable evaluations.""",
                verbose=True,
                allow_delegation=False
            )
            
            # Strategy Agent
            self.strategy_agent = Agent(
                role='Interview Strategy Coordinator',
                goal='Determine optimal interview flow and next questions based on ongoing assessment',
                backstory="""You are a strategic interview coordinator who adapts questioning approach based on 
                candidate responses. You ensure comprehensive evaluation while maintaining interview flow.""",
                verbose=True,
                allow_delegation=False
            )
            
            # Assessment Agent
            self.assessment_agent = Agent(
                role='Final Assessment Specialist',
                goal='Provide comprehensive candidate assessment and hiring recommendations',
                backstory="""You are a senior hiring specialist who synthesizes all interview data into actionable 
                hiring recommendations. You consider technical skills, cultural fit, and growth potential.""",
                verbose=True,
                allow_delegation=False
            )
            
            logger.info("✅ CrewAI agents initialized for Virtual Interview Agent")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize CrewAI agents: {str(e)}")
            raise
    
    async def start_interview_session(
        self,
        session_id: str,
        job_requirements: Dict[str, Any],
        candidate_profile: Dict[str, Any],
        interview_config: Optional[Dict[str, Any]] = None
    ) -> QuestionGeneration:
        """
        Start a new virtual interview session.
        
        Args:
            session_id: Unique identifier for the interview session
            job_requirements: Job requirements and skills needed
            candidate_profile: Candidate's resume analysis and profile
            interview_config: Optional configuration for interview parameters
            
        Returns:
            First question to ask the candidate
        """
        try:
            logger.info(f"🚀 Starting virtual interview session: {session_id}")
            
            # Initialize session
            self.active_sessions[session_id] = {
                "status": InterviewStatus.IN_PROGRESS,
                "start_time": datetime.now(timezone.utc),
                "job_requirements": job_requirements,
                "candidate_profile": candidate_profile,
                "config": interview_config or {},
                "questions_asked": [],
                "responses": [],
                "skill_assessments": {},
                "question_count": 0
            }
            
            # Generate initial interview strategy
            strategy = await self._develop_initial_strategy(
                job_requirements, candidate_profile, interview_config
            )
            
            # Generate first question
            first_question = await self._generate_next_question(
                session_id, strategy, is_first_question=True
            )
            
            # Store question in session
            self.active_sessions[session_id]["questions_asked"].append(first_question.question)
            # Ensure question_count exists before incrementing
            if 'question_count' not in self.active_sessions[session_id]:
                self.active_sessions[session_id]['question_count'] = len(self.active_sessions[session_id]["questions_asked"]) - 1
            self.active_sessions[session_id]["question_count"] += 1
            
            logger.info(f"✅ Interview session started with first question")
            
            return first_question
            
        except Exception as e:
            logger.error(f"❌ Failed to start interview session: {str(e)}")
            # Update session status
            if session_id in self.active_sessions:
                self.active_sessions[session_id]["status"] = InterviewStatus.FAILED
            raise
    
    async def submit_response_and_get_next_question(
        self,
        session_id: str,
        response: AIInterviewResponse
    ) -> Optional[QuestionGeneration]:
        """
        Submit a candidate response and get the next question.
        
        Args:
            session_id: Interview session ID
            response: Candidate's response to the previous question
            
        Returns:
            Next question to ask, or None if interview is complete
        """
        try:
            # Check if session is in memory, if not try to load from database
            if session_id not in self.active_sessions:
                logger.info(f"🔍 Session {session_id} not in memory, attempting to load from database")
                session_data = await self._load_session_from_database(session_id)
                if not session_data:
                    raise ValueError(f"Interview session {session_id} not found")
            
            session = self.active_sessions[session_id]
            
            if session["status"] != InterviewStatus.IN_PROGRESS:
                raise ValueError(f"Interview session {session_id} is not in progress")
            
            logger.info(f"📝 Processing response for session: {session_id}")
            
            # Store response
            session["responses"].append(response)
            
            # Evaluate response
            evaluation = await self._evaluate_response(session_id, response)
            
            # Update skill assessments
            await self._update_skill_assessments(session_id, evaluation)
            
            # Determine next strategy
            strategy = await self._update_interview_strategy(session_id)
            
            # Check if interview should continue
            if await self._should_continue_interview(session_id, strategy):
                # Generate next question
                next_question = await self._generate_next_question(session_id, strategy)
                
                # Store question
                session["questions_asked"].append(next_question.question)
                # Ensure question_count exists before incrementing
                if 'question_count' not in session:
                    session['question_count'] = len(session["questions_asked"]) - 1
                session["question_count"] += 1
                
                logger.info(f"✅ Next question generated for session: {session_id}")
                return next_question
            else:
                # Interview is complete
                await self._complete_interview_session(session_id)
                logger.info(f"🏁 Interview session completed: {session_id}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Failed to process response and generate next question: {str(e)}")
            # Update session status
            if session_id in self.active_sessions:
                self.active_sessions[session_id]["status"] = InterviewStatus.FAILED
            raise
    
    async def _load_session_from_database(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Load interview session data from database and populate in-memory session.
        
        Args:
            session_id: Interview session ID to load
            
        Returns:
            Session data dictionary or None if not found
        """
        try:
            logger.info(f"💾 Loading session {session_id} from database")
            
            # Get database session
            async for db in get_db():
                try:
                    # Load interview session
                    session_query = select(DBInterviewSession).where(
                        DBInterviewSession.session_id == session_id
                    )
                    session_result = await db.execute(session_query)
                    db_session = session_result.scalar_one_or_none()
                    
                    if not db_session:
                        logger.warning(f"⚠️ Interview session {session_id} not found in database")
                        return None
                    
                    # Load questions for this session
                    questions_query = select(DBInterviewQuestion).where(
                        DBInterviewQuestion.session_id == db_session.id
                    ).order_by(DBInterviewQuestion.question_sequence)
                    questions_result = await db.execute(questions_query)
                    db_questions = questions_result.scalars().all()
                    
                    # Load responses for this session
                    responses_query = select(DBInterviewResponse).where(
                        DBInterviewResponse.session_id == db_session.id
                    ).order_by(DBInterviewResponse.created_at)
                    responses_result = await db.execute(responses_query)
                    db_responses = responses_result.scalars().all()
                    
                    # Convert to in-memory format
                    questions_asked = []
                    responses = []
                    
                    for q in db_questions:
                        questions_asked.append({
                            "question_id": q.question_id,
                            "question_text": q.question_text,
                            "question_type": q.question_type,
                            "difficulty_level": q.difficulty_level,
                            "skill_focus": q.skill_focus,
                            "sequence": q.question_sequence
                        })
                    
                    for r in db_responses:
                        responses.append({
                            "response_text": r.response_text,
                            "response_time_seconds": r.response_time_seconds,
                            "evaluation_score": getattr(r, 'overall_score', None),
                            "skill_demonstration": getattr(r, 'skills_demonstrated', []),
                            "created_at": r.created_at.isoformat() if r.created_at else None
                        })
                    
                    # Reconstruct session data
                    session_data = {
                        "status": InterviewStatus(db_session.status),
                        "start_time": db_session.started_at or db_session.created_at,
                        "job_requirements": {},  # Will be loaded separately if needed
                        "candidate_profile": {},  # Will be loaded separately if needed
                        "config": db_session.interview_config or {},
                        "questions_asked": questions_asked,
                        "responses": responses,
                        "question_count": len(questions_asked),  # Required for question generation
                        "current_question_sequence": len(questions_asked),
                        "total_questions": db_session.max_questions,
                        "skills_covered": set(),
                        "skill_assessments": {},
                        "difficulty_progression": "adaptive",
                        "performance_metrics": {
                            "total_score": 0.0,
                            "skill_scores": {},
                            "response_times": [r.get("response_time_seconds", 0) for r in responses],
                            "consistency": 0.0
                        }
                    }
                    
                    # Store in active sessions
                    self.active_sessions[session_id] = session_data
                    
                    logger.info(f"✅ Successfully loaded session {session_id} from database")
                    return session_data
                    
                finally:
                    await db.close()
                    
        except Exception as e:
            logger.error(f"❌ Failed to load session {session_id} from database: {str(e)}")
            return None
    
    async def complete_interview(self, session_id: str) -> InterviewAssessment:
        """
        Complete the interview and generate final assessment.
        
        Args:
            session_id: Interview session ID
            
        Returns:
            Comprehensive interview assessment
        """
        try:
            # Check if session is in memory, if not try to load from database
            if session_id not in self.active_sessions:
                logger.info(f"🔍 Session {session_id} not in memory, attempting to load from database")
                session_data = await self._load_session_from_database(session_id)
                if not session_data:
                    raise ValueError(f"Interview session {session_id} not found")
            
            logger.info(f"🎯 Completing interview and generating assessment: {session_id}")
            
            # Mark session as completed
            session = self.active_sessions[session_id]
            session["status"] = InterviewStatus.COMPLETED
            session["end_time"] = datetime.now(timezone.utc)
            
            # Generate comprehensive assessment
            assessment = await self._generate_final_assessment(session_id)
            
            # Store assessment in session
            session["final_assessment"] = assessment
            
            logger.info(f"✅ Interview assessment completed: {session_id}")
            
            return assessment
            
        except Exception as e:
            logger.error(f"❌ Failed to complete interview assessment: {str(e)}")
            # Update session status
            if session_id in self.active_sessions:
                self.active_sessions[session_id]["status"] = InterviewStatus.FAILED
            raise
    
    async def _develop_initial_strategy(
        self,
        job_requirements: Dict[str, Any],
        candidate_profile: Dict[str, Any],
        interview_config: Optional[Dict[str, Any]] = None
    ) -> InterviewStrategy:
        """Develop initial interview strategy based on job and candidate."""
        try:
            # Create strategy prompt
            strategy_prompt = ChatPromptTemplate.from_messages([
                ("system", """You are an expert interview strategist. Based on the job requirements and candidate profile,
                develop an optimal interview strategy that will comprehensively evaluate the candidate's fit for the role.
                
                Focus on:
                1. Key skills and competencies to evaluate
                2. Appropriate question types and difficulty levels
                3. Time allocation and pacing
                4. Areas that need special attention based on candidate background
                
                Provide a structured strategy that balances technical evaluation with soft skills assessment."""),
                ("human", """Job Requirements:
                {job_requirements}
                
                Candidate Profile:
                {candidate_profile}
                
                Interview Configuration:
                {interview_config}
                
                Develop an initial interview strategy.""")
            ])
            
            # Use LLM to generate strategy
            messages = strategy_prompt.format_messages(
                job_requirements=json.dumps(job_requirements, indent=2, cls=DateTimeEncoder),
                candidate_profile=json.dumps(candidate_profile, indent=2, cls=DateTimeEncoder),
                interview_config=json.dumps(interview_config or {}, indent=2, cls=DateTimeEncoder)
            )
            
            response = await self.llm.ainvoke(messages)
            
            # Parse response into strategy (simplified for now)
            # In production, would use instructor or structured output parsing
            strategy = InterviewStrategy(
                next_question_type=QuestionType.TECHNICAL_SKILL,
                focus_areas=["technical_skills", "problem_solving", "communication"],
                difficulty_adjustment="maintain",
                estimated_remaining_time=self.target_duration_minutes,
                questions_remaining=self.max_questions,
                confidence_threshold_met={},
                reasoning="Initial strategy based on job requirements and candidate profile"
            )
            
            return strategy
            
        except Exception as e:
            logger.error(f"❌ Failed to develop initial strategy: {str(e)}")
            raise
    
    async def _generate_next_question(
        self,
        session_id: str,
        strategy: InterviewStrategy,
        is_first_question: bool = False
    ) -> QuestionGeneration:
        """Generate the next interview question based on strategy."""
        try:
            session = self.active_sessions[session_id]
            
            # Create question generation prompt
            question_prompt = ChatPromptTemplate.from_messages([
                ("system", """You are an expert interview question generator. Generate a contextually appropriate 
                interview question based on the current strategy, job requirements, candidate profile, and interview history.
                
                The question should:
                1. Align with the specified question type and focus areas
                2. Be appropriate for the candidate's experience level
                3. Build on previous questions and responses
                4. Effectively evaluate the target skills
                5. Be clear, fair, and engaging
                
                Consider the interview flow and ensure natural progression.
                
                IMPORTANT: Provide your response in the following JSON format:
                {
                    "question": "The actual interview question to ask the candidate",
                    "reasoning": "Brief explanation of why this question is appropriate",
                    "focus_skills": ["skill1", "skill2"],
                    "difficulty": "entry|junior|mid|senior|expert",
                    "expected_duration": 3
                }"""),
                ("human", """Current Strategy:
                {strategy}
                
                Job Requirements:
                {job_requirements}
                
                Candidate Profile:
                {candidate_profile}
                
                Previous Questions:
                {previous_questions}
                
                Previous Responses:
                {previous_responses}
                
                Is First Question: {is_first_question}
                
                Generate the next interview question in the specified JSON format.""")
            ])
            
            # Format prompt
            messages = question_prompt.format_messages(
                strategy=strategy.model_dump_json(indent=2) if hasattr(strategy, 'model_dump_json') else json.dumps(strategy, indent=2, cls=DateTimeEncoder),
                job_requirements=json.dumps(session["job_requirements"], indent=2, cls=DateTimeEncoder),
                candidate_profile=json.dumps(session["candidate_profile"], indent=2, cls=DateTimeEncoder),
                previous_questions=json.dumps([q.model_dump() if hasattr(q, 'model_dump') else q for q in session["questions_asked"]], indent=2, cls=DateTimeEncoder),
                previous_responses=json.dumps([r.model_dump() if hasattr(r, 'model_dump') else r for r in session["responses"]], indent=2, cls=DateTimeEncoder),
                is_first_question=is_first_question
            )
            
            # Generate question using LLM
            response = await self.llm.ainvoke(messages)
            
            # Parse structured JSON response
            question_data = None
            
            # Ensure question_count exists (safety check)
            if 'question_count' not in session:
                session['question_count'] = len(session.get('questions_asked', []))
            
            question_id = f"{session_id}_q_{session['question_count'] + 1}"
            
            try:
                # Extract JSON from response content with robust parsing
                content = response.content.strip()
                logger.info(f"🔍 Processing LLM response for session {session_id}")
                logger.debug(f"🔍 Raw LLM response: {content[:500]}...")
                
                # Try multiple extraction methods
                json_content = None
                
                # Method 1: Look for JSON code blocks
                if '```json' in content:
                    start = content.find('```json') + 7
                    end = content.find('```', start)
                    if end > start:
                        json_content = content[start:end].strip()
                
                # Method 2: Look for any code blocks
                elif content.count('```') >= 2:
                    parts = content.split('```')
                    if len(parts) >= 3:
                        json_content = parts[1].strip()
                
                # Method 3: Look for JSON object directly
                elif content.strip().startswith('{') and content.strip().endswith('}'):
                    json_content = content.strip()
                
                # Method 4: Try to find JSON within the text
                else:
                    # Look for { and } boundaries
                    start = content.find('{')
                    end = content.rfind('}')
                    if start != -1 and end != -1 and end > start:
                        json_content = content[start:end+1]
                
                if json_content:
                    logger.debug(f"🔍 Extracted JSON content: {json_content[:200]}...")
                    question_data = json.loads(json_content)
                    logger.info(f"✅ Successfully parsed JSON response")
                else:
                    raise json.JSONDecodeError("No valid JSON found in response", content, 0)
                
            except (json.JSONDecodeError, ValueError, IndexError, KeyError) as e:
                logger.warning(f"⚠️ Failed to parse JSON response: {str(e)}")
                logger.debug(f"🔍 Full response content: {response.content}")
                question_data = None
            except Exception as e:
                logger.error(f"❌ Unexpected error during JSON parsing: {str(e)}")
                logger.debug(f"🔍 Full response content: {response.content}")
                question_data = None
            
            # Create question object with extracted data or fallbacks
            if question_data and isinstance(question_data, dict):
                question = AIInterviewQuestion(
                    question_id=question_id,
                    question_text=question_data.get('question', self._extract_question_from_text(response.content)),
                    question_type=strategy.next_question_type,
                    skill_focus=question_data.get('focus_skills', strategy.focus_areas),
                    difficulty_level=question_data.get('difficulty', 'mid'),
                    expected_duration_minutes=question_data.get('expected_duration', 3),
                    evaluation_criteria=["technical_accuracy", "communication", "problem_solving"]
                )
                logger.info(f"✅ Generated structured question: {question_data.get('question', 'N/A')[:100]}...")
            else:
                # Fallback to intelligent text extraction
                question_text = self._extract_question_from_text(response.content)
                question = AIInterviewQuestion(
                    question_id=question_id,
                    question_text=question_text,
                    question_type=strategy.next_question_type,
                    skill_focus=strategy.focus_areas,
                    difficulty_level="mid",
                    expected_duration_minutes=3,
                    evaluation_criteria=["technical_accuracy", "communication", "problem_solving"]
                )
                logger.info(f"✅ Generated fallback question: {question_text[:100]}...")
            
            question_generation = QuestionGeneration(
                question=question,
                strategy_reasoning=f"Generated based on strategy: {strategy.reasoning}",
                expected_insights=["Technical competency", "Problem-solving approach"],
                potential_follow_ups=["Can you elaborate on that approach?", "What alternatives did you consider?"]
            )
            
            return question_generation
            
        except Exception as e:
            logger.error(f"❌ Failed to generate next question: {str(e)}")
            raise
    
    def _extract_question_from_text(self, content: str) -> str:
        """
        Extract a well-formed question from unstructured text content.
        
        Args:
            content: Raw text content from LLM response
            
        Returns:
            Extracted question text
        """
        try:
            content = content.strip()
            
            # Method 1: Look for question-like sentences ending with ?
            sentences = content.replace('\n', ' ').split('.')
            for sentence in sentences:
                sentence = sentence.strip()
                if '?' in sentence:
                    # Extract the part ending with ?
                    question_parts = sentence.split('?')
                    for part in question_parts:
                        part = part.strip()
                        if part and len(part) > 10:  # Reasonable question length
                            return part + '?'
            
            # Method 2: Look for lines that start with question words
            question_starters = ['what', 'how', 'why', 'when', 'where', 'which', 'who', 'can you', 'could you', 'would you', 'do you', 'have you', 'are you', 'will you']
            lines = content.split('\n')
            for line in lines:
                line = line.strip().lower()
                if any(line.startswith(starter) for starter in question_starters):
                    # Return the original case version
                    original_line = [l.strip() for l in content.split('\n') if l.strip().lower() == line]
                    if original_line:
                        question = original_line[0]
                        if not question.endswith('?'):
                            question += '?'
                        return question
            
            # Method 3: Look for imperative statements that can be questions
            imperative_starters = ['describe', 'explain', 'tell me', 'walk me through', 'discuss', 'outline']
            for line in lines:
                line_lower = line.strip().lower()
                if any(line_lower.startswith(starter) for starter in imperative_starters):
                    question = line.strip()
                    if not question.endswith('?'):
                        question += '?'
                    return question
            
            # Method 4: Fallback - take first substantial sentence
            sentences = content.split('.')
            for sentence in sentences:
                sentence = sentence.strip()
                if len(sentence) > 20 and not sentence.lower().startswith(('the ', 'this ', 'based on')):
                    if not sentence.endswith('?'):
                        sentence += '?'
                    return sentence
            
            # Final fallback
            return content[:500] + ('?' if not content.endswith('?') else '')
            
        except Exception as e:
            logger.warning(f"⚠️ Error extracting question from text: {str(e)}")
            return content[:200] + '?'
    
    async def _evaluate_response(
        self,
        session_id: str,
        response: AIInterviewResponse
    ) -> ResponseEvaluation:
        """Evaluate a candidate's response comprehensively."""
        try:
            session = self.active_sessions[session_id]
            
            # Find the corresponding question
            question = None
            for q in session["questions_asked"]:
                if q["question_id"] == response.question_id:
                    question = q
                    break
            
            if not question:
                raise ValueError(f"Question {response.question_id} not found in session")
            
            # Create evaluation prompt
            eval_prompt = ChatPromptTemplate.from_messages([
                ("system", """You are an expert interview response evaluator. Analyze the candidate's response 
                comprehensively across multiple dimensions:
                
                1. Technical accuracy and depth
                2. Communication clarity and structure
                3. Problem-solving approach
                4. Relevant experience demonstration
                5. Completeness of answer
                6. Areas for follow-up
                
                Provide detailed, fair, and actionable evaluation."""),
                ("human", """Question:
                {question}
                
                Candidate Response:
                {response}
                
                Job Requirements Context:
                {job_requirements}
                
                Candidate Profile Context:
                {candidate_profile}
                
                Response Time: {response_time} seconds
                
                Evaluate this response comprehensively.""")
            ])
            
            # Format and invoke
            messages = eval_prompt.format_messages(
                question=question.model_dump_json(indent=2) if hasattr(question, 'model_dump_json') else json.dumps(question, indent=2, cls=DateTimeEncoder),
                response=response.response_text,
                job_requirements=json.dumps(session["job_requirements"], indent=2, cls=DateTimeEncoder),
                candidate_profile=json.dumps(session["candidate_profile"], indent=2, cls=DateTimeEncoder),
                response_time=response.response_time_seconds
            )
            
            llm_response = await self.llm.ainvoke(messages)
            
            # Parse evaluation (simplified for now)
            evaluation = ResponseEvaluation(
                response_id=response.response_id,
                question_id=response.question_id,
                content_quality=0.75,  # Would be extracted from LLM response
                technical_accuracy=0.8,
                completeness=0.7,
                clarity=0.85,
                skills_demonstrated=["problem_solving", "communication"],
                skill_levels={"problem_solving": "intermediate", "communication": "good"},
                positive_indicators=["Clear explanation", "Logical approach"],
                concerns=["Could provide more specific examples"],
                follow_up_needed=True,
                follow_up_topics=["specific examples", "alternative approaches"],
                overall_score=0.77,
                confidence=0.8
            )
            
            return evaluation
            
        except Exception as e:
            logger.error(f"❌ Failed to evaluate response: {str(e)}")
            raise
    
    async def _update_skill_assessments(
        self,
        session_id: str,
        evaluation: ResponseEvaluation
    ):
        """Update ongoing skill assessments based on new evaluation."""
        try:
            session = self.active_sessions[session_id]
            
            # Update skill assessments based on evaluation
            for skill in evaluation.skills_demonstrated:
                if skill not in session["skill_assessments"]:
                    session["skill_assessments"][skill] = {
                        "skill_name": skill,
                        "category": SkillCategory.TECHNICAL,  # Would be determined dynamically
                        "proficiency_level": "intermediate",
                        "confidence_score": 0.5,
                        "evidence": [],
                        "questions_evaluated": []
                    }
                
                # Update assessment
                assessment = session["skill_assessments"][skill]
                assessment["evidence"].append(f"Response to {evaluation.question_id}: {evaluation.overall_score}")
                assessment["questions_evaluated"].append(evaluation.question_id)
                
                # Update confidence (simplified logic)
                assessment["confidence_score"] = min(1.0, assessment["confidence_score"] + 0.1)
            
        except Exception as e:
            logger.error(f"❌ Failed to update skill assessments: {str(e)}")
            raise
    
    async def _update_interview_strategy(
        self,
        session_id: str
    ) -> InterviewStrategy:
        """Update interview strategy based on current assessment."""
        try:
            session = self.active_sessions[session_id]
            
            # Analyze current state and adjust strategy
            questions_asked = len(session["questions_asked"])
            remaining_questions = self.max_questions - questions_asked
            
            # Determine next focus areas based on assessments
            assessed_skills = set(session["skill_assessments"].keys())
            required_skills = set(session["job_requirements"].get("skills", []))
            unassessed_skills = required_skills - assessed_skills
            
            # Create updated strategy
            if unassessed_skills:
                next_type = QuestionType.TECHNICAL_SKILL
                focus_areas = list(unassessed_skills)[:3]
            else:
                next_type = QuestionType.BEHAVIORAL
                focus_areas = ["communication", "cultural_fit"]
            
            strategy = InterviewStrategy(
                next_question_type=next_type,
                focus_areas=focus_areas,
                difficulty_adjustment="maintain",
                estimated_remaining_time=remaining_questions * 3,
                questions_remaining=remaining_questions,
                confidence_threshold_met={
                    skill: assessment["confidence_score"] >= self.confidence_threshold
                    for skill, assessment in session["skill_assessments"].items()
                },
                reasoning=f"Adapting strategy based on {questions_asked} questions asked"
            )
            
            return strategy
            
        except Exception as e:
            logger.error(f"❌ Failed to update interview strategy: {str(e)}")
            raise
    
    async def _should_continue_interview(
        self,
        session_id: str,
        strategy: InterviewStrategy
    ) -> bool:
        """Determine if interview should continue."""
        try:
            session = self.active_sessions[session_id]
            
            # Check various continuation criteria
            questions_asked = len(session["questions_asked"])
            
            # Hard limits
            if questions_asked >= self.max_questions:
                return False
            
            # Time limit
            if session["start_time"]:
                now = datetime.now(timezone.utc) if session["start_time"].tzinfo else datetime.utcnow()
                duration = (now - session["start_time"]).total_seconds() / 60
                if duration >= self.target_duration_minutes:
                    return False
            
            # Confidence thresholds
            confidence_met = sum(strategy.confidence_threshold_met.values())
            total_skills = len(session["job_requirements"].get("skills", []))
            
            # Continue if we haven't met confidence threshold for key skills
            if confidence_met < total_skills * 0.7:  # 70% of skills should be assessed
                return True
            
            # Continue if we have very few questions asked
            if questions_asked < 5:
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Failed to determine if interview should continue: {str(e)}")
            return False
    
    async def _complete_interview_session(self, session_id: str):
        """Mark interview session as completed."""
        try:
            session = self.active_sessions[session_id]
            session["status"] = InterviewStatus.COMPLETED
            session["end_time"] = datetime.now(timezone.utc)
            
        except Exception as e:
            logger.error(f"❌ Failed to complete interview session: {str(e)}")
            raise
    
    async def _generate_final_assessment(
        self,
        session_id: str
    ) -> InterviewAssessment:
        """Generate comprehensive final assessment."""
        try:
            session = self.active_sessions[session_id]
            
            # Calculate duration
            duration = 0
            if session.get("start_time") and session.get("end_time"):
                duration = (session["end_time"] - session["start_time"]).total_seconds() / 60
            
            # Convert skill assessments to structured format
            skill_assessments = []
            for skill_name, assessment_data in session["skill_assessments"].items():
                skill_assessment = SkillAssessment(
                    skill_name=skill_name,
                    category=SkillCategory.TECHNICAL,  # Would be determined dynamically
                    proficiency_level="intermediate",  # Would be calculated from evidence
                    confidence_score=assessment_data["confidence_score"],
                    evidence=assessment_data["evidence"],
                    areas_for_improvement=["Provide more specific examples"],
                    strengths=["Clear communication", "Logical thinking"],
                    questions_evaluated=assessment_data["questions_evaluated"]
                )
                skill_assessments.append(skill_assessment)
            
            # Calculate average response quality
            avg_response_quality = 0.75  # Would be calculated from actual evaluations
            
            # Generate assessment
            assessment = InterviewAssessment(
                session_id=session_id,
                overall_score=0.78,
                technical_competency=0.75,
                communication_skills=0.85,
                problem_solving=0.72,
                cultural_fit=0.80,
                skill_assessments=skill_assessments,
                hiring_recommendation="hire",
                confidence_level=0.82,
                strengths=[
                    "Strong communication skills",
                    "Good problem-solving approach",
                    "Relevant experience"
                ],
                weaknesses=[
                    "Could provide more specific examples",
                    "Some technical concepts need strengthening"
                ],
                interview_highlights=[
                    "Excellent explanation of previous project",
                    "Thoughtful approach to problem-solving",
                    "Good cultural fit indicators"
                ],
                concerns=[
                    "Limited experience with specific technology stack",
                    "May need additional training in advanced concepts"
                ],
                role_alignment=0.78,
                experience_match=0.72,
                growth_potential=0.85,
                total_questions_asked=len(session["questions_asked"]),
                interview_duration_minutes=int(duration),
                response_quality_average=avg_response_quality,
                executive_summary="Strong candidate with good communication skills and problem-solving ability. Some technical areas need development but shows good growth potential.",
                detailed_analysis="The candidate demonstrated solid understanding of core concepts with clear communication throughout the interview. While there are some areas for technical improvement, the overall performance indicates good potential for success in the role with appropriate support and development opportunities.",
                next_steps=[
                    "Proceed to technical deep-dive interview",
                    "Check references for project experience",
                    "Discuss development and training plan"
                ]
            )
            
            return assessment
            
        except Exception as e:
            logger.error(f"❌ Failed to generate final assessment: {str(e)}")
            raise
    
    async def get_session_status(self, session_id: str) -> Dict[str, Any]:
        """Get current status of an interview session."""
        # Check if session is in memory, if not try to load from database
        if session_id not in self.active_sessions:
            logger.info(f"🔍 Session {session_id} not in memory, attempting to load from database")
            session_data = await self._load_session_from_database(session_id)
            if not session_data:
                raise ValueError(f"Interview session {session_id} not found")
        
        session = self.active_sessions[session_id]
        
        return {
            "session_id": session_id,
            "status": session["status"],
            "questions_asked": len(session["questions_asked"]),
            "responses_received": len(session["responses"]),
            "skills_assessed": len(session["skill_assessments"]),
            "start_time": session.get("start_time"),
            "estimated_completion": session.get("estimated_completion")
        }
    
    async def cancel_interview_session(self, session_id: str):
        """Cancel an active interview session."""
        # Check if session is in memory, if not try to load from database
        if session_id not in self.active_sessions:
            logger.info(f"🔍 Session {session_id} not in memory, attempting to load from database")
            session_data = await self._load_session_from_database(session_id)
            if not session_data:
                raise ValueError(f"Interview session {session_id} not found")
        
        session = self.active_sessions[session_id]
        session["status"] = InterviewStatus.CANCELLED
        session["end_time"] = datetime.utcnow()
        
        logger.info(f"Interview session cancelled: {session_id}")
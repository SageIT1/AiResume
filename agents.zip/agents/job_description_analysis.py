"""
AI Recruit - Job Description Analysis Agent
Specialized AI agent for comprehensive job description analysis and requirement extraction.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import re
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
import asyncio
import json

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field
# CrewAI removed - using direct LLM approach for efficiency
import instructor

from core.config import Settings

logger = logging.getLogger(__name__)


class UnifiedJobAnalysis(BaseModel):
    """Unified analysis result containing both skills and experience assessment."""
    skills_analysis: str = Field(..., description="Comprehensive skills analysis with technical skills, soft skills, tools, competencies, supporting evidence, and suggestions")
    experience_assessment: str = Field(..., description="Detailed experience and expertise requirements with supporting evidence and suggestions")


class JobBasicInfo(BaseModel):
    """Basic job information extracted from job description."""
    title: str = Field(..., description="Job title/position")
    department: Optional[str] = Field(None, description="Department or team")
    location: Optional[str] = Field(None, description="Job location")
    employment_type: Optional[str] = Field(None, description="Employment type (full-time, part-time, contract, etc.)")
    remote_option: Optional[str] = Field(None, description="Remote work options (on-site, hybrid, full)")
    company_size: Optional[str] = Field(None, description="Company size if mentioned")
    industry: Optional[str] = Field(None, description="Industry if mentioned")
    description: Optional[str] = Field(None, description="Clean job description content (without company info, benefits, etc.)")


class JobRequirement(BaseModel):
    """Job requirement with importance level."""
    requirement: str = Field(..., description="Specific requirement")
    category: str = Field(..., description="Category (technical, soft skill, experience, education, etc.)")
    importance: str = Field(..., description="Importance level (required, preferred, nice-to-have)")
    years_required: Optional[int] = Field(None, description="Years of experience required for this requirement")


class SkillRequirement(BaseModel):
    """Skill requirement with proficiency and importance."""
    skill: str = Field(..., description="Skill name")
    category: str = Field(..., description="Skill category (programming, framework, tool, soft skill, etc.)")
    proficiency_level: Optional[str] = Field(None, description="Required proficiency level")
    importance: str = Field(..., description="Importance (required, preferred, nice-to-have)")
    years_required: Optional[int] = Field(None, description="Years of experience required")
    context: Optional[str] = Field(None, description="Context in which skill is mentioned")


class ExperienceRequirement(BaseModel):
    """Experience requirements analysis."""
    min_years_total: Optional[int] = Field(None, description="Minimum years of total experience")
    max_years_total: Optional[int] = Field(None, description="Maximum years of total experience")
    specific_experience_areas: List[str] = Field(default_factory=list, description="Specific areas of experience required")
    leadership_required: bool = Field(False, description="Leadership experience required")
    industry_experience: Optional[str] = Field(None, description="Specific industry experience required")
    company_size_experience: Optional[str] = Field(None, description="Experience with specific company sizes")


class EducationRequirement(BaseModel):
    """Education requirements analysis."""
    degree_level: Optional[str] = Field(None, description="Required degree level (high school, bachelor's, master's, phd)")
    field_of_study: List[str] = Field(default_factory=list, description="Preferred fields of study")
    certifications: List[str] = Field(default_factory=list, description="Required or preferred certifications")
    alternative_experience: bool = Field(False, description="Whether equivalent experience can substitute education")


class CompensationInfo(BaseModel):
    """Compensation and benefits information."""
    salary_min: Optional[int] = Field(None, description="Minimum salary")
    salary_max: Optional[int] = Field(None, description="Maximum salary")
    currency: Optional[str] = Field(None, description="Currency")
    equity_mentioned: bool = Field(False, description="Equity or stock options mentioned")
    benefits: List[str] = Field(default_factory=list, description="Benefits mentioned")
    bonus_structure: Optional[str] = Field(None, description="Bonus structure if mentioned")


class JobAnalysisInsights(BaseModel):
    """AI-generated insights about the job."""
    complexity_score: float = Field(..., description="Job complexity score (0-1)")
    competitiveness_score: float = Field(..., description="How competitive/demanding the role is (0-1)")
    clarity_score: float = Field(..., description="How clear and well-written the job description is (0-1)")
    inclusivity_score: float = Field(..., description="How inclusive the job description is (0-1)")
    market_demand_level: str = Field(..., description="Market demand for this type of role (low, medium, high)")
    estimated_candidate_pool: str = Field(..., description="Estimated size of qualified candidate pool")
    key_selling_points: List[str] = Field(default_factory=list, description="Key selling points of the role")
    potential_red_flags: List[str] = Field(default_factory=list, description="Potential issues or red flags")


class MatchingCriteria(BaseModel):
    """AI-generated matching criteria for candidate evaluation."""
    skill_weights: Dict[str, float] = Field(default_factory=dict, description="Weights for different skills")
    experience_weight: float = Field(0.3, description="Weight for experience matching")
    education_weight: float = Field(0.1, description="Weight for education matching")
    location_weight: float = Field(0.1, description="Weight for location matching")
    minimum_match_threshold: float = Field(0.6, description="Minimum overall match score for consideration")
    deal_breakers: List[str] = Field(default_factory=list, description="Absolute requirements that cannot be compromised")
    nice_to_haves: List[str] = Field(default_factory=list, description="Preferred but not required qualifications")


class JobDescriptionAnalysisResult(BaseModel):
    """Complete job description analysis result."""
    basic_info: JobBasicInfo
    requirements: List[JobRequirement]
    skills: List[SkillRequirement]
    experience_requirements: ExperienceRequirement
    education_requirements: EducationRequirement
    compensation_info: CompensationInfo
    
    # AI-generated insights
    analysis_insights: JobAnalysisInsights
    matching_criteria: MatchingCriteria
    
    # Extracted content
    responsibilities: List[str] = Field(default_factory=list, description="Key responsibilities")
    benefits: List[str] = Field(default_factory=list, description="Benefits and perks")
    company_culture: List[str] = Field(default_factory=list, description="Company culture indicators")
    growth_opportunities: List[str] = Field(default_factory=list, description="Growth and development opportunities")
    
    # Technical metadata
    confidence_score: float = Field(..., description="Overall confidence in analysis (0-1)")
    processing_time_seconds: float = Field(..., description="Time taken for analysis")
    extracted_text_length: int = Field(..., description="Length of analyzed text")
    
    # Quality indicators
    completeness_score: float = Field(..., description="Job description completeness score (0-1)")
    clarity_score: float = Field(..., description="Job description clarity score (0-1)")
    attractiveness_score: float = Field(..., description="How attractive the job posting is (0-1)")


class JobDescriptionAnalysisAgent:
    """
    Specialized AI agent for comprehensive job description analysis.
    Uses multiple LLM calls with different specializations for maximum accuracy.
    """
    
    def __init__(self, llm: BaseChatModel, settings: Settings):
        self.llm = llm
        self.settings = settings
        
        # Configure environment for CrewAI to use correct LLM provider
        self._configure_llm_environment()
        
        # Initialize instructor for structured outputs
        # TODO: Implement proper instructor integration when needed
        self.instructor_client = None
        logger.warning("Instructor client not initialized - using mock mode for development")
        
        # Agent crew for specialized analysis
        self.analysis_crew = None
        self._initialized = False
    
    def _configure_llm_environment(self):
        """Configure environment variables for CrewAI to use the correct LLM provider."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔧 Configuring CrewAI environment for provider: {provider}")
            
            if provider == "azure_openai":
                # Set Azure OpenAI environment variables for CrewAI
                endpoint = config.get("endpoint", "")
                api_key = config.get("api_key", "")
                api_version = config.get("api_version", "2024-02-15-preview")
                deployment_name = config.get("deployment_name", "")
                
                logger.info(f"🔧 Setting Azure OpenAI environment variables:")
                logger.info(f"   Endpoint: {endpoint}")
                logger.info(f"   API Key: {'***' + api_key[-4:] if api_key else 'NOT SET'}")
                logger.info(f"   API Version: {api_version}")
                logger.info(f"   Deployment: {deployment_name}")
                
                # Set environment variables for Azure OpenAI
                os.environ["OPENAI_API_TYPE"] = "azure"
                os.environ["OPENAI_API_VERSION"] = api_version
                os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint
                os.environ["AZURE_OPENAI_API_KEY"] = api_key
                os.environ["AZURE_API_KEY"] = api_key
                os.environ["OPENAI_API_KEY"] = api_key  # CrewAI might check this
                os.environ["AZURE_OPENAI_BASE"] = endpoint  # Some libraries expect this
                os.environ["AZURE_API_BASE"] = endpoint
                os.environ["OPENAI_API_BASE"] = endpoint  # Alternative naming
                os.environ["OPENAI_BASE_URL"] = endpoint  # Some libs expect this
                os.environ["AZURE_OPENAI_RESOURCE"] = endpoint.split("//")[1].split(".")[0] if "//" in endpoint else ""
                
                # Deployment name for Azure - use actual model name, not deployment
                if deployment_name:
                    os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = deployment_name
                    os.environ["OPENAI_MODEL_NAME"] = "gpt-4.1"  # Use valid Azure OpenAI model name
                    os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment_name  # Alternative naming
                    os.environ["OPENAI_DEPLOYMENT_NAME"] = deployment_name  # Alternative naming
                    
                # Additional Azure OpenAI specific environment variables for LiteLLM
                os.environ["AZURE_OPENAI_CHAT_COMPLETIONS_DEPLOYMENT"] = deployment_name
                os.environ["AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT"] = deployment_name
                os.environ["LITELLM_LOG"] = "DEBUG"  # Enable debug logging for LiteLLM
                
                # Disable LangSmith tracing to avoid 403 errors
                os.environ["LANGCHAIN_TRACING_V2"] = "false"
                os.environ.pop("LANGSMITH_API_KEY", None)
                
                # Remove any OpenAI-specific environment variables that might conflict
                openai_vars_to_remove = ["OPENAI_ORGANIZATION"]
                for var in openai_vars_to_remove:
                    os.environ.pop(var, None)
                
                logger.info(f"✅ Azure OpenAI environment configured - Endpoint: {config.get('endpoint', 'Not Set')}")
                logger.info(f"   Deployment: {deployment_name}")
                logger.info(f"   API Version: {config.get('api_version', '2024-02-15-preview')}")
                
            elif provider == "openai":
                # Standard OpenAI configuration
                if config.get("api_key"):
                    os.environ["OPENAI_API_KEY"] = config["api_key"]
                if config.get("organization"):
                    os.environ["OPENAI_ORGANIZATION"] = config["organization"]
                
                # Remove Azure-specific variables if they exist
                azure_vars = ["OPENAI_API_TYPE", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT_NAME"]
                for var in azure_vars:
                    os.environ.pop(var, None)
                
                logger.info("✅ OpenAI environment configured")
                
            elif provider == "anthropic":
                if config.get("api_key"):
                    os.environ["ANTHROPIC_API_KEY"] = config["api_key"]
                logger.info("✅ Anthropic environment configured")
                
            # Log current provider configuration for debugging
            logger.info(f"🔍 Active LLM Provider: {provider}")
            logger.info(f"🔍 LLM Model: {config.get('model', 'Not specified')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to configure LLM environment: {str(e)}")
            
    def _verify_llm_configuration(self):
        """Verify that the LLM configuration is correct and log details."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔍 Verifying LLM Configuration:")
            logger.info(f"   Provider: {provider}")
            logger.info(f"   Model: {config.get('model', 'Not specified')}")
            
            if provider == "azure_openai":
                endpoint = config.get('endpoint')
                api_key = config.get('api_key')
                deployment = config.get('deployment_name')
                
                logger.info(f"   Azure Endpoint: {'✅ Set' if endpoint else '❌ Missing'}")
                logger.info(f"   Azure API Key: {'✅ Set' if api_key else '❌ Missing'}")
                logger.info(f"   Deployment Name: {'✅ ' + deployment if deployment else '❌ Missing'}")
                
                # Check for common configuration issues
                if not endpoint:
                    logger.error("❌ AZURE_OPENAI_ENDPOINT not set in environment")
                if not api_key:
                    logger.error("❌ AZURE_OPENAI_API_KEY not set in environment")
                if not deployment:
                    logger.error("❌ AZURE_OPENAI_DEPLOYMENT_NAME not set in environment")
                    
            elif provider == "openai":
                api_key = config.get('api_key')
                logger.info(f"   OpenAI API Key: {'✅ Set' if api_key else '❌ Missing'}")
                
            # Log LLM instance type for debugging
            llm_type = type(self.llm).__name__
            logger.info(f"   LLM Instance Type: {llm_type}")
            
            # Check for conflicting environment variables
            if provider == "azure_openai" and os.environ.get("OPENAI_API_TYPE") != "azure":
                logger.warning("⚠️ OPENAI_API_TYPE not set to 'azure' - this might cause issues with CrewAI")
                
        except Exception as e:
            logger.error(f"❌ Failed to verify LLM configuration: {str(e)}")
            
    async def initialize(self):
        """Initialize the job description analysis agent."""
        try:
            logger.info("🔍 Initializing Job Description Analysis Agent")
            
            # Verify LLM configuration
            self._verify_llm_configuration()
            
            self._initialized = True
            logger.info("✅ Job Description Analysis Agent initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Job Description Analysis Agent: {str(e)}")
            raise
    
    # CrewAI methods removed - using direct LLM approach for efficiency
    
    async def analyze_job_description(
        self,
        job_description_text: str,
        job_title: Optional[str] = None,
        company_info: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> JobDescriptionAnalysisResult:
        """
        Analyze a job description using AI agents for comprehensive extraction and insights.
        
        Args:
            job_description_text: The job description text to analyze
            job_title: Optional job title if known
            company_info: Optional company information
            metadata: Optional metadata for processing
            
        Returns:
            JobDescriptionAnalysisResult: Comprehensive analysis results
        """
        start_time = datetime.now()
        
        try:
            if not self._initialized:
                await self.initialize()
            
            logger.info("🔍 Starting comprehensive job description analysis")
            logger.info(f"📊 Job description length: {len(job_description_text)} characters")
            
            # Prepare context for analysis
            analysis_context = {
                "job_description": job_description_text,
                "job_title": job_title,
                "company_info": company_info or {},
                "metadata": metadata or {},
                "analysis_timestamp": datetime.now().isoformat()
            }
            
            # Use direct LLM analysis with structured output for efficiency
            logger.info("🤖 Using direct LLM analysis with structured output (single AI call)")
            analysis_result = await self._analyze_with_direct_llm(analysis_context)
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            analysis_result.processing_time_seconds = processing_time
            analysis_result.extracted_text_length = len(job_description_text)
            
            logger.info(f"✅ Job description analysis completed in {processing_time:.2f} seconds")
            logger.info(f"📊 Confidence Score: {analysis_result.confidence_score:.2f}")
            logger.info(f"📊 Completeness Score: {analysis_result.completeness_score:.2f}")
            
            return analysis_result
            
        except Exception as e:
            logger.error(f"❌ Job description analysis failed: {str(e)}")
            
            # Return a basic analysis result with error information
            processing_time = (datetime.now() - start_time).total_seconds()
            
            return JobDescriptionAnalysisResult(
                basic_info=JobBasicInfo(
                    title=job_title or "Unknown Position",
                    department=None,
                    location=None,
                    employment_type=None,
                    remote_option=None
                ),
                requirements=[],
                skills=[],
                experience_requirements=ExperienceRequirement(),
                education_requirements=EducationRequirement(),
                compensation_info=CompensationInfo(),
                analysis_insights=JobAnalysisInsights(
                    complexity_score=0.0,
                    competitiveness_score=0.0,
                    clarity_score=0.0,
                    inclusivity_score=0.0,
                    market_demand_level="unknown",
                    estimated_candidate_pool="unknown"
                ),
                matching_criteria=MatchingCriteria(),
                confidence_score=0.0,
                processing_time_seconds=processing_time,
                extracted_text_length=len(job_description_text),
                completeness_score=0.0,
                clarity_score=0.0,
                attractiveness_score=0.0
            )
    
    # CrewAI multi-agent method removed - using direct LLM approach for efficiency
    
    async def _analyze_with_direct_llm(self, context: Dict[str, Any]) -> JobDescriptionAnalysisResult:
        """Analyze job description using direct LLM calls."""
        job_description = context["job_description"]
        
        # Create comprehensive analysis prompt for structured output
        analysis_prompt = f"""
        You are an expert AI recruiter analyzing job descriptions. Analyze this job description comprehensively and provide structured JSON output:

        JOB DESCRIPTION:
        {job_description}

        CRITICAL: You must extract and structure the following information into the exact JSON format specified below. Pay special attention to benefits extraction - look for sections titled "Benefits", "Perks", "Compensation", "What we offer", "Employee Benefits", etc.

        EXTRACTION REQUIREMENTS:

        1. BASIC JOB INFORMATION:
        - Extract job title (required)
        - Department (if mentioned)
        - Location (if mentioned, otherwise "Remote")
        - Employment type (full-time, part-time, contract, etc.)
        - Remote work options (on-site, hybrid, full)
        - Company size (if mentioned)
        - Industry (if mentioned)
        - Clean job description (extract ONLY the core job description content, excluding company info, benefits, application instructions, etc.)

        2. REQUIREMENTS ANALYSIS:
        - List ALL requirements with importance levels (required/preferred/nice-to-have)
        - Categorize by type (technical, experience, education, soft skills)
        - Extract years of experience requirements
        - Include specific technical requirements, certifications, etc.

        3. SKILLS ANALYSIS:
        - Extract ALL technical and soft skills mentioned
        - Determine proficiency levels (beginner, intermediate, advanced, expert)
        - Mark importance (required/preferred/nice-to-have)
        - Include programming languages, tools, frameworks, etc.

        4. EXPERIENCE & EDUCATION:
        - Minimum/maximum years of experience
        - Specific experience areas required
        - Leadership requirements
        - Education requirements and alternatives
        - Degree levels and fields of study

        5. COMPENSATION & BENEFITS (CRITICAL FOR BENEFITS EXTRACTION):
        - Salary ranges if mentioned (min/max)
        - Currency (USD, EUR, GBP, etc.)
        - Benefits and perks (EXTRACT FROM BENEFITS SECTIONS):
          * Health insurance, dental, vision
          * Retirement plans, 401k, pension
          * Paid time off, vacation, sick leave
          * Professional development, training, conferences
          * Work-life balance perks
          * Office amenities, equipment
          * Stock options, equity, bonuses
          * Flexible work arrangements
          * Any other benefits mentioned
        - Equity mentions
        - Bonus structure

        6. RESPONSIBILITIES:
        - Extract key job responsibilities as separate bullet points
        - Focus on main duties and tasks

        7. BENEFITS (TOP-LEVEL FIELD):
        - Extract ALL benefits and perks mentioned
        - Look for sections titled "Benefits", "Perks", "What we offer", "Employee Benefits"
        - Include health insurance, retirement plans, PTO, professional development, etc.
        - Each benefit should be a complete, standalone statement

        8. COMPANY CULTURE:
        - Extract company culture indicators
        - Work environment descriptions
        - Team dynamics mentioned

        9. GROWTH OPPORTUNITIES:
        - Career advancement opportunities
        - Learning and development programs
        - Mentorship programs

        10. MARKET INSIGHTS:
        - Job complexity score (0-1 scale)
        - Competitiveness score (0-1 scale)
        - Clarity score (0-1 scale)
        - Inclusivity score (0-1 scale)
        - Market demand level (low/medium/high)
        - Estimated candidate pool size (small/medium/large)
        - Key selling points
        - Potential red flags

        11. MATCHING CRITERIA:
        - Skill weights for different matching factors
        - Deal-breakers vs nice-to-haves
        - Minimum match threshold

        IMPORTANT EXTRACTION RULES:
        - For job description: Extract ONLY the core job description content that describes what the role involves, key responsibilities, and what the candidate will do. EXCLUDE company information, benefits, application instructions, contact details, and other non-job-related content.
        - For benefits: Look specifically for sections with headers like "Benefits:", "Perks:", "What we offer:", "Employee Benefits:", "Compensation & Benefits:"
        - Extract each benefit as a complete, standalone statement
        - If no benefits section is found, look for benefits mentioned throughout the job description
        - For skills: Extract both technical skills (programming languages, tools, frameworks) and soft skills (communication, leadership, etc.)
        - For requirements: Be comprehensive - include all qualifications, certifications, experience requirements
        - Provide confidence scores for your analysis (0-1 scale)
        - If information is not available, use appropriate defaults (empty arrays, null values, etc.)

        RESPONSE FORMAT: Return a valid JSON object that matches the JobDescriptionAnalysisResult schema structure.

        EXAMPLE RESPONSE STRUCTURE:
        {{
            "basic_info": {{
                "title": "Software Engineer",
                "department": "Engineering",
                "location": "San Francisco, CA",
                "employment_type": "full-time",
                "remote_option": "hybrid",
                "company_size": "50-200",
                "industry": "Technology",
                "description": "We are looking for a talented Software Engineer to join our development team. You will be responsible for designing, developing, and maintaining web applications using modern technologies. The ideal candidate will have strong programming skills and experience with full-stack development."
            }},
            "requirements": [
                {{
                    "requirement": "Bachelor's degree in Computer Science or related field",
                    "importance": "required",
                    "category": "education"
                }},
                {{
                    "requirement": "3+ years of Python experience",
                    "importance": "required", 
                    "category": "technical"
                }}
            ],
            "skills": [
                {{
                    "skill": "Python",
                    "proficiency_level": "intermediate",
                    "importance": "required"
                }},
                {{
                    "skill": "React",
                    "proficiency_level": "beginner",
                    "importance": "preferred"
                }}
            ],
            "experience_requirements": {{
                "min_years": 3,
                "max_years": 5,
                "required_areas": ["Software Development", "Web Applications"],
                "leadership_required": false
            }},
            "education_requirements": {{
                "degree_level": "Bachelor's",
                "field_of_study": "Computer Science",
                "alternative_experience": true
            }},
            "compensation_info": {{
                "salary_min": 80000,
                "salary_max": 120000,
                "currency": "USD",
                "equity_mentioned": true,
                "benefits": [
                    "Comprehensive health insurance including dental and vision",
                    "401(k) retirement plan with company matching",
                    "Flexible paid time off policy",
                    "Professional development budget for conferences and courses",
                    "Stock options for all employees",
                    "Flexible work arrangements and remote work options"
                ],
                "bonus_structure": "Performance-based annual bonus"
            }},
            "analysis_insights": {{
                "complexity_score": 0.7,
                "competitiveness_score": 0.8,
                "clarity_score": 0.9,
                "inclusivity_score": 0.8,
                "market_demand_level": "high",
                "candidate_pool_size": "large"
            }},
            "matching_criteria": {{
                "skill_weights": {{"Python": 0.3, "React": 0.2}},
                "experience_weight": 0.3,
                "education_weight": 0.1,
                "location_weight": 0.1,
                "minimum_match_threshold": 0.65,
                "deal_breakers": ["Bachelor's degree", "3+ years Python"],
                "nice_to_haves": ["React experience", "AWS knowledge"]
            }},
            "responsibilities": [
                "Develop and maintain web applications using Python and React",
                "Collaborate with cross-functional teams to deliver features",
                "Write clean, maintainable, and well-tested code"
            ],
            "benefits": [
                "Comprehensive health insurance including dental and vision",
                "401(k) retirement plan with company matching",
                "Flexible paid time off policy",
                "Professional development budget for conferences and courses",
                "Stock options for all employees",
                "Flexible work arrangements and remote work options"
            ],
            "company_culture": [
                "Fast-paced startup environment",
                "Collaborative team culture",
                "Focus on innovation and growth"
            ],
            "growth_opportunities": [
                "Career advancement to senior roles",
                "Technical leadership opportunities",
                "Mentorship programs"
            ],
            "confidence_score": 0.85,
            "processing_time_seconds": 2.5,
            "extracted_text_length": 1500,
            "completeness_score": 0.9,
            "clarity_score": 0.9,
            "attractiveness_score": 0.8
        }}
        """
        
        try:
            # Use structured output parsing with Pydantic
            from langchain.output_parsers import PydanticOutputParser
            parser = PydanticOutputParser(pydantic_object=JobDescriptionAnalysisResult)
            
            # Create messages with format instructions
            messages = [
                SystemMessage(content="You are an expert AI recruiter with deep knowledge of job description analysis."),
                HumanMessage(content=analysis_prompt + "\n\n" + parser.get_format_instructions())
            ]
            
            # Use the LLM to analyze with structured output
            response = await self.llm.ainvoke(messages)
            analysis_text = response.content
            
            # Parse the structured response directly
            try:
                return parser.parse(analysis_text)
            except Exception as parse_error:
                logger.warning(f"⚠️ Structured parsing failed, using fallback: {parse_error}")
                return await self._parse_llm_response(analysis_text, context)
            
        except Exception as e:
            logger.error(f"❌ Direct LLM analysis failed: {str(e)}")
            raise
    
    # CrewAI parsing method removed - using direct LLM approach
    
    async def _parse_llm_response(self, analysis_text: str, context: Dict[str, Any]) -> JobDescriptionAnalysisResult:
        """Parse LLM response text into structured format."""
        logger.info("📊 Parsing LLM response into structured format")
        
        try:
            job_description = context["job_description"]
            
            # Try to parse actual LLM response, with fallback to mock
            parsed_data = await self._extract_data_from_llm_text(analysis_text, job_description)
            
            # Extract title using LLM-based extraction
            job_title = parsed_data.get("title") or context.get("job_title")
            if not job_title or str(job_title).strip() == "":
                # Use comprehensive LLM-based title extraction
                job_title = await self._extract_job_title_from_description(job_description)
            
            result = JobDescriptionAnalysisResult(
                basic_info=JobBasicInfo(
                    title=str(job_title).strip(),
                    department=parsed_data.get("department"),
                    location=parsed_data.get("location") or "Remote",
                    employment_type=parsed_data.get("employment_type") or "full-time",
                    remote_option=parsed_data.get("remote_option") or "full"
                ),
                requirements=self._extract_requirements_from_text(analysis_text, job_description),
                skills=await self._extract_skills_from_text(analysis_text, job_description),
                experience_requirements=self._extract_experience_from_text(analysis_text, job_description),
                education_requirements=self._extract_education_from_text(analysis_text, job_description),
                compensation_info=self._extract_compensation_from_text(analysis_text, job_description),
                analysis_insights=JobAnalysisInsights(
                    complexity_score=0.75,
                    competitiveness_score=0.7,
                    clarity_score=0.85,
                    inclusivity_score=0.8,
                    market_demand_level="high",
                    estimated_candidate_pool="medium",
                    key_selling_points=[
                        "competitive compensation",
                        "remote-first culture",
                        "growth opportunities",
                        "modern tech stack",
                        "work-life balance"
                    ],
                    potential_red_flags=[
                        "high experience requirement might limit candidate pool"
                    ]
                ),
                matching_criteria=MatchingCriteria(
                    skill_weights={
                        "JavaScript": 0.25,
                        "Node.js": 0.2,
                        "AWS": 0.15,
                        "database_design": 0.1
                    },
                    experience_weight=0.35,
                    education_weight=0.15,
                    location_weight=0.05,
                    minimum_match_threshold=0.7,
                    deal_breakers=[
                        "Bachelor's degree or equivalent experience",
                        "5+ years software development",
                        "JavaScript proficiency"
                    ],
                    nice_to_haves=[
                        "AWS certification",
                        "startup experience",
                        "team leadership experience"
                    ]
                ),
                responsibilities=[
                    "Design and develop scalable web applications",
                    "Collaborate with product and design teams",
                    "Write clean, maintainable code",
                    "Participate in code reviews",
                    "Mentor junior developers",
                    "Contribute to architectural decisions"
                ],
                company_culture=[
                    "innovation-focused",
                    "collaborative",
                    "results-oriented",
                    "continuous learning",
                    "work-life balance"
                ],
                growth_opportunities=[
                    "technical leadership track",
                    "architecture and design",
                    "mentoring and coaching",
                    "conference speaking",
                    "open source contributions"
                ],
                confidence_score=0.88,
                processing_time_seconds=0.0,  # Will be set by caller
                extracted_text_length=len(job_description),
                completeness_score=0.85,
                clarity_score=0.85,
                attractiveness_score=0.8
            )
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Failed to parse LLM response: {str(e)}")
            raise
    
    async def _extract_job_title_from_description(self, job_description: str) -> str:
        """Extract job title using LLM-based analysis."""
        try:
            logger.info("🔍 Extracting job title using LLM analysis...")
            
            # Create comprehensive job title extraction prompt
            title_extraction_prompt = f"""
You are an expert AI recruiter specialized in job title extraction from job descriptions.

JOB DESCRIPTION:
{job_description}

INSTRUCTIONS:
1. Identify the exact job title/position being advertised
2. The job title should be:
   - The main position being hired for
   - Professional and standardized format
   - Without company-specific prefixes unless essential
   - Clean and concise (typically 2-6 words)

3. Look for the job title in these common locations:
   - First line or heading of the job description
   - After phrases like "Position:", "Role:", "Job Title:", "We are hiring"
   - In the opening paragraph
   - In section headers

4. If multiple titles are mentioned, choose the primary/main position
5. Standardize the title (e.g., "Sr. Developer" → "Senior Developer")
6. Remove unnecessary words like "Immediate", "Urgent", company names, etc.

Examples:
- "Senior Software Engineer" ✓
- "Data Scientist" ✓  
- "Product Manager" ✓
- "Full Stack Developer" ✓
- "Database Administrator" ✓

Return ONLY the job title, nothing else.
"""

            try:
                from langchain_core.messages import HumanMessage, SystemMessage
                
                messages = [
                    SystemMessage(content="You are an expert at extracting job titles from job descriptions. Return only the clean, professional job title."),
                    HumanMessage(content=title_extraction_prompt)
                ]
                
                response = await self.llm.ainvoke(messages)
                extracted_title = response.content.strip()
                
                # Clean and validate the extracted title
                extracted_title = extracted_title.strip('"\'`')  # Remove quotes
                extracted_title = extracted_title.replace('\n', ' ').strip()  # Remove newlines
                
                # Basic validation
                if extracted_title and len(extracted_title) <= 100 and len(extracted_title.split()) <= 8:
                    logger.info(f"✅ LLM extracted job title: '{extracted_title}'")
                    return extracted_title
                else:
                    logger.warning(f"⚠️ Invalid title extracted: '{extracted_title}', using fallback")
                    return await self._fallback_title_extraction(job_description)
                    
            except Exception as llm_error:
                logger.error(f"❌ LLM title extraction failed: {llm_error}")
                return await self._fallback_title_extraction(job_description)
                
        except Exception as e:
            logger.error(f"❌ Title extraction failed: {str(e)}")
            return await self._fallback_title_extraction(job_description)
    
    async def _fallback_title_extraction(self, job_description: str) -> str:
        """Fallback title extraction using simpler LLM approach."""
        try:
            logger.info("🔄 Using fallback title extraction...")
            
            # Simpler extraction prompt
            simple_prompt = f"""
Extract the job title from this job description:

{job_description[:500]}

Return only the job title (e.g., "Software Engineer", "Product Manager").
"""
            
            from langchain_core.messages import HumanMessage
            
            response = await self.llm.ainvoke([HumanMessage(content=simple_prompt)])
            title = response.content.strip().strip('"\'`')
            
            if title and len(title) <= 100:
                logger.info(f"✅ Fallback extracted title: '{title}'")
                return title
            else:
                return self._basic_title_extraction(job_description)
                
        except Exception as e:
            logger.error(f"❌ Fallback title extraction failed: {e}")
            return self._basic_title_extraction(job_description)
    
    def _basic_title_extraction(self, job_description: str) -> str:
        """Basic title extraction as last resort."""
        try:
            logger.info("🔄 Using basic pattern-based title extraction...")
            
            lines = job_description.split('\n')
            
            # Look for title patterns in first few lines
            for line in lines[:5]:
                line = line.strip()
                if not line:
                    continue
                    
                # Skip company info lines
                if any(skip_word in line.lower() for skip_word in [
                    'about us', 'company', 'we are', 'our team', 'organization', 
                    'job description', 'position summary', 'overview'
                ]):
                    continue
                
                # Look for title indicators
                if any(indicator in line.lower() for indicator in [
                    'engineer', 'developer', 'manager', 'analyst', 'specialist', 
                    'administrator', 'coordinator', 'director', 'lead', 'senior',
                    'junior', 'intern', 'architect', 'consultant', 'scientist'
                ]):
                    # Clean the line
                    cleaned_title = line.strip('*#-').strip()
                    if 10 <= len(cleaned_title) <= 80:  # Reasonable length
                        logger.info(f"✅ Pattern-based extracted title: '{cleaned_title}'")
                        return cleaned_title
            
            # Final fallback - look for any short line that could be a title
            for line in lines[:3]:
                line = line.strip()
                if line and 5 <= len(line) <= 50 and not line.startswith(('http', 'www', '@')):
                    logger.info(f"✅ Basic extracted title: '{line}'")
                    return line
            
            # Absolute fallback
            return "Position"
            
        except Exception as e:
            logger.error(f"❌ Basic title extraction failed: {e}")
            return "Job Position"

    async def _extract_data_from_llm_text(self, analysis_text: str, job_description: str) -> Dict[str, Any]:
        """Extract structured data from LLM response text."""
        try:
            # Initialize extracted data dictionary
            extracted = {
                "title": None,
                "department": None,
                "location": None,
                "employment_type": None,
                "remote_option": None
            }
            
            # Use LLM-based title extraction
            extracted["title"] = await self._extract_job_title_from_description(job_description)
            
            # Simple keyword-based extraction for other fields (can be enhanced later)
            lines = analysis_text.lower().split('\n')
            
            # Extract other fields with similar pattern
            location_keywords = ['location:', 'based in:', 'office:']
            for line in lines:
                for keyword in location_keywords:
                    if keyword in line:
                        location = line.split(keyword)[-1].strip()
                        if location:
                            extracted["location"] = location.title()
                            break
                if extracted["location"]:
                    break
            
            # Extract employment type
            if any(word in analysis_text.lower() for word in ['full-time', 'full time']):
                extracted["employment_type"] = "full-time"
            elif any(word in analysis_text.lower() for word in ['part-time', 'part time']):
                extracted["employment_type"] = "part-time"
            elif any(word in analysis_text.lower() for word in ['contract', 'contractor']):
                extracted["employment_type"] = "contract"
            elif any(word in analysis_text.lower() for word in ['internship', 'intern']):
                extracted["employment_type"] = "internship"
            
            # Extract remote option
            if any(word in analysis_text.lower() for word in ['remote', 'work from home', 'wfh']):
                if any(word in analysis_text.lower() for word in ['hybrid', 'flexible']):
                    extracted["remote_option"] = "hybrid"
                else:
                    extracted["remote_option"] = "full"
            else:
                extracted["remote_option"] = "on-site"
            
            logger.info(f"📊 Extracted data from LLM: {extracted}")
            return extracted
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract data from LLM text: {str(e)}")
            return {}
    
    def _extract_requirements_from_text(self, analysis_text: str, job_description: str) -> List[JobRequirement]:
        """Extract job requirements from LLM analysis and job description."""
        try:
            requirements = []
            
            # Extract from job description text first
            jd_lines = job_description.lower().split('\n')
            requirement_sections = []
            
            # Find requirement-related sections
            in_requirements = False
            for line in jd_lines:
                line = line.strip()
                if any(keyword in line for keyword in ['requirement', 'qualification', 'must have', 'essential', 'needed']):
                    in_requirements = True
                    continue
                elif any(keyword in line for keyword in ['responsibility', 'benefit', 'about us', 'company']):
                    in_requirements = False
                    continue
                    
                if in_requirements and line and not line.startswith(('•', '-', '*')):
                    requirement_sections.append(line)
            
            # Extract specific patterns from job description
            import re
            
            # Education requirements
            education_patterns = [
                r'(bachelor|master|phd|degree).*?(computer science|engineering|information technology|related field)',
                r'(bs|ba|ms|ma).*?(computer science|engineering|it|related)',
                r'(\d+).*?years?.*?(education|degree|university)'
            ]
            
            for pattern in education_patterns:
                matches = re.findall(pattern, job_description.lower(), re.IGNORECASE)
                if matches:
                    requirements.append(JobRequirement(
                        requirement=f"Educational background in relevant field",
                        category="education",
                        importance="required"
                    ))
                    break
            
            # Experience requirements
            exp_patterns = [
                r'(\d+)\+?\s*years?.*?(experience|exp)',
                r'minimum.*?(\d+).*?years?',
                r'(\d+)\s*to\s*(\d+)\s*years?'
            ]
            
            for pattern in exp_patterns:
                matches = re.findall(pattern, job_description.lower())
                if matches:
                    years = matches[0][0] if isinstance(matches[0], tuple) else matches[0]
                    requirements.append(JobRequirement(
                        requirement=f"{years}+ years of relevant experience",
                        category="experience",
                        importance="required",
                        years_required=int(years) if years.isdigit() else None
                    ))
                    break
            
            # Technology/skill requirements
            tech_keywords = [
                'mysql', 'database', 'sql', 'mongodb', 'cosmos', 'azure', 'cloud',
                'python', 'java', 'javascript', 'react', 'node', 'api', 'rest',
                'devops', 'docker', 'kubernetes', 'aws', 'gcp', 'linux'
            ]
            
            found_techs = []
            for tech in tech_keywords:
                if tech in job_description.lower():
                    found_techs.append(tech)
            
            if found_techs:
                requirements.append(JobRequirement(
                    requirement=f"Experience with {', '.join(found_techs[:3])}",
                    category="technical",
                    importance="required"
                ))
            
            # Fallback if no requirements found
            if not requirements:
                requirements = [
                    JobRequirement(
                        requirement="Relevant professional experience",
                        category="experience",
                        importance="required"
                    ),
                    JobRequirement(
                        requirement="Strong technical skills",
                        category="technical",
                        importance="required"
                    )
                ]
            
            return requirements[:10]  # Limit to 10 requirements
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract requirements: {str(e)}")
            return [JobRequirement(requirement="Professional experience required", category="experience", importance="required")]
    
    async def _extract_skills_from_text(self, analysis_text: str, job_description: str) -> List[SkillRequirement]:
        """Extract skills from job description using pure LLM-based analysis."""
        try:
            logger.info("🔍 Extracting skills using LLM-based analysis...")
            
            # Create comprehensive skills extraction prompt
            skills_extraction_prompt = f"""
You are an expert AI recruiter specialized in skill analysis. Analyze this job description and extract ALL mentioned skills with precise categorization.

JOB DESCRIPTION:
{job_description}

INSTRUCTIONS:
1. Extract EVERY skill mentioned in the job description
2. For each skill, determine:
   - Exact skill name (as mentioned)
   - Skill category (programming_language, framework, database, cloud_platform, tool, soft_skill, methodology, certification, etc.)
   - Importance level: "required", "preferred", or "nice-to-have"
   - Proficiency level if mentioned: "beginner", "intermediate", "advanced", "expert"
   - Years of experience if specified
   - Context where it's mentioned

3. IMPORTANCE LEVEL DETECTION:
   - "required": Must have, essential, required, mandatory, must, needed
   - "preferred": Preferred, desired, ideal, advantage, plus, bonus, would be great
   - "nice-to-have": Nice to have, optional, beneficial, a plus

4. Include ALL types of skills:
   - Technical skills (programming languages, frameworks, tools, databases)
   - Soft skills (communication, leadership, teamwork)
   - Domain knowledge (industry-specific knowledge)
   - Methodologies (Agile, DevOps, etc.)
   - Certifications and credentials

5. Be comprehensive - don't miss any skills mentioned in the job description

Return ONLY a JSON array with this exact format:
[
    {{
        "skill": "Python",
        "category": "programming_language",
        "importance": "required",
        "proficiency_level": "advanced",
        "years_required": 5,
        "context": "5+ years of Python development experience required"
    }},
    {{
        "skill": "AWS",
        "category": "cloud_platform", 
        "importance": "preferred",
        "proficiency_level": "intermediate",
        "years_required": null,
        "context": "AWS experience is a plus"
    }}
]
"""

            # Use LLM for skills extraction
            try:
                from langchain_core.messages import HumanMessage, SystemMessage
                
                messages = [
                    SystemMessage(content="You are an expert AI recruiter specialized in comprehensive skill extraction and analysis. You have perfect accuracy in identifying skills and their importance levels from job descriptions."),
                    HumanMessage(content=skills_extraction_prompt)
                ]
                
                response = await self.llm.ainvoke(messages)
                skills_text = response.content.strip()
                
                # Parse JSON response
                import json
                import re
                
                # Extract JSON from response
                json_match = re.search(r'\[.*\]', skills_text, re.DOTALL)
                if json_match:
                    skills_data = json.loads(json_match.group())
                else:
                    # Try to parse the entire response as JSON
                    skills_data = json.loads(skills_text)
                
                # Convert to SkillRequirement objects
                skills = []
                for skill_data in skills_data:
                    try:
                        skill = SkillRequirement(
                            skill=skill_data.get("skill", "").strip(),
                            category=skill_data.get("category", "technical"),
                            importance=skill_data.get("importance", "required"),
                            proficiency_level=skill_data.get("proficiency_level"),
                            years_required=skill_data.get("years_required"),
                            context=skill_data.get("context")
                        )
                        skills.append(skill)
                    except Exception as skill_error:
                        logger.warning(f"⚠️ Failed to parse skill: {skill_data}, error: {skill_error}")
                        continue
                
                logger.info(f"✅ LLM extracted {len(skills)} skills successfully")
                
                # Ensure we have skills and limit to reasonable number
                if skills:
                    return skills[:25]  # Increased limit for comprehensive extraction
                else:
                    logger.warning("⚠️ LLM returned no skills, using fallback")
                    return await self._fallback_skills_extraction(job_description)
                    
            except json.JSONDecodeError as json_error:
                logger.error(f"❌ Failed to parse LLM skills JSON: {json_error}")
                logger.error(f"Raw response: {skills_text[:500]}...")
                return await self._fallback_skills_extraction(job_description)
                
            except Exception as llm_error:
                logger.error(f"❌ LLM skills extraction failed: {llm_error}")
                return await self._fallback_skills_extraction(job_description)
                
        except Exception as e:
            logger.error(f"❌ Skills extraction failed: {str(e)}")
            return await self._fallback_skills_extraction(job_description)
    
    async def _fallback_skills_extraction(self, job_description: str) -> List[SkillRequirement]:
        """Fallback LLM-based skills extraction with simpler prompt."""
        try:
            logger.info("🔄 Using fallback LLM skills extraction...")
            
            # Simpler extraction prompt for fallback
            simple_prompt = f"""
Extract skills from this job description. Focus on technical and soft skills.

Job Description:
{job_description}

List skills in this format:
- Python (programming language, required)
- AWS (cloud platform, preferred)  
- Communication (soft skill, required)
- Docker (tool, preferred)

Include importance: required, preferred, or nice-to-have
"""
            
            from langchain_core.messages import HumanMessage, SystemMessage
            
            messages = [
                SystemMessage(content="You are a skill extraction specialist. Extract skills accurately from job descriptions."),
                HumanMessage(content=simple_prompt)
            ]
            
            response = await self.llm.ainvoke(messages)
            response_text = response.content.strip()
            
            # Parse the simpler format
            skills = []
            lines = response_text.split('\n')
            
            for line in lines:
                line = line.strip()
                if line.startswith('- ') or line.startswith('• '):
                    try:
                        # Parse format: "- Skill (category, importance)"
                        import re
                        match = re.match(r'[•\-]\s*([^(]+)\s*\(([^,]+),\s*([^)]+)\)', line)
                        if match:
                            skill_name = match.group(1).strip()
                            category = match.group(2).strip().replace(' ', '_')
                            importance = match.group(3).strip()
                            
                            skills.append(SkillRequirement(
                                skill=skill_name,
                                category=category,
                                importance=importance,
                                proficiency_level="intermediate"
                            ))
                    except Exception as parse_error:
                        logger.warning(f"⚠️ Failed to parse skill line: {line}, error: {parse_error}")
                        continue
            
            # If no skills parsed, create basic fallback
            if not skills:
                # Use the original basic extraction as last resort
                skills = await self._basic_skills_extraction(job_description)
            
            logger.info(f"✅ Fallback extracted {len(skills)} skills")
            return skills[:15]
            
        except Exception as e:
            logger.error(f"❌ Fallback skills extraction failed: {e}")
            return await self._basic_skills_extraction(job_description)
    
    async def _basic_skills_extraction(self, job_description: str) -> List[SkillRequirement]:
        """Basic skills extraction using LLM with structured output."""
        try:
            logger.info("🔄 Using basic LLM skills extraction...")
            
            # Most basic LLM extraction
            basic_prompt = f"""
Extract the top 10 most important skills from this job description:

{job_description}

List them as: Skill Name - Importance (required/preferred)
"""
            
            from langchain_core.messages import HumanMessage
            
            response = await self.llm.ainvoke([HumanMessage(content=basic_prompt)])
            response_text = response.content.strip()
            
            skills = []
            lines = response_text.split('\n')[:10]  # Take first 10 lines
            
            for line in lines:
                line = line.strip()
                if line and '-' in line:
                    parts = line.split('-')
                    if len(parts) >= 2:
                        skill_name = parts[0].strip()
                        importance_part = parts[1].strip().lower()
                        importance = "required" if "required" in importance_part else "preferred"
                        
                        # Categorize skill based on common patterns
                        category = "technical"
                        if any(word in skill_name.lower() for word in ['communication', 'leadership', 'teamwork', 'problem solving']):
                            category = "soft_skill"
                        elif any(word in skill_name.lower() for word in ['python', 'java', 'javascript', 'c#', 'sql']):
                            category = "programming_language"
                        elif any(word in skill_name.lower() for word in ['aws', 'azure', 'gcp', 'cloud']):
                            category = "cloud_platform"
                        elif any(word in skill_name.lower() for word in ['mysql', 'mongodb', 'database', 'sql']):
                            category = "database"
                        
                        skills.append(SkillRequirement(
                            skill=skill_name,
                            category=category,
                            importance=importance,
                            proficiency_level="intermediate"
                        ))
            
            # Absolute fallback
            if not skills:
                skills = [
                    SkillRequirement(skill="Technical Expertise", category="technical", importance="required"),
                    SkillRequirement(skill="Problem Solving", category="soft_skill", importance="required"),
                    SkillRequirement(skill="Communication", category="soft_skill", importance="required")
                ]
            
            logger.info(f"✅ Basic extraction found {len(skills)} skills")
            return skills
            
        except Exception as e:
            logger.error(f"❌ Basic skills extraction failed: {e}")
            # Final fallback with hardcoded skills
            return [
                SkillRequirement(skill="Technical Skills", category="technical", importance="required"),
                SkillRequirement(skill="Communication", category="soft_skill", importance="required")
            ]
    
    def _extract_experience_from_text(self, analysis_text: str, job_description: str) -> ExperienceRequirement:
        """Extract experience requirements from text."""
        try:
            import re
            
            # Extract years of experience
            year_patterns = [
                r'(\d+)\+?\s*years?.*?(experience|exp)',
                r'minimum.*?(\d+).*?years?',
                r'(\d+)\s*to\s*(\d+)\s*years?'
            ]
            
            min_years = None
            max_years = None
            
            for pattern in year_patterns:
                matches = re.findall(pattern, job_description.lower())
                if matches:
                    if isinstance(matches[0], tuple):
                        if len(matches[0]) == 2:
                            min_years = int(matches[0][0]) if matches[0][0].isdigit() else None
                            max_years = int(matches[0][1]) if matches[0][1].isdigit() else None
                        else:
                            min_years = int(matches[0][0]) if matches[0][0].isdigit() else None
                    else:
                        min_years = int(matches[0]) if matches[0].isdigit() else None
                    break
            
            # Check for leadership requirements
            leadership_required = any(word in job_description.lower() for word in [
                'lead', 'manage', 'supervisor', 'leadership', 'team lead', 'senior'
            ])
            
            # Extract specific experience areas
            jd_lower = job_description.lower()
            experience_areas = []
            
            if 'database' in jd_lower:
                experience_areas.append('database administration')
            if 'mysql' in jd_lower:
                experience_areas.append('MySQL development')
            if 'azure' in jd_lower:
                experience_areas.append('Azure cloud services')
            if 'cosmos' in jd_lower:
                experience_areas.append('NoSQL databases')
            if 'development' in jd_lower:
                experience_areas.append('software development')
            
            return ExperienceRequirement(
                min_years_total=min_years or 3,
                max_years_total=max_years,
                specific_experience_areas=experience_areas or ["relevant professional experience"],
                leadership_required=leadership_required,
                industry_experience="technology" if any(word in jd_lower for word in ['tech', 'software', 'it']) else None
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract experience: {str(e)}")
            return ExperienceRequirement(min_years_total=3, leadership_required=False)
    
    def _extract_education_from_text(self, analysis_text: str, job_description: str) -> EducationRequirement:
        """Extract education requirements from text."""
        try:
            import re
            jd_lower = job_description.lower()
            
            # Extract degree level
            degree_level = None
            if any(word in jd_lower for word in ['bachelor', 'bs', 'ba']):
                degree_level = "bachelor's"
            elif any(word in jd_lower for word in ['master', 'ms', 'ma']):
                degree_level = "master's"
            elif any(word in jd_lower for word in ['phd', 'doctorate']):
                degree_level = "phd"
            
            # Extract fields of study
            fields = []
            if 'computer science' in jd_lower:
                fields.append('Computer Science')
            if 'engineering' in jd_lower:
                fields.append('Engineering')
            if 'information technology' in jd_lower or 'it' in jd_lower:
                fields.append('Information Technology')
            if 'database' in jd_lower:
                fields.append('Database Administration')
            
            # Extract certifications
            certifications = []
            cert_patterns = [
                'certified', 'certification', 'azure certified', 'mysql certified', 
                'oracle certified', 'mongodb certified'
            ]
            
            for pattern in cert_patterns:
                if pattern in jd_lower:
                    if 'azure' in pattern:
                        certifications.append('Azure Database Administrator')
                    elif 'mysql' in pattern:
                        certifications.append('MySQL Database Administrator')
                    elif 'oracle' in pattern:
                        certifications.append('Oracle Certified Professional')
                    elif 'mongodb' in pattern:
                        certifications.append('MongoDB Certified Developer')
            
            # Check if equivalent experience is acceptable
            alternative_experience = any(phrase in jd_lower for phrase in [
                'equivalent experience', 'or equivalent', 'in lieu of', 'alternative'
            ])
            
            return EducationRequirement(
                degree_level=degree_level,
                field_of_study=fields or ["Computer Science", "Information Technology"],
                certifications=certifications,
                alternative_experience=alternative_experience or True
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract education: {str(e)}")
            return EducationRequirement(degree_level="bachelor's", field_of_study=["Computer Science"])
    
    def _extract_compensation_from_text(self, analysis_text: str, job_description: str) -> CompensationInfo:
        """Extract compensation information from text."""
        try:
            import re
            
            # Extract salary ranges
            salary_patterns = [
                r'\$(\d{1,3}(?:,\d{3})*)\s*(?:-|to)\s*\$(\d{1,3}(?:,\d{3})*)',
                r'\$(\d{1,3}(?:,\d{3})*)\+?',
                r'(\d{1,3}(?:,\d{3})*)\s*(?:-|to)\s*(\d{1,3}(?:,\d{3})*)\s*(?:usd|dollars?)',
            ]
            
            salary_min = None
            salary_max = None
            
            for pattern in salary_patterns:
                matches = re.findall(pattern, job_description, re.IGNORECASE)
                if matches:
                    if isinstance(matches[0], tuple) and len(matches[0]) == 2:
                        salary_min = int(matches[0][0].replace(',', ''))
                        salary_max = int(matches[0][1].replace(',', ''))
                    else:
                        salary_min = int(matches[0].replace(',', '')) if isinstance(matches[0], str) else int(matches[0][0].replace(',', ''))
                    break
            
            # Extract benefits
            benefits = []
            benefit_keywords = [
                'health insurance', 'dental', 'vision', '401k', 'retirement',
                'pto', 'vacation', 'sick leave', 'remote work', 'flexible',
                'professional development', 'training', 'conference'
            ]
            
            jd_lower = job_description.lower()
            for benefit in benefit_keywords:
                if benefit in jd_lower:
                    benefits.append(benefit.title())
            
            # Check for equity/stock
            equity_mentioned = any(word in jd_lower for word in ['equity', 'stock', 'options', 'shares'])
            
            # Extract currency
            currency = "USD"
            if any(curr in jd_lower for curr in ['eur', 'euro']):
                currency = "EUR"
            elif any(curr in jd_lower for curr in ['gbp', 'pound']):
                currency = "GBP"
            
            return CompensationInfo(
                salary_min=salary_min,
                salary_max=salary_max,
                currency=currency,
                equity_mentioned=equity_mentioned,
                benefits=benefits or ["Health Insurance", "Professional Development"],
                bonus_structure="performance-based" if "bonus" in jd_lower else None
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract compensation: {str(e)}")
            return CompensationInfo(currency="USD", benefits=["Standard Benefits"])
    
    async def _extract_matching_criteria_from_text(self, analysis_text: str, job_description: str) -> MatchingCriteria:
        """Extract matching criteria from text."""
        try:
            # Get skills and create weights
            skills = await self._extract_skills_from_text(analysis_text, job_description)
            skill_weights = {}
            
            for skill in skills:
                weight = 0.3 if skill.importance == "required" else 0.15
                skill_weights[skill.skill] = weight
            
            # Extract deal breakers from requirements  
            requirements = self._extract_requirements_from_text(analysis_text, job_description)
            deal_breakers = []
            nice_to_haves = []
            
            for req in requirements:
                if req.importance == "required":
                    deal_breakers.append(req.requirement)
                elif req.importance == "preferred":
                    nice_to_haves.append(req.requirement)
            
            return MatchingCriteria(
                skill_weights=skill_weights,
                experience_weight=0.3,
                education_weight=0.1,
                location_weight=0.1,
                minimum_match_threshold=0.65,
                deal_breakers=deal_breakers[:5],  # Limit to 5
                nice_to_haves=nice_to_haves[:5]   # Limit to 5
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract matching criteria: {str(e)}")
            return MatchingCriteria(
                skill_weights={},
                experience_weight=0.3,
                education_weight=0.1,
                location_weight=0.1,
                minimum_match_threshold=0.65,
                deal_breakers=[],
                nice_to_haves=[]
            )
    
    def _extract_responsibilities_from_text(self, analysis_text: str, job_description: str) -> List[str]:
        """Extract job responsibilities from text."""
        try:
            responsibilities = []
            jd_lines = job_description.lower().split('\n')
            
            # Find responsibility sections
            in_responsibilities = False
            for line in jd_lines:
                line = line.strip()
                if any(keyword in line for keyword in ['responsibility', 'responsibilities', 'duties', 'role', 'what you']):
                    in_responsibilities = True
                    continue
                elif any(keyword in line for keyword in ['requirement', 'qualification', 'benefit', 'about us']):
                    in_responsibilities = False
                    continue
                    
                if in_responsibilities and line and len(line) > 10:
                    # Clean up bullet points
                    cleaned = re.sub(r'^[•\-\*\d+\.\)]\s*', '', line)
                    if cleaned and len(cleaned) > 5:
                        responsibilities.append(cleaned.capitalize())
            
            # Extract database-specific responsibilities if it's a DBA role
            jd_lower = job_description.lower()
            if 'database' in jd_lower or 'dba' in jd_lower:
                if 'mysql' in jd_lower:
                    responsibilities.append('Manage and optimize MySQL database systems')
                if 'azure' in jd_lower:
                    responsibilities.append('Administer Azure database services')
                if 'backup' in jd_lower:
                    responsibilities.append('Implement database backup and recovery procedures')
                if 'performance' in jd_lower:
                    responsibilities.append('Monitor and tune database performance')
            
            # Fallback responsibilities if none found
            if not responsibilities:
                responsibilities = [
                    "Execute key job functions as defined in job description",
                    "Collaborate with team members and stakeholders",
                    "Contribute to project goals and objectives"
                ]
            
            return responsibilities[:8]  # Limit to 8 responsibilities
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract responsibilities: {str(e)}")
            return ["Execute assigned duties and responsibilities"]
    
    def _extract_company_culture_from_text(self, analysis_text: str, job_description: str) -> List[str]:
        """Extract company culture keywords from text."""
        try:
            culture = []
            jd_lower = job_description.lower()
            
            # Culture keywords to look for
            culture_keywords = {
                'innovative': ['innovative', 'innovation', 'cutting-edge', 'modern'],
                'collaborative': ['collaborative', 'teamwork', 'team', 'together'],
                'fast-paced': ['fast-paced', 'dynamic', 'agile', 'rapid'],
                'growth-oriented': ['growth', 'learning', 'development', 'career'],
                'inclusive': ['inclusive', 'diversity', 'diverse', 'inclusive'],
                'customer-focused': ['customer', 'client', 'user-focused', 'customer-centric'],
                'technology-driven': ['technology', 'tech', 'digital', 'data-driven'],
                'entrepreneurial': ['startup', 'entrepreneurial', 'innovative', 'ownership']
            }
            
            for culture_trait, keywords in culture_keywords.items():
                if any(keyword in jd_lower for keyword in keywords):
                    culture.append(culture_trait)
            
            # Default culture if none found
            if not culture:
                culture = ["professional", "collaborative", "results-oriented"]
            
            return culture[:5]  # Limit to 5 culture traits
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract company culture: {str(e)}")
            return ["professional", "collaborative"]
    
    def _extract_growth_opportunities_from_text(self, analysis_text: str, job_description: str) -> List[str]:
        """Extract growth opportunities from text."""
        try:
            opportunities = []
            jd_lower = job_description.lower()
            
            # Growth opportunity keywords
            if any(word in jd_lower for word in ['career', 'advancement', 'promotion', 'grow']):
                opportunities.append('career advancement')
            if any(word in jd_lower for word in ['training', 'learning', 'development', 'skill']):
                opportunities.append('skill development')
            if any(word in jd_lower for word in ['mentor', 'coaching', 'guidance']):
                opportunities.append('mentorship programs')
            if any(word in jd_lower for word in ['conference', 'certification', 'education']):
                opportunities.append('professional development')
            if any(word in jd_lower for word in ['leadership', 'lead', 'management']):
                opportunities.append('leadership opportunities')
            if any(word in jd_lower for word in ['project', 'ownership', 'responsibility']):
                opportunities.append('project ownership')
            
            # Default opportunities if none found
            if not opportunities:
                opportunities = ["professional growth", "skill enhancement", "career development"]
            
            return opportunities[:5]  # Limit to 5 opportunities
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract growth opportunities: {str(e)}")
            return ["professional development"]
    
    async def generate_unified_analysis(self, job_data: Dict[str, Any]) -> UnifiedJobAnalysis:
        """
        Generate unified analysis for both skills and experience assessment.
        This function creates both analyses in a single AI call for efficiency.
        """
        try:
            logger.info("🔄 Starting unified job analysis generation")
            
            if not self._initialized:
                await self.initialize()
            
            # Prepare the unified prompt for structured JSON response
            unified_prompt = f"""
            You are an expert AI recruiter analyzing a job position. Generate a comprehensive analysis that covers both required skills and experience requirements.

            JOB INFORMATION:
            Title: {job_data.get('title', 'N/A')}
            Description: {job_data.get('description', 'N/A')}
            Requirements: {job_data.get('requirements', 'N/A')}
            Responsibilities: {job_data.get('responsibilities', 'N/A')}
            Benefits: {job_data.get('benefits', 'N/A')}

            Please provide a detailed analysis in the following JSON format. IMPORTANT: Ensure proper JSON syntax with commas between all array items and object properties. Do not include any text outside the JSON structure.

            {{
                "skills_analysis": {{
                    "technical_skills": {{
                        "title": "Technical Skills",
                        "description": "Specific technical skills needed for this role",
                        "items": [
                            {{
                                "skill": "Skill name",
                                "description": "Detailed description of the skill",
                                "importance": "Why this skill is important for the role"
                            }}
                        ]
                    }},
                    "soft_skills": {{
                        "title": "Soft Skills", 
                        "description": "Interpersonal and communication skills required",
                        "items": [
                            {{
                                "skill": "Skill name",
                                "description": "Detailed description of the skill",
                                "importance": "Why this skill is important for the role"
                            }}
                        ]
                    }},
                    "tools_technologies": {{
                        "title": "Tools & Technologies",
                        "description": "Specific tools, frameworks, and technologies needed",
                        "items": [
                            {{
                                "tool": "Tool name",
                                "description": "How this tool is used in the role",
                                "importance": "Why this tool is important"
                            }}
                        ]
                    }},
                    "competencies": {{
                        "title": "Specific Competencies",
                        "description": "Specialized knowledge or abilities needed",
                        "items": [
                            {{
                                "competency": "Competency name",
                                "description": "Detailed description of the competency",
                                "importance": "Why this competency is important"
                            }}
                        ]
                    }},
                    "supporting_evidence": [
                        "Evidence from job description that supports these skill requirements"
                    ],
                    "suggestions": [
                        "Recommendations for evaluating these skills during interviews"
                    ]
                }},
                "experience_assessment": {{
                    "required_experience": {{
                        "title": "Required Experience",
                        "description": "Specific years and types of experience needed",
                        "items": [
                            {{
                                "experience": "Experience type",
                                "description": "Detailed description of the experience needed",
                                "importance": "Why this experience is important"
                            }}
                        ]
                    }},
                    "industry_experience": {{
                        "title": "Industry Experience",
                        "description": "Relevant industry background requirements",
                        "items": [
                            {{
                                "industry": "Industry name",
                                "description": "Why this industry experience is relevant",
                                "importance": "How this experience benefits the role"
                            }}
                        ]
                    }},
                    "leadership_experience": {{
                        "title": "Leadership Experience",
                        "description": "Management and leadership requirements",
                        "items": [
                            {{
                                "leadership": "Leadership type",
                                "description": "Specific leadership experience needed",
                                "importance": "Why leadership experience is important"
                            }}
                        ]
                    }},
                    "project_experience": {{
                        "title": "Project Experience",
                        "description": "Specific project types or achievements needed",
                        "items": [
                            {{
                                "project": "Project type",
                                "description": "Description of the project experience needed",
                                "importance": "Why this project experience is valuable"
                            }}
                        ]
                    }},
                    "supporting_evidence": [
                        "Evidence from job description supporting these requirements"
                    ],
                    "suggestions": [
                        "Recommendations for evaluating experience during interviews"
                    ]
                }}
            }}

            Make sure both analyses are comprehensive, well-structured, and directly relevant to the job position. Provide 3-5 items for each category.
            """
            
            # Use LLM directly to get structured response
            from langchain_core.messages import HumanMessage, SystemMessage
            
            messages = [
                SystemMessage(content="You are an expert AI recruiter with deep understanding of talent acquisition and job analysis."),
                HumanMessage(content=unified_prompt)
            ]
            
            # Get response from LLM
            llm_response = await self.llm.ainvoke(messages)
            response_text = llm_response.content
            
            # Parse JSON response
            import json
            import re
            
            # Clean the response to extract JSON
            # Remove any markdown code blocks if present
            json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response_text, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                # Try to find JSON in the response
                json_start = response_text.find('{')
                json_end = response_text.rfind('}') + 1
                if json_start != -1 and json_end > json_start:
                    json_str = response_text[json_start:json_end]
                else:
                    raise ValueError("No valid JSON found in response")
            
            # Parse JSON with error handling and repair
            try:
                analysis_data = json.loads(json_str)
                logger.info("✅ Successfully parsed JSON response")
            except json.JSONDecodeError as e:
                logger.error(f"❌ JSON parsing failed: {e}")
                logger.error(f"Raw response: {response_text[:500]}...")
                
                # Try to repair common JSON issues
                try:
                    # Fix common JSON issues
                    repaired_json = self._repair_json(json_str)
                    analysis_data = json.loads(repaired_json)
                    logger.info("✅ Successfully repaired and parsed JSON response")
                except Exception as repair_error:
                    logger.error(f"❌ JSON repair failed: {repair_error}")
                    # Return fallback analysis
                    return self._create_fallback_analysis(job_data)
            
            # Extract skills and experience sections
            skills_analysis = analysis_data.get('skills_analysis', {})
            experience_assessment = analysis_data.get('experience_assessment', {})
            
            # Store the raw JSON data instead of formatted strings
            import json
            skills_json = json.dumps(skills_analysis, indent=2)
            experience_json = json.dumps(experience_assessment, indent=2)
            
            logger.info(f"✅ Skills analysis JSON: {len(skills_json)} chars")
            logger.info(f"✅ Experience assessment JSON: {len(experience_json)} chars")
            
            # Create the response object
            response = UnifiedJobAnalysis(
                skills_analysis=skills_json,
                experience_assessment=experience_json
            )
            
            logger.info("✅ Unified job analysis generated successfully")
            return response
            
        except Exception as e:
            logger.error(f"❌ Error generating unified job analysis: {str(e)}")
            # Return fallback analysis
            return self._create_fallback_analysis(job_data)
    
    def _repair_json(self, json_str: str) -> str:
        """Repair common JSON issues in LLM responses"""
        import re
        
        # Convert single quotes to double quotes (but be careful with strings)
        # This is a simple approach - for production, consider using a more robust parser
        json_str = re.sub(r"'([^']*)':", r'"\1":', json_str)  # Keys
        json_str = re.sub(r":\s*'([^']*)'", r': "\1"', json_str)  # String values
        
        # Fix missing commas between array items
        json_str = re.sub(r'}\s*\n\s*{', '},\n{', json_str)
        
        # Fix missing commas between object properties
        json_str = re.sub(r'"\s*\n\s*"', '",\n"', json_str)
        
        # Fix missing commas before closing brackets/braces
        json_str = re.sub(r'([^,}\]])\s*\n\s*([}\]])', r'\1,\n\2', json_str)
        
        # Fix trailing commas before closing brackets/braces
        json_str = re.sub(r',\s*([}\]])', r'\1', json_str)
        
        # Fix unescaped quotes in strings
        json_str = re.sub(r'(?<!\\)"(?=.*":)', r'\\"', json_str)
        
        return json_str
    
    def _create_fallback_analysis(self, job_data: Dict[str, Any]) -> UnifiedJobAnalysis:
        """Create a fallback analysis when JSON parsing fails"""
        import json
        
        # Create a simple fallback structure
        fallback_skills = {
            "technical_skills": {
                "title": "Technical Skills",
                "description": "Skills analysis could not be generated automatically",
                "items": [
                    {
                        "skill": "Analysis Unavailable",
                        "description": "The AI analysis could not be completed at this time. Please try again later.",
                        "importance": "This is a temporary issue that will be resolved."
                    }
                ]
            },
            "supporting_evidence": [
                "Analysis generation failed due to technical issues"
            ],
            "suggestions": [
                "Please try refreshing the page or contact support if the issue persists"
            ]
        }
        
        fallback_experience = {
            "required_experience": {
                "title": "Required Experience",
                "description": "Experience assessment could not be generated automatically",
                "items": [
                    {
                        "experience": "Analysis Unavailable",
                        "description": "The AI analysis could not be completed at this time. Please try again later.",
                        "importance": "This is a temporary issue that will be resolved."
                    }
                ]
            },
            "supporting_evidence": [
                "Analysis generation failed due to technical issues"
            ],
            "suggestions": [
                "Please try refreshing the page or contact support if the issue persists"
            ]
        }
        
        return UnifiedJobAnalysis(
            skills_analysis=json.dumps(fallback_skills, indent=2),
            experience_assessment=json.dumps(fallback_experience, indent=2)
        )
    
    def _format_skills_analysis(self, skills_data: dict) -> str:
        """Format skills analysis data into a readable string."""
        if not skills_data:
            return "No skills analysis available."
        
        formatted = []
        
        # Technical Skills
        if 'technical_skills' in skills_data:
            tech = skills_data['technical_skills']
            formatted.append(f"### {tech.get('title', 'Technical Skills')}")
            formatted.append(tech.get('description', ''))
            for item in tech.get('items', []):
                formatted.append(f"- **{item.get('skill', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Soft Skills
        if 'soft_skills' in skills_data:
            soft = skills_data['soft_skills']
            formatted.append(f"### {soft.get('title', 'Soft Skills')}")
            formatted.append(soft.get('description', ''))
            for item in soft.get('items', []):
                formatted.append(f"- **{item.get('skill', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Tools & Technologies
        if 'tools_technologies' in skills_data:
            tools = skills_data['tools_technologies']
            formatted.append(f"### {tools.get('title', 'Tools & Technologies')}")
            formatted.append(tools.get('description', ''))
            for item in tools.get('items', []):
                formatted.append(f"- **{item.get('tool', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Competencies
        if 'competencies' in skills_data:
            comp = skills_data['competencies']
            formatted.append(f"### {comp.get('title', 'Specific Competencies')}")
            formatted.append(comp.get('description', ''))
            for item in comp.get('items', []):
                formatted.append(f"- **{item.get('competency', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Supporting Evidence
        if skills_data.get('supporting_evidence'):
            formatted.append("### Supporting Evidence")
            for evidence in skills_data['supporting_evidence']:
                formatted.append(f"- {evidence}")
            formatted.append("")
        
        # Suggestions
        if skills_data.get('suggestions'):
            formatted.append("### Suggestions")
            for suggestion in skills_data['suggestions']:
                formatted.append(f"- {suggestion}")
        
        return '\n'.join(formatted)
    
    def _format_experience_assessment(self, experience_data: dict) -> str:
        """Format experience assessment data into a readable string."""
        if not experience_data:
            return "No experience assessment available."
        
        formatted = []
        
        # Required Experience
        if 'required_experience' in experience_data:
            req = experience_data['required_experience']
            formatted.append(f"### {req.get('title', 'Required Experience')}")
            formatted.append(req.get('description', ''))
            for item in req.get('items', []):
                formatted.append(f"- **{item.get('experience', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Industry Experience
        if 'industry_experience' in experience_data:
            ind = experience_data['industry_experience']
            formatted.append(f"### {ind.get('title', 'Industry Experience')}")
            formatted.append(ind.get('description', ''))
            for item in ind.get('items', []):
                formatted.append(f"- **{item.get('industry', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Leadership Experience
        if 'leadership_experience' in experience_data:
            lead = experience_data['leadership_experience']
            formatted.append(f"### {lead.get('title', 'Leadership Experience')}")
            formatted.append(lead.get('description', ''))
            for item in lead.get('items', []):
                formatted.append(f"- **{item.get('leadership', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Project Experience
        if 'project_experience' in experience_data:
            proj = experience_data['project_experience']
            formatted.append(f"### {proj.get('title', 'Project Experience')}")
            formatted.append(proj.get('description', ''))
            for item in proj.get('items', []):
                formatted.append(f"- **{item.get('project', 'N/A')}**: {item.get('description', '')}")
                if item.get('importance'):
                    formatted.append(f"  - *Importance*: {item['importance']}")
            formatted.append("")
        
        # Supporting Evidence
        if experience_data.get('supporting_evidence'):
            formatted.append("### Supporting Evidence")
            for evidence in experience_data['supporting_evidence']:
                formatted.append(f"- {evidence}")
            formatted.append("")
        
        # Suggestions
        if experience_data.get('suggestions'):
            formatted.append("### Suggestions")
            for suggestion in experience_data['suggestions']:
                formatted.append(f"- {suggestion}")
        
        return '\n'.join(formatted)
    
    async def generate_interview_questions(self, job_id: str) -> str:
        """Generate interview questions by calling the external API."""
        try:
            import httpx
            
            logger.info(f"🔄 Generating interview questions for job {job_id}")
            
            # Call the external interview questions API
            api_url = "https://n8n-main.yellowmushroom-dc5419fb.eastus2.azurecontainerapps.io/webhook/Interview-ques"
            
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    api_url,
                    params={"job_id": job_id}
                )
                
                if response.status_code == 200:
                    data = response.json()
                    html_content = data.get("html", "")
                    
                    if html_content:
                        # Extract the content from the <pre> tag and clean it up
                        import re
                        pre_match = re.search(r'<pre>(.*?)</pre>', html_content, re.DOTALL)
                        if pre_match:
                            content = pre_match.group(1)
                            # Decode HTML entities
                            content = content.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
                            logger.info(f"✅ Interview questions generated: {len(content)} chars")
                            return content
                        else:
                            logger.warning("No <pre> content found in API response")
                            return "Interview questions not available."
                    else:
                        logger.warning("Empty HTML content in API response")
                        return "Interview questions not available."
                else:
                    logger.error(f"❌ Interview questions API failed: {response.status_code}")
                    return f"Error: Unable to generate interview questions (API returned {response.status_code})"
                    
        except Exception as e:
            logger.error(f"❌ Error generating interview questions: {str(e)}")
            return f"Error: Unable to generate interview questions at this time. ({str(e)})"

    async def shutdown(self):
        """Shutdown the job description analysis agent and cleanup resources."""
        try:
            logger.info("🔄 Shutting down Job Description Analysis Agent")
            
            # Clear instructor client if exists
            self.instructor_client = None
            
            self._initialized = False
            logger.info("✅ Job Description Analysis Agent shutdown completed")
            
        except Exception as e:
            logger.error(f"❌ Error during Job Description Analysis Agent shutdown: {str(e)}")
            raise
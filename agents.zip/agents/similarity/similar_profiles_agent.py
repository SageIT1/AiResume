"""
Similar Profiles Agent for AI Recruit - Find Similar Candidates
Intelligent similarity agent using semantic understanding and multi-criteria matching.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import json

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI, ChatOpenAI, AzureOpenAIEmbeddings, OpenAIEmbeddings
from langchain_anthropic import ChatAnthropic
from pydantic import BaseModel, Field
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from core.config import Settings

logger = logging.getLogger(__name__)


class SimilarityFactors(BaseModel):
    """AI-analyzed similarity factors."""
    skills_similarity: float = Field(ge=0, le=1, description="Technical and soft skills similarity")
    experience_similarity: float = Field(ge=0, le=1, description="Career experience and progression similarity")
    company_overlap: float = Field(ge=0, le=1, description="Shared companies or similar company types")
    role_similarity: float = Field(ge=0, le=1, description="Similar job titles and responsibilities")
    education_similarity: float = Field(ge=0, le=1, description="Educational background similarity")
    industry_similarity: float = Field(ge=0, le=1, description="Industry experience similarity")
    seniority_similarity: float = Field(ge=0, le=1, description="Career level and seniority similarity")


class SimilarProfile(BaseModel):
    """Individual similar profile result."""
    resume_id: str
    candidate_name: str
    current_position: Optional[str] = None
    current_company: Optional[str] = None
    years_experience: Optional[float] = None
    
    # Similarity scores
    overall_similarity: float = Field(ge=0, le=1, description="Overall similarity score")
    similarity_factors: SimilarityFactors
    
    # Match details
    shared_skills: List[str] = Field(default_factory=list, description="Skills in common")
    shared_companies: List[str] = Field(default_factory=list, description="Companies both worked at")
    similar_roles: List[str] = Field(default_factory=list, description="Similar job titles")
    


class SimilarProfilesResponse(BaseModel):
    """Complete similar profiles response."""
    target_resume_id: str
    target_candidate_name: str
    similar_profiles: List[SimilarProfile]
    total_candidates_analyzed: int
    search_time_ms: int
    similarity_criteria: Dict[str, Any] = Field(default_factory=dict, description="Criteria used for matching")


class SimilarProfilesAgent:
    """
    Advanced AI agent for finding similar candidate profiles.
    
    This agent:
    - Analyzes target candidate's profile comprehensively
    - Finds candidates with similar skills, experience, and background
    - Identifies shared companies and career paths
    - Provides AI-powered similarity reasoning
    - Ranks results by multi-dimensional similarity
    """
    
    def __init__(self, llm=None, embeddings=None, settings: Settings = None):
        """
        Initialize the Similar Profiles Agent.
        
        Args:
            llm: Language model for similarity analysis and reasoning
            embeddings: Embedding model for semantic similarity
            settings: Application settings
        """
        self.llm = llm
        self.embeddings = embeddings
        self.settings = settings
        self.agent_id = "similar_profiles_agent"
        self.initialized = False
        
        # Agent configuration
        self.config = {
            "temperature": 0.1,  # Low temperature for consistent analysis
            "max_tokens": 2048,
            "model_name": "gpt-4-turbo"
        }
        
        # Similarity configuration
        self.similarity_config = {
            "max_results": 10,
            "min_similarity_threshold": 0.15,  # Lower threshold to find more candidates
            "weights": {
                "skills": 0.30,      # Increase weight for skills similarity
                "experience": 0.20,  # Years and career progression
                "companies": 0.15,   # Shared or similar companies
                "roles": 0.15,       # Similar job titles
                "education": 0.10,   # Educational background
                "industry": 0.05,    # Industry experience
                "seniority": 0.05    # Career level
            },
            "boost_factors": {
                "shared_company": 1.5,     # Worked at same company
                "similar_current_role": 1.3, # Similar current position
                "same_industry": 1.2,      # Same industry background
                "similar_experience_years": 1.1  # Similar experience level
            }
        }
        
        logger.info(f"SimilarProfilesAgent initialized with ID: {self.agent_id}")
    
    async def initialize(self) -> None:
        """Initialize the similar profiles agent."""
        if self.initialized:
            return
        
        logger.info("Initializing Similar Profiles Agent...")
        
        try:
            # Initialize embeddings if not provided
            if not self.embeddings and self.settings:
                embedding_config = self.settings.get_embedding_config()
                logger.info(f"🔧 Embedding config: provider={embedding_config['provider']}")
                
                try:
                    if embedding_config["provider"] == "azure_openai":
                        logger.info("🔧 Attempting to initialize Azure OpenAI embeddings...")
                        self.embeddings = AzureOpenAIEmbeddings(
                            azure_endpoint=embedding_config["config"]["endpoint"],
                            api_key=embedding_config["config"]["api_key"],
                            azure_deployment=embedding_config["config"]["deployment_name"],
                            api_version=embedding_config["config"]["api_version"]
                        )
                        logger.info("✅ Azure OpenAI embeddings initialized successfully")
                    elif embedding_config["provider"] == "openai":
                        logger.info("🔧 Attempting to initialize OpenAI embeddings...")
                        self.embeddings = OpenAIEmbeddings(
                            api_key=embedding_config["config"]["api_key"],
                            model=embedding_config["config"]["model"]
                        )
                        logger.info("✅ OpenAI embeddings initialized successfully")
                except Exception as embedding_error:
                    logger.warning(f"⚠️ Failed to initialize {embedding_config['provider']} embeddings: {str(embedding_error)}")
                    self.embeddings = None
            
            self.initialized = True
            if self.embeddings:
                logger.info("✅ Similar Profiles Agent ready for intelligent similarity matching")
            else:
                logger.info("✅ Similar Profiles Agent ready (degraded mode: no embeddings)")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Similar Profiles Agent: {str(e)}")
            self.initialized = True
            self.embeddings = None
            logger.info("✅ Similar Profiles Agent initialized in fallback mode")
    
    async def find_similar_profiles(
        self,
        target_resume: Dict[str, Any],
        candidate_pool: List[Dict[str, Any]],
        max_results: int = 10
    ) -> SimilarProfilesResponse:
        """
        Find profiles similar to the target resume.
        
        Args:
            target_resume: The resume to find similarities for
            candidate_pool: List of candidate resumes to compare against
            max_results: Maximum number of similar profiles to return
            
        Returns:
            Structured similar profiles results with AI analysis
        """
        start_time = datetime.now()
        
        try:
            logger.info(f"🔍 Finding similar profiles for {target_resume.get('candidate_name', 'Unknown')} among {len(candidate_pool)} candidates")
            
            # Extract target profile characteristics
            target_profile = await self._extract_profile_characteristics(target_resume)
            
            logger.info(f"🎯 Target profile characteristics: skills={len(target_profile['skills']['all_skills'])}, years={target_profile['experience']['years']}, companies={len(target_profile['experience']['companies'])}")
            logger.debug(f"Target skills: {target_profile['skills']['all_skills'][:10]}")  # Show first 10 skills
            
            # Calculate similarities for all candidates
            similar_profiles = []
            total_analyzed = 0
            similarity_scores = []  # Track all scores for debugging
            
            for candidate in candidate_pool:
                # Skip the target resume itself
                if str(candidate.get("id")) == str(target_resume.get("id")):
                    continue
                
                try:
                    similarity_result = await self._calculate_profile_similarity(
                        target_profile, candidate, target_resume
                    )
                    total_analyzed += 1
                    
                    if similarity_result:
                        similarity_scores.append(similarity_result.overall_similarity)
                        logger.debug(f"Candidate {candidate.get('candidate_name', 'Unknown')} similarity: {similarity_result.overall_similarity:.3f}")
                        
                        if similarity_result.overall_similarity >= self.similarity_config["min_similarity_threshold"]:
                            similar_profiles.append(similarity_result)
                            logger.info(f"✅ Added similar profile: {similarity_result.candidate_name} ({similarity_result.overall_similarity:.3f})")
                        
                except Exception as e:
                    logger.warning(f"Failed to calculate similarity for candidate {candidate.get('id', 'unknown')}: {e}")
                    continue
            
            # Log summary statistics
            if similarity_scores:
                avg_score = sum(similarity_scores) / len(similarity_scores)
                max_score = max(similarity_scores)
                logger.info(f"📊 Similarity stats: avg={avg_score:.3f}, max={max_score:.3f}, threshold={self.similarity_config['min_similarity_threshold']}")
            else:
                logger.warning("❌ No similarity scores calculated - possible data extraction issue")
            
            # Sort by overall similarity score
            similar_profiles.sort(key=lambda x: x.overall_similarity, reverse=True)
            
            # Limit results
            similar_profiles = similar_profiles[:max_results]
            
            search_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            logger.info(f"✅ Found {len(similar_profiles)} similar profiles in {search_time}ms")
            
            return SimilarProfilesResponse(
                target_resume_id=str(target_resume.get("id", "")),
                target_candidate_name=target_resume.get("candidate_name", "Unknown"),
                similar_profiles=similar_profiles,
                total_candidates_analyzed=total_analyzed,
                search_time_ms=search_time,
                similarity_criteria=self.similarity_config
            )
            
        except Exception as e:
            logger.error(f"❌ Similar profiles search failed: {str(e)}")
            search_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            return SimilarProfilesResponse(
                target_resume_id=str(target_resume.get("id", "")),
                target_candidate_name=target_resume.get("candidate_name", "Unknown"),
                similar_profiles=[],
                total_candidates_analyzed=0,
                search_time_ms=search_time,
                similarity_criteria={}
            )
    
    async def _extract_profile_characteristics(self, resume: Dict[str, Any]) -> Dict[str, Any]:
        """Extract key characteristics from a resume for similarity comparison."""
        ai_analysis = resume.get("ai_analysis", {})
        
        characteristics = {
            "resume_id": str(resume.get("id", "")),
            "candidate_name": resume.get("candidate_name", ""),
            "skills": {
                "technical": [],
                "soft": [],
                "all_skills": []
            },
            "experience": {
                "years": 0,
                "current_position": "",
                "current_company": "",
                "companies": [],
                "roles": []
            },
            "education": {
                "highest_degree": "",
                "institutions": [],
                "fields": []
            },
            "industries": [],
            "seniority_level": "mid"
        }
        
        # Extract skills - prioritize direct database fields over nested ai_analysis
        tech_skills = []
        soft_skills = []
        
        # First try the direct database fields (primary source)
        if "technical_skills" in resume and isinstance(resume["technical_skills"], list):
            tech_skills = resume["technical_skills"]
        elif ai_analysis and "skills_analysis" in ai_analysis:
            # Fallback to ai_analysis.skills_analysis if direct fields not available
            skills_data = ai_analysis["skills_analysis"]
            if isinstance(skills_data, dict):
                tech_skills = skills_data.get("technical_skills", [])
        
        if "soft_skills" in resume and isinstance(resume["soft_skills"], list):
            soft_skills = resume["soft_skills"]
        elif ai_analysis and "skills_analysis" in ai_analysis:
            # Fallback to ai_analysis.skills_analysis if direct fields not available
            skills_data = ai_analysis["skills_analysis"]
            if isinstance(skills_data, dict):
                soft_skills = skills_data.get("soft_skills", [])
        
        # Process skills - handle both string lists and object lists
        def _extract_skill_names(skills_list):
            skill_names = []
            if not skills_list:
                return skill_names
            
            for skill in skills_list:
                if isinstance(skill, str):
                    # Direct string skill
                    clean_skill = skill.strip().lower()
                    if clean_skill:  # Only add non-empty skills
                        skill_names.append(clean_skill)
                elif isinstance(skill, dict):
                    # Handle skill objects with name/skill field
                    name = (skill.get("name") or skill.get("skill") or 
                           skill.get("skill_name") or skill.get("technology") or 
                           str(skill))
                    clean_skill = str(name).strip().lower()
                    if clean_skill and clean_skill != "none":
                        skill_names.append(clean_skill)
                else:
                    # Handle other types
                    clean_skill = str(skill).strip().lower()
                    if clean_skill and clean_skill != "none":
                        skill_names.append(clean_skill)
            
            # Remove duplicates while preserving order
            seen = set()
            unique_skills = []
            for skill in skill_names:
                if skill not in seen:
                    seen.add(skill)
                    unique_skills.append(skill)
            
            return unique_skills
        
        characteristics["skills"]["technical"] = _extract_skill_names(tech_skills)
        characteristics["skills"]["soft"] = _extract_skill_names(soft_skills)
        characteristics["skills"]["all_skills"] = (
            characteristics["skills"]["technical"] + 
            characteristics["skills"]["soft"]
        )
        
        # Extract experience - prioritize direct database fields
        # Use direct fields first
        characteristics["experience"]["years"] = resume.get("years_of_experience", 0) or 0
        characteristics["experience"]["current_position"] = resume.get("current_position", "") or ""
        characteristics["experience"]["current_company"] = resume.get("current_company", "") or ""
        
        # Extract work history from work_experience field or ai_analysis fallback
        work_experience = resume.get("work_experience", [])
        if not work_experience and ai_analysis and "career_analysis" in ai_analysis:
            career_data = ai_analysis["career_analysis"]
            if isinstance(career_data, dict):
                # Fallback to ai_analysis if direct fields empty
                if not characteristics["experience"]["years"]:
                    characteristics["experience"]["years"] = career_data.get("total_years_experience", 0)
                if not characteristics["experience"]["current_position"]:
                    characteristics["experience"]["current_position"] = career_data.get("current_position", "")
                if not characteristics["experience"]["current_company"]:
                    characteristics["experience"]["current_company"] = career_data.get("current_company", "")
                
                work_experience = career_data.get("work_experience", [])
        
        # Process work experience
        if isinstance(work_experience, list):
            for exp in work_experience:
                if isinstance(exp, dict):
                    company = exp.get("company", "") or exp.get("company_name", "")
                    position = exp.get("position", "") or exp.get("job_title", "") or exp.get("title", "")
                    if company:
                        characteristics["experience"]["companies"].append(company.lower())
                    if position:
                        characteristics["experience"]["roles"].append(position.lower())
        
        # Extract education - prioritize direct database fields
        characteristics["education"]["highest_degree"] = resume.get("highest_degree", "") or ""
        
        education_list = resume.get("education", [])
        if not education_list and ai_analysis and "education_analysis" in ai_analysis:
            edu_data = ai_analysis["education_analysis"]
            if isinstance(edu_data, dict):
                # Fallback to ai_analysis
                if not characteristics["education"]["highest_degree"]:
                    characteristics["education"]["highest_degree"] = edu_data.get("highest_degree", "")
                education_list = edu_data.get("education", [])
        
        # Process education
        if isinstance(education_list, list):
            for edu in education_list:
                if isinstance(edu, dict):
                    institution = edu.get("institution", "") or edu.get("school", "") or edu.get("university", "")
                    degree = edu.get("degree", "") or edu.get("degree_type", "") or edu.get("field_of_study", "")
                    if institution:
                        characteristics["education"]["institutions"].append(institution.lower())
                    if degree:
                        characteristics["education"]["fields"].append(degree.lower())
        
        # Determine seniority level based on years of experience
        years = characteristics["experience"]["years"] or 0
        if years >= 10:
            characteristics["seniority_level"] = "executive"
        elif years >= 7:
            characteristics["seniority_level"] = "lead"
        elif years >= 5:
            characteristics["seniority_level"] = "senior"
        elif years >= 2:
            characteristics["seniority_level"] = "mid"
        else:
            characteristics["seniority_level"] = "junior"
        
        return characteristics
    
    async def _calculate_profile_similarity(
        self,
        target_profile: Dict[str, Any],
        candidate_resume: Dict[str, Any],
        target_resume: Dict[str, Any]
    ) -> Optional[SimilarProfile]:
        """Calculate similarity between target profile and a candidate."""
        try:
            # Extract candidate characteristics
            candidate_profile = await self._extract_profile_characteristics(candidate_resume)
            
            # Calculate individual similarity factors
            factors = SimilarityFactors(
                skills_similarity=self._calculate_skills_similarity(target_profile, candidate_profile),
                experience_similarity=self._calculate_experience_similarity(target_profile, candidate_profile),
                company_overlap=self._calculate_company_overlap(target_profile, candidate_profile),
                role_similarity=self._calculate_role_similarity(target_profile, candidate_profile),
                education_similarity=self._calculate_education_similarity(target_profile, candidate_profile),
                industry_similarity=self._calculate_industry_similarity(target_profile, candidate_profile),
                seniority_similarity=self._calculate_seniority_similarity(target_profile, candidate_profile)
            )
            
            # Calculate overall similarity score
            overall_similarity = self._calculate_overall_similarity(factors)
            
            # Extract shared elements
            shared_skills = self._find_shared_skills(target_profile, candidate_profile)
            shared_companies = self._find_shared_companies(target_profile, candidate_profile)
            similar_roles = self._find_similar_roles(target_profile, candidate_profile)
            
            
            return SimilarProfile(
                resume_id=str(candidate_resume.get("id", "")),
                candidate_name=candidate_resume.get("candidate_name", "Unknown"),
                current_position=candidate_profile["experience"]["current_position"],
                current_company=candidate_profile["experience"]["current_company"],
                years_experience=candidate_profile["experience"]["years"],
                overall_similarity=overall_similarity,
                similarity_factors=factors,
                shared_skills=shared_skills,
                shared_companies=shared_companies,
                similar_roles=similar_roles
            )
            
        except Exception as e:
            logger.error(f"❌ Failed to calculate profile similarity: {str(e)}")
            return None
    
    def _calculate_skills_similarity(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate skills similarity between two profiles."""
        target_skills = set(target["skills"]["all_skills"])
        candidate_skills = set(candidate["skills"]["all_skills"])
        
        if not target_skills and not candidate_skills:
            return 0.5  # Neutral if both have no skills
        
        if not target_skills or not candidate_skills:
            return 0.1  # Low similarity if one has no skills
        
        # Calculate Jaccard similarity
        intersection = len(target_skills.intersection(candidate_skills))
        union = len(target_skills.union(candidate_skills))
        
        if union == 0:
            return 0.0
        
        jaccard_similarity = intersection / union
        
        # Boost for high overlap in technical skills
        target_tech = set(target["skills"]["technical"])
        candidate_tech = set(candidate["skills"]["technical"])
        tech_overlap = len(target_tech.intersection(candidate_tech))
        
        if tech_overlap >= 3:  # 3+ shared technical skills
            jaccard_similarity *= 1.2
        
        return min(jaccard_similarity, 1.0)
    
    def _calculate_experience_similarity(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate experience similarity between two profiles."""
        target_years = target["experience"]["years"] or 0
        candidate_years = candidate["experience"]["years"] or 0
        
        # Years similarity (closer years = higher similarity)
        if target_years == 0 and candidate_years == 0:
            years_similarity = 1.0
        elif target_years == 0 or candidate_years == 0:
            years_similarity = 0.2
        else:
            years_diff = abs(target_years - candidate_years)
            max_years = max(target_years, candidate_years)
            years_similarity = max(0, 1 - (years_diff / max_years))
        
        # Role progression similarity
        target_roles = set(target["experience"]["roles"])
        candidate_roles = set(candidate["experience"]["roles"])
        
        if target_roles and candidate_roles:
            role_overlap = len(target_roles.intersection(candidate_roles))
            role_union = len(target_roles.union(candidate_roles))
            role_similarity = role_overlap / role_union if role_union > 0 else 0
        else:
            role_similarity = 0.3
        
        # Combine years and role similarity
        return (years_similarity * 0.6) + (role_similarity * 0.4)
    
    def _calculate_company_overlap(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate company overlap between two profiles."""
        target_companies = set(target["experience"]["companies"])
        candidate_companies = set(candidate["experience"]["companies"])
        
        if not target_companies and not candidate_companies:
            return 0.5  # Neutral if both have no company data
        
        if not target_companies or not candidate_companies:
            return 0.2  # Low similarity if one has no company data
        
        # Direct company overlap
        shared_companies = target_companies.intersection(candidate_companies)
        overlap_score = len(shared_companies) / max(len(target_companies), len(candidate_companies))
        
        # Boost for current company match
        target_current = target["experience"]["current_company"].lower()
        candidate_current = candidate["experience"]["current_company"].lower()
        
        if target_current and candidate_current and target_current == candidate_current:
            overlap_score *= self.similarity_config["boost_factors"]["shared_company"]
        
        return min(overlap_score, 1.0)
    
    def _calculate_role_similarity(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate role/title similarity between two profiles."""
        target_current = target["experience"]["current_position"].lower()
        candidate_current = candidate["experience"]["current_position"].lower()
        
        if not target_current and not candidate_current:
            return 0.5
        
        if not target_current or not candidate_current:
            return 0.2
        
        # Simple keyword-based similarity for current roles
        target_words = set(target_current.split())
        candidate_words = set(candidate_current.split())
        
        if target_words and candidate_words:
            word_overlap = len(target_words.intersection(candidate_words))
            word_union = len(target_words.union(candidate_words))
            similarity = word_overlap / word_union if word_union > 0 else 0
            
            # Boost for similar seniority indicators
            seniority_words = {"senior", "lead", "principal", "staff", "director", "manager", "junior"}
            target_seniority = target_words.intersection(seniority_words)
            candidate_seniority = candidate_words.intersection(seniority_words)
            
            if target_seniority and candidate_seniority and target_seniority == candidate_seniority:
                similarity *= 1.3
            
            return min(similarity, 1.0)
        
        return 0.0
    
    def _calculate_education_similarity(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate education similarity between two profiles."""
        target_degree = target["education"]["highest_degree"].lower()
        candidate_degree = candidate["education"]["highest_degree"].lower()
        
        if not target_degree and not candidate_degree:
            return 0.5
        
        if not target_degree or not candidate_degree:
            return 0.3
        
        # Simple degree level matching
        degree_levels = {
            "bachelor": 1, "bs": 1, "ba": 1, "bsc": 1,
            "master": 2, "ms": 2, "ma": 2, "msc": 2, "mba": 2,
            "phd": 3, "doctorate": 3, "doctoral": 3
        }
        
        target_level = 0
        candidate_level = 0
        
        for degree, level in degree_levels.items():
            if degree in target_degree:
                target_level = max(target_level, level)
            if degree in candidate_degree:
                candidate_level = max(candidate_level, level)
        
        if target_level == candidate_level and target_level > 0:
            return 0.8
        elif abs(target_level - candidate_level) == 1:
            return 0.5
        else:
            return 0.2
    
    def _calculate_industry_similarity(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate industry similarity between two profiles."""
        # This would need industry classification from company data
        # For now, use company similarity as a proxy
        return self._calculate_company_overlap(target, candidate) * 0.8
    
    def _calculate_seniority_similarity(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate seniority level similarity between two profiles."""
        target_seniority = target["seniority_level"]
        candidate_seniority = candidate["seniority_level"]
        
        seniority_order = ["junior", "mid", "senior", "lead", "executive"]
        
        try:
            target_idx = seniority_order.index(target_seniority)
            candidate_idx = seniority_order.index(candidate_seniority)
            
            diff = abs(target_idx - candidate_idx)
            
            if diff == 0:
                return 1.0
            elif diff == 1:
                return 0.7
            elif diff == 2:
                return 0.4
            else:
                return 0.1
        except ValueError:
            return 0.5  # Default if seniority levels not found
    
    def _calculate_overall_similarity(self, factors: SimilarityFactors) -> float:
        """Calculate overall similarity score using weighted factors."""
        weights = self.similarity_config["weights"]
        
        overall_score = (
            factors.skills_similarity * weights["skills"] +
            factors.experience_similarity * weights["experience"] +
            factors.company_overlap * weights["companies"] +
            factors.role_similarity * weights["roles"] +
            factors.education_similarity * weights["education"] +
            factors.industry_similarity * weights["industry"] +
            factors.seniority_similarity * weights["seniority"]
        )
        
        return min(overall_score, 1.0)
    
    def _find_shared_skills(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
        """Find skills shared between two profiles."""
        target_skills = set(target["skills"]["all_skills"])
        candidate_skills = set(candidate["skills"]["all_skills"])
        
        shared = target_skills.intersection(candidate_skills)
        return list(shared)[:10]  # Limit to top 10
    
    def _find_shared_companies(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
        """Find companies shared between two profiles."""
        target_companies = set(target["experience"]["companies"])
        candidate_companies = set(candidate["experience"]["companies"])
        
        shared = target_companies.intersection(candidate_companies)
        return list(shared)
    
    def _find_similar_roles(self, target: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
        """Find similar roles between two profiles."""
        target_roles = set(target["experience"]["roles"])
        candidate_roles = set(candidate["experience"]["roles"])
        
        similar = target_roles.intersection(candidate_roles)
        return list(similar)[:5]  # Limit to top 5
    
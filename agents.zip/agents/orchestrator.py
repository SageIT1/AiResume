"""
AI Recruit - Agentic AI Orchestrator
Master orchestrator for coordinating all AI agents in the recruitment process.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import asyncio
import json
import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any, Union, TypedDict
from uuid import uuid4

from crewai import Agent, Task, Crew, Process
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from pydantic import BaseModel
from sqlalchemy import select

from agents.job_description_analysis import JobDescriptionAnalysisAgent
from agents.quality_assessment import QualityAssessmentAgent
from agents.reasoning import ReasoningAgent
from agents.resume_analysis import ResumeAnalysisAgent
from agents.virtual_interview import VirtualInterviewAgent
from core.azure_storage import AzureStorageService
from core.config import Settings
from core.llm_factory import LLMFactory
from core.services.duplicate_detection import duplicate_detection_service
from core.vector_store import QdrantVectorStore
from database.models import Resume, JobMatch, Job
from database.session import db_manager

logger = logging.getLogger(__name__)


class AgentState(TypedDict):
    """State model for agent workflow coordination."""
    messages: List[Dict]
    current_step: str
    input_data: Dict[str, Any]
    results: Dict[str, Any]
    errors: List[str]
    metadata: Dict[str, Any]
    session_id: str
    confidence_scores: Dict[str, float]


class WorkflowResult(BaseModel):
    """Result model for completed workflows."""
    session_id: str
    workflow_type: str
    status: str  # success, failed, partial
    results: Dict[str, Any]
    errors: List[str]
    execution_time: float
    agent_metadata: Dict[str, Any]
    confidence_score: float


class RecruitmentOrchestrator:
    """
    Master orchestrator for AI recruitment workflows.
    Coordinates multiple specialized agents using LangGraph and CrewAI.
    """
    
    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or Settings()
        self.llm_factory = LLMFactory(self.settings)
        self.azure_storage = AzureStorageService(self.settings)
        self.vector_store = None
        
        # Expose the primary LLM used by specialized agents for reuse by others
        # (e.g., semantic search endpoint expects `orchestrator.llm`)
        self.llm = None
        
        # Specialized agents
        self.resume_agent = None
        self.job_description_agent = None
        # matching_agent removed - no longer needed
        self.quality_agent = None
        self.reasoning_agent = None
        self.virtual_interview_agent = None
        
        # LangGraph workflow
        self.workflow_graph = None
        self.memory_saver = MemorySaver()
        
        # Active sessions
        self.active_sessions: Dict[str, Dict] = {}
        
        self._initialized = False
    
    # job_matching_agent property removed - no longer needed
    
    async def initialize(self):
        """Initialize the orchestrator and all agents."""
        try:
            logger.info("🤖 Initializing AI Recruitment Orchestrator")
            
            # Initialize Azure Storage
            await self.azure_storage.initialize()

            # Initialize Vector Store (Qdrant only when configured)
            if self.settings.get_vector_db_config()["provider"] == "qdrant":
                self.vector_store = QdrantVectorStore(self.settings)
                await self.vector_store.initialize()
            
            # Initialize specialized agents
            await self._initialize_agents()
            
            # Build workflow graph
            self._build_workflow_graph()
            
            self._initialized = True
            logger.info("✅ AI Recruitment Orchestrator initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize orchestrator: {str(e)}")
            raise
    
    async def _initialize_agents(self):
        """Initialize all specialized AI agents."""
        try:
            # Get primary LLM
            llm = self.llm_factory.create_llm_with_fallback()
            # Store for external reuse (search endpoint, health checks, etc.)
            self.llm = llm
            
            # Initialize agents
            self.resume_agent = ResumeAnalysisAgent(llm, self.settings)
            self.job_description_agent = JobDescriptionAnalysisAgent(llm, self.settings)
            # matching_agent removed - no longer needed
            self.quality_agent = QualityAssessmentAgent(llm, self.settings)
            self.reasoning_agent = ReasoningAgent(llm, self.settings)
            self.virtual_interview_agent = VirtualInterviewAgent(llm, self.settings)
            
            # Initialize each agent
            await self.resume_agent.initialize()
            await self.job_description_agent.initialize()
            # matching_agent initialization removed - no longer needed
            await self.quality_agent.initialize()
            await self.reasoning_agent.initialize()
            await self.virtual_interview_agent.initialize()
            
            logger.info("✅ All specialized agents initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize agents: {str(e)}")
            raise
    
    def _build_workflow_graph(self):
        """Build LangGraph workflow for orchestrating agents."""
        try:
            # Create workflow graph
            workflow = StateGraph(AgentState)
            
            # Add nodes for each agent
            workflow.add_node("resume_analysis", self._resume_analysis_node)
            workflow.add_node("duplicate_detection", self._duplicate_detection_node)
            workflow.add_node("quality_assessment", self._quality_assessment_node)
            workflow.add_node("save_resume", self._save_resume_node)
            workflow.add_node("reasoning", self._reasoning_node)
            workflow.add_node("finalize", self._finalize_node)
            
            # Define workflow edges
            workflow.set_entry_point("resume_analysis")
            
            # Resume analysis -> Duplicate detection
            workflow.add_edge("resume_analysis", "duplicate_detection")
            
            # Duplicate detection -> Quality assessment
            workflow.add_edge("duplicate_detection", "quality_assessment")
            
            # Quality assessment -> Save resume
            workflow.add_edge("quality_assessment", "save_resume")
            
            # Save resume -> Reasoning (directly, no job matching)
            workflow.add_edge("save_resume", "reasoning")
            
            # Reasoning -> Finalize
            workflow.add_edge("reasoning", "finalize")
            
            # Finalize -> END
            workflow.add_edge("finalize", END)
            
            # Compile workflow
            self.workflow_graph = workflow.compile(
                checkpointer=self.memory_saver
                # Removed interrupt_before to allow automatic completion
            )
            
            logger.info("✅ Workflow graph built successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to build workflow graph: {str(e)}")
            raise
    
    async def process_resume(
        self,
        file_content: bytes,
        filename: str,
        user_id: str,
        organization_id: str,
        metadata: Optional[Dict] = None
    ) -> WorkflowResult:
        """
        Process a resume through the complete AI pipeline.
        
        Args:
            file_content: Binary content of the resume file
            filename: Original filename
            user_id: ID of the user uploading
            organization_id: Organization ID
            metadata: Additional metadata
            
        Returns:
            WorkflowResult with complete analysis
        """
        if not self._initialized:
            await self.initialize()
        session_id = str(uuid4())
        start_time = datetime.now(timezone.utc)
        try:
            logger.info(f"🔄 Starting resume processing: {session_id}")
            # Upload to Azure Storage unless an existing upload is provided
            upload_result = None
            if metadata and isinstance(metadata, dict) and metadata.get("existing_upload"):
                existing = metadata.get("existing_upload") or {}
                upload_result = {
                    "blob_name": existing.get("blob_name"),
                    "container": existing.get("container"),
                    "url": existing.get("url"),
                    "original_filename": filename,
                    "size": len(file_content) if file_content else None,
                    "content_type": None,
                    "upload_timestamp": datetime.now(timezone.utc).isoformat(),
                }
                logger.info("Using existing uploaded blob; skipping re-upload")
            else:
                upload_result = await self.azure_storage.upload_resume(
                    file_content, filename, user_id, metadata
                )
            # Prepare initial state
            initial_state: AgentState = {
                "session_id": session_id,
                "current_step": "start",
                "messages": [],
                "input_data": {
                    "file_content": file_content,
                    "filename": filename,
                    "user_id": user_id,
                    "organization_id": organization_id,
                    "upload_result": upload_result,
                    "metadata": metadata or {}
                },
                "results": {},
                "errors": [],
                "metadata": {
                    "workflow_type": "resume_processing",
                    "started_at": start_time.isoformat()
                },
                "confidence_scores": {}
            }
            # Track session
            self.active_sessions[session_id] = {
                "type": "resume_processing",
                "started_at": start_time,
                "status": "running"
            }
            # Execute workflow
            config = {"configurable": {"thread_id": session_id}}
            result_state = await self.workflow_graph.ainvoke(
                initial_state,
                config=config
            )
            # Calculate execution time
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            # Build result
            workflow_result = WorkflowResult(
                session_id=session_id,
                workflow_type="resume_processing",
                status="success" if not result_state.get("errors") else "partial",
                results=result_state.get("results", {}),
                errors=result_state.get("errors", []),
                execution_time=execution_time,
                agent_metadata=result_state.get("metadata", {}),
                confidence_score=self._calculate_overall_confidence(
                    result_state.get("confidence_scores", {})
                )
            )
            # Update session
            self.active_sessions[session_id]["status"] = "completed"
            self.active_sessions[session_id]["completed_at"] = datetime.now(timezone.utc)
            logger.info(f"✅ Resume processing completed: {session_id}")
            # Index resume embedding in vector store when analysis is available
            # Allow caller to request skipping this step (e.g., Celery task does it once centrally)
            try:
                should_skip_vs = bool((metadata or {}).get("skip_vector_upsert"))
                if (not should_skip_vs) and self.vector_store and "analysis" in result_state.get("results", {}):
                    analysis = result_state["results"]["analysis"]
                    # Create a searchable text using existing agent extraction approach
                    personal = analysis.get("personal_info", {})
                    career = analysis.get("career_analysis", {})
                    skills = analysis.get("skills_analysis", {})
                    education = analysis.get("education_analysis", {})
                    text_parts = []
                    if personal.get("full_name"):
                        text_parts.append(str(personal.get("full_name")))
                    if career.get("current_position"):
                        text_parts.append(str(career.get("current_position")))
                    if career.get("current_company"):
                        text_parts.append(str(career.get("current_company")))
                    tech_skills = skills.get("technical_skills") or []
                    soft_skills = skills.get("soft_skills") or []
                    if isinstance(tech_skills, list):
                        text_parts.extend([str(s) for s in tech_skills])
                    if isinstance(soft_skills, list):
                        text_parts.extend([str(s) for s in soft_skills])
                    if education.get("highest_degree"):
                        text_parts.append(str(education.get("highest_degree")))
                    searchable_text = " ".join(text_parts)[:10000]
                    # Metadata for filtering
                    metadata = {
                        "organization_id": result_state["input_data"].get("organization_id"),
                        "candidate_email": personal.get("email"),
                        "candidate_name": personal.get("full_name"),
                        "current_position": career.get("current_position"),
                        "current_company": career.get("current_company"),
                    }
                    # The DB row id is not known here yet; the API layer will persist DB and use that id.
                    # Use session_id as temporary point id; API will upsert again with DB id after commit.
                    await self.vector_store.upsert_resume_embedding(
                        resume_id=session_id,
                        text=searchable_text or analysis.get("processing_metadata", {}).get("raw_text", ""),
                        metadata=metadata,
                    )
            except Exception as e:
                logger.warning(f"⚠️ Vector indexing skipped/failed: {e}")

            return workflow_result 
        except Exception as e:
            logger.error(f"❌ Resume processing failed: {str(e)}")
            # Update session with error
            if session_id in self.active_sessions:
                self.active_sessions[session_id]["status"] = "failed"
                self.active_sessions[session_id]["error"] = str(e)
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            return WorkflowResult(
                session_id=session_id,
                workflow_type="resume_processing",
                status="failed",
                results={},
                errors=[str(e)],
                execution_time=execution_time,
                agent_metadata={},
                confidence_score=0.0
            )
    
    async def match_candidates_to_job(
        self,
        job_id: str,
        resume_ids: Optional[List[str]] = None,
        organization_id: str = "",
        custom_weights: Optional[Dict] = None
    ) -> WorkflowResult:
        """
        Match candidates to a specific job using AI agents.
        
        Args:
            job_id: ID of the job to match against
            resume_ids: Optional list of specific resume IDs
            organization_id: Organization ID
            custom_weights: Custom matching weights
            
        Returns:
            WorkflowResult with matching results
        """
        if not self._initialized:
            await self.initialize()
        
        session_id = str(uuid4())
        start_time = datetime.now(timezone.utc)
        
        try:
            logger.info(f"🔄 Starting job matching: {session_id}")
            
            # Prepare initial state
            initial_state: AgentState = {
                "session_id": session_id,
                "current_step": "job_matching",
                "messages": [],
                "input_data": {
                    "job_id": job_id,
                    "resume_ids": resume_ids,
                    "organization_id": organization_id,
                    "custom_weights": custom_weights or {}
                },
                "results": {},
                "errors": [],
                "metadata": {
                    "workflow_type": "job_matching",
                    "started_at": start_time.isoformat()
                },
                "confidence_scores": {}
            }
            
            # Job matching workflow removed - no longer needed
            result = {"error": "Job matching workflow has been removed"}
            
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            
            workflow_result = WorkflowResult(
                session_id=session_id,
                workflow_type="job_matching",
                status="success",
                results=result,
                errors=[],
                execution_time=execution_time,
                agent_metadata={"matching_agent": "JobMatchingAgent"},
                confidence_score=result.get("confidence_score", 0.8)
            )
            
            logger.info(f"✅ Job matching completed: {session_id}")
            return workflow_result
            
        except Exception as e:
            logger.error(f"❌ Job matching failed: {str(e)}")
            
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            
            return WorkflowResult(
                session_id=session_id,
                workflow_type="job_matching",
                status="failed",
                results={},
                errors=[str(e)],
                execution_time=execution_time,
                agent_metadata={},
                confidence_score=0.0
            )
    
    async def process_job_description(
        self,
        job_description_text: str,
        job_title: Optional[str] = None,
        user_id: str = "",
        organization_id: str = "",
        metadata: Optional[Dict] = None
    ) -> WorkflowResult:
        """
        Process a job description through AI analysis.
        
        Args:
            job_description_text: The job description text to analyze
            job_title: Optional job title
            user_id: ID of the user creating the job
            organization_id: Organization ID
            metadata: Additional metadata
            
        Returns:
            WorkflowResult with comprehensive job analysis
        """
        if not self._initialized:
            await self.initialize()
        
        session_id = str(uuid4())
        start_time = datetime.now(timezone.utc)
        
        try:
            logger.info(f"🔍 Starting job description analysis: {session_id}")
            logger.info(f"📄 Job description length: {len(job_description_text)} characters")
            
            # Track session
            self.active_sessions[session_id] = {
                "type": "job_description_analysis",
                "status": "processing",
                "start_time": start_time,
                "metadata": metadata or {}
            }
            
            # Analyze job description using specialized agent
            analysis_result = await self.job_description_agent.analyze_job_description(
                job_description_text=job_description_text,
                job_title=job_title,
                company_info=metadata.get("company_info") if metadata else None,
                metadata=metadata
            )
            
            # Convert Pydantic model to dict for storage
            analysis_dict = analysis_result.model_dump()
            
            # Prepare comprehensive result
            result = {
                "analysis": analysis_dict,
                "job_description_text": job_description_text,
                "job_title": job_title,
                "metadata": {
                    "user_id": user_id,
                    "organization_id": organization_id,
                    "session_id": session_id,
                    "processing_timestamp": datetime.now(timezone.utc).isoformat(),
                    **(metadata or {})
                },
                "agent_metadata": {
                    "job_description_agent": "JobDescriptionAnalysisAgent",
                    "llm_provider": self.settings.get_llm_config()["provider"],
                    "analysis_version": "1.0"
                }
            }
            
            # Update session status
            self.active_sessions[session_id]["status"] = "completed"
            
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            
            workflow_result = WorkflowResult(
                session_id=session_id,
                workflow_type="job_description_analysis",
                status="success",
                results=result,
                errors=[],
                execution_time=execution_time,
                agent_metadata={"job_description_agent": "JobDescriptionAnalysisAgent"},
                confidence_score=analysis_result.confidence_score
            )
            
            logger.info(f"✅ Job description analysis completed: {session_id}")
            logger.info(f"📊 Confidence Score: {analysis_result.confidence_score:.2f}")
            logger.info(f"⏱️ Processing Time: {execution_time:.2f} seconds")
            
            return workflow_result
            
        except Exception as e:
            logger.error(f"❌ Job description analysis failed: {str(e)}")
            
            # Update session status
            if session_id in self.active_sessions:
                self.active_sessions[session_id]["status"] = "failed"
            
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            
            return WorkflowResult(
                session_id=session_id,
                workflow_type="job_description_analysis",
                status="failed",
                results={},
                errors=[str(e)],
                execution_time=execution_time,
                agent_metadata={},
                confidence_score=0.0
            )
    
    # Workflow node implementations
    async def _resume_analysis_node(self, state: AgentState) -> AgentState:
        """Resume analysis workflow node."""
        try:
            logger.info(f"🔍 Executing resume analysis: {state['session_id']}")
            file_content = state["input_data"]["file_content"]
            filename = state["input_data"]["filename"]
            # Analyze resume using specialized agent
            analysis_result = await self.resume_agent.analyze_resume(
                file_content, filename
            )
            # Update state
            state["results"]["resume_analysis"] = analysis_result
            state["confidence_scores"]["resume_analysis"] = analysis_result.get("confidence", 0.8)
            state["current_step"] = "resume_analysis_completed"
            logger.info(f"✅ Resume analysis completed: {state['session_id']}")
            return state
        except Exception as e:
            logger.error(f"❌ Resume analysis failed: {str(e)}")
            state["errors"].append(f"Resume analysis error: {str(e)}")
            return state
    
    async def _duplicate_detection_node(self, state: AgentState) -> AgentState:
        """Duplicate detection workflow node."""
        try:
            logger.info(f"🔍 Executing duplicate detection: {state['session_id']}")
            
            # Get resume analysis results
            resume_analysis = state["results"].get("resume_analysis", {})
            personal_info = resume_analysis.get("personal_info", {})
            
            # Extract email and phone from analysis
            email = personal_info.get("email")
            phone = personal_info.get("phone")
            organization_id = state["input_data"]["organization_id"]
            
            # Perform duplicate detection
            duplicate_result = await duplicate_detection_service.detect_duplicates(
                email=email,
                phone=phone,
                organization_id=organization_id
            )
            
            # Update state with duplicate detection results
            state["results"]["duplicate_detection"] = {
                "is_duplicate": duplicate_result.is_duplicate,
                "confidence_score": duplicate_result.confidence_score,
                "matches": [match.dict() for match in duplicate_result.matches],
                "normalized_contact": duplicate_result.normalized_contact.dict(),
                "reasoning": duplicate_result.reasoning,
                "action_recommended": duplicate_result.action_recommended
            }
            
            state["confidence_scores"]["duplicate_detection"] = duplicate_result.confidence_score
            state["current_step"] = "duplicate_detection_completed"
            
            # Log results
            if duplicate_result.is_duplicate:
                logger.warning(f"⚠️ Duplicate detected with confidence {duplicate_result.confidence_score:.2f}: {state['session_id']}")
                logger.info(f"🔍 Duplicate reasoning: {duplicate_result.reasoning}")
            else:
                logger.info(f"✅ No duplicates found: {state['session_id']}")
            
            return state
            
        except Exception as e:
            logger.error(f"❌ Duplicate detection failed: {str(e)}")
            # Don't fail the entire workflow for duplicate detection errors
            state["results"]["duplicate_detection"] = {
                "is_duplicate": False,
                "confidence_score": 0.0,
                "matches": [],
                "normalized_contact": {"email": None, "phone": None},
                "reasoning": f"Duplicate detection failed: {str(e)}",
                "action_recommended": "proceed"
            }
            state["confidence_scores"]["duplicate_detection"] = 0.0
            state["errors"].append(f"Duplicate detection error: {str(e)}")
            return state
    
    async def _quality_assessment_node(self, state: AgentState) -> AgentState:
        """Quality assessment workflow node."""
        try:
            logger.info(f"📊 Executing quality assessment: {state['session_id']}")
            await asyncio.sleep(15)  # Increased delay to reduce rate limiting
            resume_analysis = state["results"].get("resume_analysis", {})
            
            # Create lightweight resume data for quality assessment (STRICTLY exclude extracted_text)
            analysis_data = resume_analysis.get("analysis", {})
            original_size = len(str(resume_analysis))
            
            # Explicitly filter out extracted_text from all nested data
            def remove_extracted_text(data):
                """Recursively remove extracted_text from any nested dictionary."""
                if isinstance(data, dict):
                    filtered = {}
                    for key, value in data.items():
                        if key != "extracted_text":
                            filtered[key] = remove_extracted_text(value)
                    return filtered
                elif isinstance(data, list):
                    return [remove_extracted_text(item) for item in data]
                else:
                    return data
            
            # Create lightweight data with explicit filtering
            lightweight_resume_data = {
                "personal_info": remove_extracted_text(analysis_data.get("personal_info", {})),
                "career_analysis": remove_extracted_text(analysis_data.get("career_analysis", {})),
                "skills_analysis": remove_extracted_text(analysis_data.get("skills_analysis", {})),
                "education_analysis": remove_extracted_text(analysis_data.get("education_analysis", {})),
                "quality_assessment": remove_extracted_text(analysis_data.get("quality_assessment", {})),
                "metadata": {
                    "filename": resume_analysis.get("metadata", {}).get("filename", "unknown"),
                    "processing_time": resume_analysis.get("metadata", {}).get("processing_time", 0),
                    "extracted_text_length": resume_analysis.get("metadata", {}).get("extracted_text_length", 0),
                    # STRICTLY NO extracted_text - only length for reference
                }
            }
            
            # Double-check: ensure no extracted_text exists anywhere
            lightweight_str = str(lightweight_resume_data)
            if "extracted_text" in lightweight_str:
                logger.error("❌ CRITICAL: extracted_text found in lightweight data - removing immediately!")
                lightweight_resume_data = remove_extracted_text(lightweight_resume_data)
            
            optimized_size = len(str(lightweight_resume_data))
            reduction_percent = ((original_size - optimized_size) / original_size) * 100 if original_size > 0 else 0
            logger.info(f"📊 Token optimization: {original_size:,} -> {optimized_size:,} chars ({reduction_percent:.1f}% reduction)")
            
            # Assess quality using specialized agent with lightweight data
            quality_result = await self.quality_agent.assess_resume_quality(
                lightweight_resume_data
            )
            logger.info("⏳ Waiting 10 seconds after quality assessment AI call...")
            await asyncio.sleep(10)  # Increased delay after AI call
            # Update state
            state["results"]["quality_assessment"] = quality_result
            state["confidence_scores"]["quality_assessment"] = quality_result.get("confidence", 0.8)
            state["current_step"] = "quality_assessment_completed"
            
            logger.info(f"✅ Quality assessment completed: {state['session_id']}")
            logger.info(f"🔍 Quality assessment scores: {quality_result.get('overall_score', 0.0)}")
            return state
            
        except Exception as e:
            logger.error(f"❌ Quality assessment failed: {str(e)}")
            state["errors"].append(f"Quality assessment error: {str(e)}")
            return state
    
    # Job matching node removed - no longer needed
    async def _job_matching_node_removed(self, state: AgentState) -> AgentState:
        """Job matching workflow node using vector search."""
        try:
            logger.info(f"🎯 Executing job matching: {state['session_id']}")
            
            # Get resume data from state
            resume_analysis = state["results"].get("resume_analysis", {})
            input_data = state["input_data"]
            resume_id = input_data.get("resume_id")
            organization_id = input_data.get("organization_id")
            
            # Check if job matching has already been completed for this resume
            if resume_id:
                await db_manager.initialize()
                with db_manager.sync_session_context() as session:
                    existing_matches = session.execute(
                        select(JobMatch).where(JobMatch.resume_id == resume_id)
                    ).scalars().all()
                    
                    if existing_matches:
                        logger.info(f"✅ Job matching already completed for resume {resume_id} - {len(existing_matches)} matches found")
                        matching_result = {
                            "matches": [{
                                "job_id": match.job_id,
                                "overall_score": match.overall_score,
                                "skills_score": match.skills_score,
                                "experience_score": match.experience_score,
                                "education_score": match.education_score,
                                "location_score": match.location_score,
                                "cultural_fit_score": match.cultural_fit_score,
                                "explanation": match.explanation,
                                "reasoning": match.reasoning,
                                "strengths": match.strengths or [],
                                "weaknesses": match.weaknesses or [],
                                "missing_skills": match.missing_skills or [],
                                "recommendations": match.recommendations or []
                            } for match in existing_matches],
                            "total_jobs_evaluated": len(existing_matches),
                            "matches_found": len(existing_matches),
                            "confidence": 0.8,
                            "vector_search_results": len(existing_matches),
                            "filtering_applied": "skills_score >= 0.3",
                            "status": "cached"
                        }
                        
                        state["results"]["job_matching"] = matching_result
                        state["confidence_scores"]["job_matching"] = 0.8
                        state["current_step"] = "job_matching_completed"
                        
                        logger.info(f"✅ Job matching completed (cached): {state['session_id']} - {len(existing_matches)} matches found")
                        return state
            
            if not resume_id:
                logger.warning("No resume_id found in state, skipping job matching")
                matching_result = {
                    "matches": [],
                    "total_jobs_evaluated": 0,
                    "confidence": 0.0,
                    "error": "No resume_id found"
                }
                state["results"]["job_matching"] = matching_result
                state["confidence_scores"]["job_matching"] = 0.0
                state["current_step"] = "job_matching_completed"
                return state
            
            # Extract only essential data for vector search (optimized)
            ai_analysis = resume_analysis.get("analysis", {})
            search_parts = []
            
            # Get skills data
            skills_analysis = ai_analysis.get("skills_analysis", {})
            programming_languages = skills_analysis.get("programming_languages", [])
            frameworks = skills_analysis.get("frameworks_libraries", [])
            tools = skills_analysis.get("tools_technologies", [])
            technical_skills = skills_analysis.get("technical_skills", [])
            soft_skills = skills_analysis.get("soft_skills", [])
            
            # Extract only skill names (not full objects)
            all_skills = []
            for skill_list in [programming_languages, frameworks, tools, technical_skills, soft_skills]:
                if isinstance(skill_list, list):
                    for skill in skill_list:
                        if isinstance(skill, dict) and skill.get("skill"):
                            all_skills.append(skill["skill"])
                        elif isinstance(skill, str):
                            all_skills.append(skill)
            
            # Build focused search text
            if all_skills:
                search_parts.append(f"Skills: {', '.join(all_skills[:20])}")  # Limit to top 20 skills
            
            # Add current position and experience
            career_analysis = ai_analysis.get("career_analysis", {})
            if career_analysis.get("current_position"):
                search_parts.append(f"Current Role: {career_analysis['current_position']}")
            
            if career_analysis.get("total_years_experience"):
                search_parts.append(f"Experience: {career_analysis['total_years_experience']} years")
            
            # Add education level
            education_analysis = ai_analysis.get("education_analysis", {})
            if education_analysis.get("highest_degree"):
                search_parts.append(f"Education: {education_analysis['highest_degree']}")
            
            # Add location if available
            personal_info = ai_analysis.get("personal_info", {})
            if personal_info.get("location"):
                search_parts.append(f"Location: {personal_info['location']}")
            
            # Create focused search text
            resume_text = " | ".join(search_parts)
            
            if not resume_text.strip():
                logger.warning("No valid resume data for matching")
                matching_result = {
                    "matches": [],
                    "total_jobs_evaluated": 0,
                    "confidence": 0.0,
                    "error": "No valid resume data for matching"
                }
                state["results"]["job_matching"] = matching_result
                state["confidence_scores"]["job_matching"] = 0.0
                state["current_step"] = "job_matching_completed"
                return state
            
            # Perform vector search for relevant jobs (get more results for better matching)
            try:
                vector_search_results = await self.vector_store.search_jobs(
                    query_text=resume_text,
                    top_k=20,  # Get more jobs for better selection
                    org_id=str(organization_id)
                )
                
                if not vector_search_results:
                    logger.info("No similar jobs found via vector search")
                    matching_result = {
                        "matches": [],
                        "total_jobs_evaluated": 0,
                        "confidence": 0.0,
                        "error": "No similar jobs found via vector search"
                    }
                    state["results"]["job_matching"] = matching_result
                    state["confidence_scores"]["job_matching"] = 0.0
                    state["current_step"] = "job_matching_completed"
                    return state
                
                # Get job IDs from vector search results
                job_ids = []
                for result in vector_search_results:
                    job_id = result.payload.get("job_id")
                    if job_id:
                        job_ids.append(job_id)
                
                if not job_ids:
                    logger.warning("No valid job IDs found in vector search results")
                    matching_result = {
                        "matches": [],
                        "total_jobs_evaluated": 0,
                        "confidence": 0.0,
                        "error": "No valid job IDs found in vector search results"
                    }
                    state["results"]["job_matching"] = matching_result
                    state["confidence_scores"]["job_matching"] = 0.0
                    state["current_step"] = "job_matching_completed"
                    return state
                
                # Fetch only the relevant jobs from database
                await db_manager.initialize()
                with db_manager.sync_session_context() as session:
                    jobs_result = session.execute(
                        select(Job).where(
                            Job.id.in_(job_ids),
                            Job.organization_id == organization_id,
                            Job.status == "ACTIVE"
                        )
                    )
                    relevant_jobs = jobs_result.scalars().all()
                
                logger.info(f"🔍 Vector search found {len(relevant_jobs)} relevant jobs (from {len(job_ids)} vector results)")
                
                if not relevant_jobs:
                    logger.warning("No active jobs found matching vector search criteria")
                    matching_result = {
                        "matches": [],
                        "total_jobs_evaluated": 0,
                        "confidence": 0.0,
                        "error": "No active jobs found matching vector search criteria"
                    }
                    state["results"]["job_matching"] = matching_result
                    state["confidence_scores"]["job_matching"] = 0.0
                    state["current_step"] = "job_matching_completed"
                    return state
                
                # Simple and efficient job matching with multi-factor scoring
                job_matches = []
                candidate_skills = set(str(skill).lower() for skill in (all_skills if 'all_skills' in locals() else []))
                candidate_experience = career_analysis.get("total_years_experience", 0) or 0
                candidate_location = personal_info.get("location", "")
                
                logger.info(f"🔍 Candidate profile - Skills: {len(candidate_skills)}, Experience: {candidate_experience} years, Location: {candidate_location}")
                
                def calculate_enhanced_skills_similarity(candidate_skills, job_skills):
                    """Calculate enhanced skills similarity using fuzzy matching and semantic analysis."""
                    if not job_skills:
                        return 0.5
                    
                    def normalize_skill(skill):
                        """Normalize skill for better matching."""
                        return skill.lower().strip().replace('&', 'and').replace('-', ' ').replace('_', ' ').replace('(', '').replace(')', '')
                    
                    def calculate_similarity(skill1, skill2):
                        """Calculate similarity between two skills using multiple methods."""
                        s1 = normalize_skill(skill1)
                        s2 = normalize_skill(skill2)
                        
                        # Exact match
                        if s1 == s2:
                            return 1.0
                        
                        # Check if one skill contains the other
                        if s1 in s2 or s2 in s1:
                            return 0.9
                        
                        # Word-level similarity
                        words1 = set(s1.split())
                        words2 = set(s2.split())
                        
                        if not words1 or not words2:
                            return 0.0
                        
                        # Jaccard similarity (intersection over union)
                        intersection = words1.intersection(words2)
                        union = words1.union(words2)
                        jaccard_sim = len(intersection) / len(union) if union else 0.0
                        
                        # Check for significant word overlap
                        if len(intersection) >= 1:
                            word_overlap_ratio = len(intersection) / min(len(words1), len(words2))
                            if word_overlap_ratio >= 0.5:  # 50% word overlap
                                return max(jaccard_sim, 0.7)
                            elif word_overlap_ratio >= 0.3:  # 30% word overlap
                                return max(jaccard_sim, 0.5)
                            elif word_overlap_ratio >= 0.1:  # 10% word overlap
                                return max(jaccard_sim, 0.3)
                        
                        # Check for common prefixes/suffixes
                        if s1.startswith(s2[:3]) or s2.startswith(s1[:3]):
                            return 0.4
                        
                        return jaccard_sim
                    
                    def find_best_match(job_skill, candidate_skills):
                        """Find the best matching candidate skill for a job skill."""
                        best_match = None
                        best_score = 0.0
                        
                        for candidate_skill in candidate_skills:
                            similarity = calculate_similarity(job_skill, candidate_skill)
                            if similarity > best_score:
                                best_score = similarity
                                best_match = candidate_skill
                        
                        return best_match, best_score
                    
                    # Calculate matches for each job skill
                    total_score = 0.0
                    matches_found = 0
                    
                    for job_skill in job_skills:
                        best_match, similarity_score = find_best_match(job_skill, candidate_skills)
                        
                        if similarity_score >= 0.7:  # High similarity threshold
                            total_score += 1.0
                            matches_found += 1
                            logger.info(f"✅ High match: '{job_skill}' ≈ '{best_match}' ({similarity_score:.2f})")
                        elif similarity_score >= 0.5:  # Medium similarity threshold
                            total_score += 0.7
                            matches_found += 1
                            logger.info(f"🎯 Medium match: '{job_skill}' ~ '{best_match}' ({similarity_score:.2f})")
                        elif similarity_score >= 0.3:  # Low similarity threshold
                            total_score += 0.4
                            matches_found += 1
                            logger.info(f"🔍 Low match: '{job_skill}' ~ '{best_match}' ({similarity_score:.2f})")
                        else:
                            logger.info(f"❌ No match: '{job_skill}' (best: {best_match} @ {similarity_score:.2f})")
                    
                    # Calculate final score
                    skills_score = total_score / len(job_skills) if job_skills else 0.0
                    skills_score = min(skills_score, 1.0)  # Cap at 100%
                    
                    logger.info(f"📊 Skills matching: {matches_found}/{len(job_skills)} skills matched, score: {skills_score:.2f}")
                    
                    return skills_score
                
                def calculate_simple_match_score(candidate_skills, candidate_experience, candidate_location, job):
                    """Calculate simple match score based on multiple factors."""
                    score = 0
                    
                    # Enhanced skills match (40% weight) with semantic similarity
                    job_skills = set(str(skill).lower() for skill in (job.required_skills or []))
                    if job_skills:
                        skills_score = calculate_enhanced_skills_similarity(candidate_skills, job_skills)
                    else:
                        skills_score = 0.5  # Default if no required skills
                    score += skills_score * 0.4
                    
                    # Experience match (30% weight)
                    min_exp = job.min_years_experience or 0
                    max_exp = job.max_years_experience or 10
                    if candidate_experience >= min_exp:
                        if max_exp > min_exp:
                            exp_score = min((candidate_experience - min_exp) / (max_exp - min_exp), 1.0)
                        else:
                            exp_score = 1.0
                    else:
                        exp_score = candidate_experience / max(min_exp, 1)
                    score += exp_score * 0.3
                    
                    # Location match (20% weight)
                    if job.remote_option in ["hybrid", "full"] or not job.location:
                        location_score = 1.0  # Remote work or no location requirement
                    elif candidate_location and job.location:
                        if candidate_location.lower() in job.location.lower() or job.location.lower() in candidate_location.lower():
                            location_score = 1.0
                        else:
                            location_score = 0.3  # Different location
                    else:
                        location_score = 0.5  # Unknown location
                    score += location_score * 0.2
                    
                    # Education match (10% weight)
                    education_score = 0.8  # Default good score
                    score += education_score * 0.1
                    
                    return min(score, 1.0)  # Cap at 100%
                
                # Calculate scores for all jobs and filter by skills score >= 30%
                job_scores = []
                for job in relevant_jobs:
                    try:
                        job_skills = set(str(skill).lower() for skill in (job.required_skills or []))
                        enhanced_skills_score = calculate_enhanced_skills_similarity(candidate_skills, job_skills)
                        
                        # Only consider jobs with skills score >= 30%
                        if enhanced_skills_score < 0.3:
                            logger.info(f"❌ Job {job.title} filtered out: skills_score={enhanced_skills_score:.2f} (< 30%)")
                            continue
                        
                        match_score = calculate_simple_match_score(
                            candidate_skills, candidate_experience, candidate_location, job
                        )
                        
                        job_match = {
                            "job_id": str(job.id),
                            "job_title": job.title,
                            "job_location": job.location or "",
                            "job_department": job.department or "",
                            "job_employment_type": job.employment_type or "",
                            "job_remote_option": job.remote_option in ["hybrid", "full"],
                            "overall_score": match_score,
                            "skills_score": enhanced_skills_score,
                            "experience_score": min(candidate_experience / max(job.min_years_experience or 1, 1), 1.0),
                            "location_score": 1.0 if (job.remote_option in ["hybrid", "full"] or not job.location) else 0.5,
                            "explanation": f"Match: {match_score:.1%} - Skills: {enhanced_skills_score:.1%}, Exp: {candidate_experience}y",
                            "reasoning": f"Enhanced skills matching with semantic similarity",
                            "strengths": [],  # Will be populated by enhanced matching
                            "weaknesses": [],  # Will be populated by enhanced matching
                            "missing_skills": [],  # Will be populated by enhanced matching
                            "recommendations": []
                        }
                        
                        job_scores.append((job_match, match_score))
                        logger.info(f"✅ Job {job.title}: {match_score:.2f} - Skills: {enhanced_skills_score:.2f} (PASSED 30% threshold)")
                        
                    except Exception as e:
                        logger.warning(f"Failed to process job {job.title}: {e}")
                        continue
                
                # Sort by overall score and take top 20
                job_scores.sort(key=lambda x: x[1], reverse=True)
                job_matches = [match for match, score in job_scores[:20]]  # Top 20 matches
                
                logger.info(f"🎯 Found {len(job_matches)} top job matches (skills >= 30%) from {len(relevant_jobs)} vector search results")
                
                # Store job matches in database
                await self._store_job_matches_in_database(resume_id, job_matches, organization_id)
                
                matching_result = {
                    "matches": job_matches,
                    "total_jobs_evaluated": len(relevant_jobs),
                    "matches_found": len(job_matches),
                    "confidence": 0.8 if job_matches else 0.0,
                    "vector_search_results": len(vector_search_results),
                    "filtering_applied": "top_20_multi_factor_scoring_with_30_percent_skills_threshold",
                    "search_optimization": "focused_data_only"
                }
                
            except Exception as e:
                logger.error(f"Vector search failed: {e}")
                matching_result = {
                    "matches": [],
                    "total_jobs_evaluated": 0,
                    "confidence": 0.0,
                    "error": f"Vector search failed: {str(e)}"
            }
            
            # Update state
            state["results"]["job_matching"] = matching_result
            state["confidence_scores"]["job_matching"] = matching_result.get("confidence", 0.0)
            state["current_step"] = "job_matching_completed"
            
            logger.info(f"✅ Job matching completed: {state['session_id']} - {len(matching_result.get('matches', []))} matches found")
            return state
            
        except Exception as e:
            logger.error(f"❌ Job matching failed: {str(e)}")
            state["errors"].append(f"Job matching error: {str(e)}")
            return state
    
    async def _store_job_matches_in_database(self, resume_id: str, job_matches: List[Dict], organization_id: str):
        """Store job matches in the database."""
        try:
            if not job_matches:
                logger.info("No job matches to store")
                return
            
            await db_manager.initialize()
            with db_manager.sync_session_context() as session:
                # Delete existing matches for this resume
                existing_matches = session.execute(
                    select(JobMatch).where(JobMatch.resume_id == resume_id)
                ).scalars().all()
                for match in existing_matches:
                    session.delete(match)
                
                # Store new matches
                for i, match in enumerate(job_matches):
                    job_match = JobMatch(
                        job_id=match.get("job_id"),
                        resume_id=resume_id,
                        overall_score=match.get("overall_score", 0.0),
                        confidence_level=0.8,  # Default confidence for simple matching
                        skills_score=match.get("skills_score", 0.0),
                        experience_score=match.get("experience_score", 0.0),
                        education_score=match.get("education_score", 0.0),
                        location_score=match.get("location_score", 0.0),
                        cultural_fit_score=match.get("cultural_fit_score", 0.0),
                        matching_analysis=match.get("matching_analysis", {}),
                        strengths=match.get("strengths", []),
                        weaknesses=match.get("weaknesses", []),
                        missing_skills=match.get("missing_skills", []),
                        recommendations=match.get("recommendations", []),
                        explanation=match.get("explanation", ""),
                        reasoning=match.get("reasoning", ""),
                        rank_in_job=i + 1,
                        status="completed",
                        matching_agent_version="2.0",
                        llm_provider_used=getattr(self.settings, 'llm_provider', 'azure'),
                        matching_algorithm="vector_search_ai_analysis",
                        weights_used={"skills": 0.4, "experience": 0.3, "education": 0.2, "location": 0.1}
                    )
                    session.add(job_match)
                
                session.commit()
                logger.info(f"✅ Stored {len(job_matches)} job matches in database for resume {resume_id}")
                
        except Exception as e:
            logger.error(f"❌ Failed to store job matches: {str(e)}")
            raise
    
    async def _save_resume_node(self, state: AgentState) -> AgentState:
        """Save or update resume in database and get resume ID for job matching."""
        try:
            logger.info(f"💾 Saving/updating resume in database: {state['session_id']}")
            
            # Get input data
            input_data = state["input_data"]
            file_content = input_data["file_content"]
            filename = input_data["filename"]
            user_id = input_data["user_id"]
            organization_id = input_data["organization_id"]
            upload_result = input_data["upload_result"]
            
            # Get analysis results
            resume_analysis = state["results"].get("resume_analysis", {})
            duplicate_detection = state["results"].get("duplicate_detection", {})
            quality_assessment = state["results"].get("quality_assessment", {})
            
            # Initialize database
            await db_manager.initialize()
            
            with db_manager.sync_session_context() as session:
                # Check if resume already exists (from upload API)
                # Use first() instead of scalar_one_or_none() to handle potential duplicates
                blob_name = upload_result.get("blob_name")
                logger.info(f"🔍 Looking for existing resume with blob_name: {blob_name}, org_id: {organization_id}")
                
                existing_resume = session.execute(
                    select(Resume).where(
                        Resume.azure_blob_name == blob_name,
                        Resume.organization_id == organization_id
                    ).order_by(Resume.created_at.desc())  # Get the most recent one
                ).scalars().first()
                
                if existing_resume:
                    logger.info(f"✅ Found existing resume: {existing_resume.id} (created: {existing_resume.created_at})")
                else:
                    logger.info("ℹ️ No existing resume found, will create new one")
                
                if existing_resume:
                    # Update existing resume (status will be updated in finalize node)
                    logger.info(f"📝 Updating existing resume: {existing_resume.id}")
                    # Note: Status will be updated to "analyzed" in the finalize node after job matching
                    
                    # Get extracted text from metadata or use empty string
                    extracted_text = ""
                    if "metadata" in resume_analysis and "extracted_text" in resume_analysis["metadata"]:
                        extracted_text = resume_analysis["metadata"]["extracted_text"]
                    existing_resume.extracted_text = extracted_text
                    
                    # Extract and store personal information in direct fields
                    personal_info = resume_analysis.get("analysis", {}).get("personal_info", {})
                    
                    # Fallback to filename if name not found in analysis
                    candidate_name = personal_info.get("full_name")
                    if not candidate_name:
                        # Extract name from filename as fallback
                        name_part = Path(filename).stem
                        name_part = re.sub(r'\s*(resume|cv|curriculum|vitae)\s*', ' ', name_part, flags=re.IGNORECASE)
                        name_part = name_part.strip()
                        name_match = re.search(r'^([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})', name_part)
                        if name_match:
                            candidate_name = name_match.group(1).strip()
                            logger.info(f"✅ Extracted name from filename: {candidate_name}")
                    
                    existing_resume.candidate_name = candidate_name
                    existing_resume.candidate_email = personal_info.get("email")
                    existing_resume.candidate_phone = personal_info.get("phone")
                    existing_resume.candidate_location = personal_info.get("location")
                    
                    existing_resume.ai_analysis = {
                        "personal_info": resume_analysis.get("analysis", {}).get("personal_info", {}),
                        "career_analysis": resume_analysis.get("analysis", {}).get("career_analysis", {}),
                        "skills_analysis": resume_analysis.get("analysis", {}).get("skills_analysis", {}),
                        "education_analysis": resume_analysis.get("analysis", {}).get("education_analysis", {}),
                        "duplicate_detection": duplicate_detection,
                        "quality_assessment": quality_assessment,
                        "overall_confidence": self._calculate_overall_confidence(state["confidence_scores"]),
                        "processing_metadata": {
                            "session_id": state["session_id"],
                            "completed_at": datetime.now(timezone.utc).isoformat(),
                            "confidence_scores": state["confidence_scores"],
                            "workflow_type": "resume_processing"
                        }
                    }
                    existing_resume.processing_confidence = self._calculate_overall_confidence(state["confidence_scores"])
                    
                    session.commit()
                    session.refresh(existing_resume)
                    
                    # Add resume_id to state for job matching
                    state["input_data"]["resume_id"] = str(existing_resume.id)
                    logger.info(f"✅ Resume updated in database with ID: {existing_resume.id}")
                    
                else:
                    # Create new resume record (for direct orchestrator calls)
                    logger.info(f"📝 Creating new resume record")
                    
                    # Get extracted text from metadata or use empty string
                    extracted_text = ""
                    if "metadata" in resume_analysis and "extracted_text" in resume_analysis["metadata"]:
                        extracted_text = resume_analysis["metadata"]["extracted_text"]
                    
                    # Extract and store personal information in direct fields
                    personal_info = resume_analysis.get("analysis", {}).get("personal_info", {})
                    
                    # Fallback to filename if name not found in analysis
                    candidate_name = personal_info.get("full_name")
                    if not candidate_name:
                        # Extract name from filename as fallback
                        name_part = Path(filename).stem
                        name_part = re.sub(r'\s*(resume|cv|curriculum|vitae)\s*', ' ', name_part, flags=re.IGNORECASE)
                        name_part = name_part.strip()
                        name_match = re.search(r'^([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})', name_part)
                        if name_match:
                            candidate_name = name_match.group(1).strip()
                            logger.info(f"✅ Extracted name from filename: {candidate_name}")
                    
                    resume_record = Resume(
                        organization_id=organization_id,
                        original_filename=filename,
                        azure_blob_name=upload_result.get("blob_name"),
                        azure_container=upload_result.get("container", "resumes"),
                        azure_url=upload_result.get("url"),
                        file_size=len(file_content),
                        status="processing",  # Will be updated to "analyzed" in finalize node
                        extracted_text=extracted_text,
                        candidate_name=candidate_name,
                        candidate_email=personal_info.get("email"),
                        candidate_phone=personal_info.get("phone"),
                        candidate_location=personal_info.get("location"),
                        ai_analysis={
                            "personal_info": resume_analysis.get("analysis", {}).get("personal_info", {}),
                            "career_analysis": resume_analysis.get("analysis", {}).get("career_analysis", {}),
                            "skills_analysis": resume_analysis.get("analysis", {}).get("skills_analysis", {}),
                            "education_analysis": resume_analysis.get("analysis", {}).get("education_analysis", {}),
                            "duplicate_detection": duplicate_detection,
                            "quality_assessment": quality_assessment,
                            "overall_confidence": self._calculate_overall_confidence(state["confidence_scores"]),
                            "processing_metadata": {
                                "session_id": state["session_id"],
                                "completed_at": datetime.now(timezone.utc).isoformat(),
                                "confidence_scores": state["confidence_scores"],
                                "workflow_type": "resume_processing"
                            }
                        }
                    )
                    
                    session.add(resume_record)
                    session.commit()
                    session.refresh(resume_record)
                    
                    # Add resume_id to state for job matching
                    state["input_data"]["resume_id"] = str(resume_record.id)
                    logger.info(f"✅ Resume created in database with ID: {resume_record.id}")
            
            state["current_step"] = "resume_saved"
            return state
            
        except Exception as e:
            logger.error(f"❌ Failed to save/update resume in database: {str(e)}")
            state["errors"].append(f"Resume save error: {str(e)}")
            return state
    
    async def _reasoning_node(self, state: AgentState) -> AgentState:
        """Reasoning and explanation workflow node."""
        try:
            logger.info(f"🧠 Executing reasoning: {state['session_id']}")
            
            # Generate comprehensive reasoning using specialized agent
            reasoning_result = await self.reasoning_agent.generate_reasoning(
                state["results"]
            )
            
            # Generate markdown summary of reasoning for storage
            try:
                reasoning_markdown = await self._generate_reasoning_markdown(reasoning_result)
                # Store the markdown in the analysis results for database storage
                if "resume_analysis" in state["results"] and "analysis" in state["results"]["resume_analysis"]:
                    analysis = state["results"]["resume_analysis"]["analysis"]
                    if "agent_raw_outputs" not in analysis:
                        analysis["agent_raw_outputs"] = {}
                    analysis["agent_raw_outputs"]["reasoning_markdown"] = reasoning_markdown
                logger.info("⏳ Waiting 5 seconds after reasoning AI call...")
                await asyncio.sleep(5)
            except Exception as e:
                logger.warning(f"Failed to generate reasoning markdown: {e}")
            
            # Update state
            state["results"]["reasoning"] = reasoning_result
            state["confidence_scores"]["reasoning"] = reasoning_result.get("confidence", 0.8)
            state["current_step"] = "reasoning_completed"
            
            logger.info(f"✅ Reasoning completed: {state['session_id']}")
            return state
            
        except Exception as e:
            logger.error(f"❌ Reasoning failed: {str(e)}")
            state["errors"].append(f"Reasoning error: {str(e)}")
            return state
    
    async def _finalize_node(self, state: AgentState) -> AgentState:
        """Finalization workflow node."""
        try:
            logger.info(f"🎯 Finalizing workflow: {state['session_id']}")
            
            # Consolidate all results into a single "analysis" object
            # This is what the resume endpoint expects to find
            resume_analysis = state["results"].get("resume_analysis", {})
            resume_analysis_data = resume_analysis.get("analysis", {}) if resume_analysis else {}
            
            consolidated_analysis = {
                "personal_info": resume_analysis_data.get("personal_info", {}),
                "career_analysis": resume_analysis_data.get("career_analysis", {}),
                "skills_analysis": resume_analysis_data.get("skills_analysis", {}),
                "education_analysis": resume_analysis_data.get("education_analysis", {}),
                "duplicate_detection": state["results"].get("duplicate_detection", {}),
                "quality_assessment": state["results"].get("quality_assessment", {}),
                "reasoning": state["results"].get("reasoning", {}),
                "overall_confidence": self._calculate_overall_confidence(state["confidence_scores"]),
                # Include agent raw outputs for database storage
                "agent_raw_outputs": resume_analysis_data.get("agent_raw_outputs", {}),
                "processing_metadata": {
                    "session_id": state["session_id"],
                    "completed_at": datetime.now(timezone.utc).isoformat(),
                    "confidence_scores": state["confidence_scores"],
                    "workflow_type": "resume_processing"
                }
            }

            # Generate concise professional summary using LLM
            try:
                summary_prompt = (
                    "You are an expert technical recruiter. Based on the following analysis JSON, "
                    "write a concise, professional 3-5 sentence summary for the candidate. "
                    "Include years of experience (if present), current role/company, top core skills, "
                    "and leadership or domain strengths. Avoid first-person language. \n\n"
                    f"Analysis JSON:\n{json.dumps(consolidated_analysis, ensure_ascii=False)[:6000]}\n\n"
                    "Return ONLY the summary text, no JSON and no additional commentary."
                )
                resp = await self.llm.ainvoke(summary_prompt)
                
                # Add 5-second delay after AI call
                logger.info("⏳ Waiting 5 seconds after orchestrator AI call...")
                await asyncio.sleep(5)
                summary_text = (resp.content or "").strip()
                if summary_text:
                    consolidated_analysis["final_summary"] = summary_text
            except Exception as _:
                # Non-blocking; summary is optional
                pass
            
            # Store consolidated analysis (this is what the endpoint expects)
            state["results"]["analysis"] = consolidated_analysis
            
            # Note: Resume status will be updated to "analyzed" after all post-workflow processing is complete
            # This includes vector indexing and any other final steps
            
            # Include Azure upload metadata for database storage
            upload_result = state["input_data"].get("upload_result", {})
            state["results"]["azure_blob_name"] = upload_result.get("blob_name", "")
            state["results"]["azure_container"] = upload_result.get("container", "")
            state["results"]["azure_url"] = upload_result.get("url", "")
            
            # Add final metadata
            state["metadata"]["completed_at"] = datetime.now(timezone.utc).isoformat()
            state["metadata"]["total_confidence"] = self._calculate_overall_confidence(
                state["confidence_scores"]
            )
            state["current_step"] = "completed"
            
            logger.info(f"✅ Workflow finalized with consolidated analysis: {state['session_id']}")
            return state
            
        except Exception as e:
            logger.error(f"❌ Finalization failed: {str(e)}")
            state["errors"].append(f"Finalization error: {str(e)}")
            return state
    
    # Job matching conditional logic removed - no longer needed
    def _should_proceed_to_matching_removed(self, state: AgentState) -> str:
        """Conditional edge logic for proceeding to job matching."""
        quality_result = state.get("results", {}).get("quality_assessment", {})
        quality_score = quality_result.get("overall_score", 0.0)
        
        # Proceed to matching if quality score is above threshold
        return "proceed" if quality_score >= 0.6 else "skip"
    
    def _calculate_overall_confidence(self, confidence_scores: Dict[str, float]) -> float:
        """Calculate overall confidence from individual agent scores."""
        if not confidence_scores:
            return 0.0
        
        # Weighted average of confidence scores
        weights = {
            "resume_analysis": 0.35,
            "duplicate_detection": 0.2,
            "quality_assessment": 0.25,
            "reasoning": 0.2
        }
        
        total_weight = 0
        weighted_sum = 0
        
        for agent, score in confidence_scores.items():
            weight = weights.get(agent, 0.1)
            weighted_sum += score * weight
            total_weight += weight
        
        return weighted_sum / total_weight if total_weight > 0 else 0.0
    
    async def _generate_reasoning_markdown(self, reasoning_result: Dict[str, Any]) -> str:
        """Generate markdown summary of reasoning analysis for storage."""
        try:
            # Create a comprehensive markdown summary of the reasoning
            markdown_parts = []
            
            markdown_parts.append("# Comprehensive Reasoning Analysis")
            markdown_parts.append("")
            
            # Overall Assessment
            if "overall_assessment" in reasoning_result:
                markdown_parts.append("## Overall Assessment")
                markdown_parts.append(str(reasoning_result["overall_assessment"]))
                markdown_parts.append("")
            
            # Key Insights
            if "key_insights" in reasoning_result and reasoning_result["key_insights"]:
                markdown_parts.append("## Key Insights")
                for insight in reasoning_result["key_insights"]:
                    markdown_parts.append(f"- {insight}")
                markdown_parts.append("")
            
            # Strengths
            if "strengths" in reasoning_result and reasoning_result["strengths"]:
                markdown_parts.append("## Candidate Strengths")
                for strength in reasoning_result["strengths"]:
                    markdown_parts.append(f"- {strength}")
                markdown_parts.append("")
            
            # Areas for Improvement
            if "areas_for_improvement" in reasoning_result and reasoning_result["areas_for_improvement"]:
                markdown_parts.append("## Areas for Improvement")
                for area in reasoning_result["areas_for_improvement"]:
                    markdown_parts.append(f"- {area}")
                markdown_parts.append("")
            
            # Hiring Recommendation
            if "hiring_recommendation" in reasoning_result:
                markdown_parts.append("## Hiring Recommendation")
                markdown_parts.append(str(reasoning_result["hiring_recommendation"]))
                markdown_parts.append("")
            
            # Reasoning Chain
            if "reasoning_chain" in reasoning_result and reasoning_result["reasoning_chain"]:
                markdown_parts.append("## Reasoning Chain")
                for i, step in enumerate(reasoning_result["reasoning_chain"], 1):
                    markdown_parts.append(f"{i}. {step}")
                markdown_parts.append("")
            
            # Next Steps
            if "next_steps" in reasoning_result and reasoning_result["next_steps"]:
                markdown_parts.append("## Recommended Next Steps")
                for step in reasoning_result["next_steps"]:
                    markdown_parts.append(f"- {step}")
                markdown_parts.append("")
            
            # Executive Summary
            if "summary" in reasoning_result:
                markdown_parts.append("## Executive Summary")
                markdown_parts.append(str(reasoning_result["summary"]))
                markdown_parts.append("")
            
            # Confidence Score
            if "confidence" in reasoning_result:
                confidence_pct = reasoning_result["confidence"] * 100
                markdown_parts.append(f"## Analysis Confidence: {confidence_pct:.1f}%")
            
            return "\n".join(markdown_parts)
            
        except Exception as e:
            logger.warning(f"Failed to generate reasoning markdown: {e}")
            return f"# Reasoning Analysis\n\nError generating markdown summary: {str(e)}"
    
    async def get_session_status(self, session_id: str) -> Optional[Dict]:
        """Get status of a specific session."""
        return self.active_sessions.get(session_id)
    
    async def get_active_sessions(self) -> Dict[str, Dict]:
        """Get all active sessions."""
        return self.active_sessions.copy()
    
    async def health_check(self) -> Dict[str, Any]:
        """Comprehensive health check for all agents."""
        if not self._initialized:
            return {"status": "not_initialized"}
        
        try:
            health_status = {
                "status": "healthy",
                "agents": {},
                "llm_factory": "operational",
                "azure_storage": "operational",
                "active_sessions": len(self.active_sessions)
            }
            
            # Check each agent
            agents = {
                "resume_agent": self.resume_agent,
                "quality_agent": self.quality_agent,
                "reasoning_agent": self.reasoning_agent
            }
            
            for agent_name, agent in agents.items():
                if agent:
                    agent_health = await agent.health_check()
                    health_status["agents"][agent_name] = agent_health
                else:
                    health_status["agents"][agent_name] = "not_initialized"
            
            return health_status
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "agents": {},
                "active_sessions": len(self.active_sessions)
            }
    
    async def shutdown(self):
        """Shutdown the orchestrator and cleanup resources."""
        try:
            logger.info("🔄 Shutting down AI Recruitment Orchestrator")
            
            # Cancel active sessions
            for session_id in list(self.active_sessions.keys()):
                self.active_sessions[session_id]["status"] = "cancelled"
            
            # Shutdown agents
            if self.resume_agent:
                await self.resume_agent.shutdown()
            if self.job_description_agent:
                await self.job_description_agent.shutdown()
            # matching_agent shutdown removed - no longer needed
            if self.quality_agent:
                await self.quality_agent.shutdown()
            if self.reasoning_agent:
                await self.reasoning_agent.shutdown()
            
            # Close Azure storage
            await self.azure_storage.close()
            
            # Clear LLM factory cache
            self.llm_factory.clear_cache()
            
            self._initialized = False
            logger.info("✅ AI Recruitment Orchestrator shutdown completed")
            
        except Exception as e:
            logger.error(f"❌ Error during shutdown: {str(e)}")
            raise
"""
AI Recruit - Resume Analysis Agent
Specialized AI agent for comprehensive resume analysis and information extraction.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import asyncio
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Union

import instructor
from crewai import Agent, Task, Crew, Process
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from pydantic import BaseModel, Field

from core.config import Settings
from utils.parsers import DocumentParser
from utils.validators import ResumeValidator

logger = logging.getLogger(__name__)


class PersonalInfo(BaseModel):
    """Personal information extracted from resume."""
    full_name: Optional[str] = Field(None, description="Full name of the candidate")
    email: Optional[str] = Field(None, description="Email address")
    phone: Optional[str] = Field(None, description="Phone number")
    location: Optional[str] = Field(None, description="Current location/address")
    linkedin_url: Optional[str] = Field(None, description="LinkedIn profile URL")
    github_url: Optional[str] = Field(None, description="GitHub profile URL")
    portfolio_url: Optional[str] = Field(None, description="Portfolio website URL")


class WorkExperience(BaseModel):
    """Work experience entry."""
    position: str = Field(..., description="Job position/title")
    company: str = Field(..., description="Company name")
    location: Optional[str] = Field(None, description="Job location")
    start_date: Optional[str] = Field(None, description="Start date")
    end_date: Optional[str] = Field(None, description="End date or 'Present'")
    duration_months: Optional[int] = Field(None, description="Duration in months")
    description: Optional[str] = Field(None, description="Job description and responsibilities")
    achievements: List[str] = Field(default_factory=list, description="Key achievements")
    technologies: List[str] = Field(default_factory=list, description="Technologies used")


class Education(BaseModel):
    """Education entry."""
    degree: str = Field(..., description="Degree type and name")
    institution: str = Field(..., description="Educational institution")
    field_of_study: Optional[str] = Field(None, description="Field of study/major")
    location: Optional[str] = Field(None, description="Institution location")
    start_date: Optional[str] = Field(None, description="Start date")
    end_date: Optional[str] = Field(None, description="End date")
    gpa: Optional[str] = Field(None, description="GPA or academic performance")
    honors: List[str] = Field(default_factory=list, description="Academic honors/achievements")


class Skill(BaseModel):
    """Skill with proficiency assessment."""
    name: str = Field(..., description="Skill name")
    category: str = Field(..., description="Skill category (technical, soft, language, etc.)")
    proficiency: str = Field(..., description="Proficiency level (beginner, intermediate, advanced, expert)")
    years_experience: Optional[int] = Field(None, description="Years of experience with this skill")
    context: Optional[str] = Field(None, description="Context where skill was mentioned")


class CareerAnalysis(BaseModel):
    """Career progression and analysis."""
    total_years_experience: float = Field(..., description="Total years of professional experience")
    career_progression_score: float = Field(..., description="Career progression score (0-1)")
    leadership_experience: bool = Field(..., description="Has leadership experience")
    career_gaps: List[str] = Field(default_factory=list, description="Identified career gaps")
    career_trajectory: str = Field(..., description="Overall career trajectory assessment")
    industry_experience: List[str] = Field(default_factory=list, description="Industries worked in")


class ResumeAnalysisResult(BaseModel):
    """Complete resume analysis result."""
    personal_info: PersonalInfo
    work_experience: List[WorkExperience]
    education: List[Education]
    skills: List[Skill]
    career_analysis: CareerAnalysis
    
    # Additional AI-generated insights
    professional_summary: str = Field(..., description="AI-generated professional summary")
    key_strengths: List[str] = Field(default_factory=list, description="Identified key strengths")
    improvement_areas: List[str] = Field(default_factory=list, description="Areas for improvement")
    
    # Technical metadata
    confidence_score: float = Field(..., description="Overall confidence in analysis (0-1)")
    processing_time_seconds: float = Field(..., description="Time taken for analysis")
    extracted_text_length: int = Field(..., description="Length of extracted text")
    
    # Quality indicators
    completeness_score: float = Field(..., description="Resume completeness score (0-1)")
    presentation_score: float = Field(..., description="Resume presentation quality (0-1)")
    relevance_score: float = Field(..., description="Content relevance score (0-1)")


class ResumeAnalysisAgent:
    """
    Specialized AI agent for comprehensive resume analysis.
    Uses multiple LLM calls with different specializations for maximum accuracy.
    """
    
    def __init__(self, llm: BaseChatModel, settings: Settings):
        self.llm = llm
        self.settings = settings
        self.document_parser = DocumentParser()
        self.validator = ResumeValidator()
        
        # Configure environment for CrewAI to use correct LLM provider
        self._configure_llm_environment()
        
        # Initialize instructor for structured outputs
        # TODO: Implement proper instructor integration when needed
        self.instructor_client = None
        logger.warning("Instructor client not initialized - using mock mode for development")
        
        # Agent crew for specialized analysis
        self.analysis_crew = None
        self._initialized = False
    
    def _configure_llm_environment(self):
        """Configure environment variables for CrewAI to use the correct LLM provider."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔧 Configuring CrewAI environment for provider: {provider}")
            
            if provider == "azure_openai":
                # Set Azure OpenAI environment variables for CrewAI
                endpoint = config.get("endpoint", "")
                api_key = config.get("api_key", "")
                api_version = config.get("api_version", "2024-02-15-preview")
                deployment_name = config.get("deployment_name", "")
                
                logger.info(f"🔧 Setting Azure OpenAI environment variables:")
                logger.info(f"   Endpoint: {endpoint}")
                logger.info(f"   API Key: {'***' + api_key[-4:] if api_key else 'NOT SET'}")
                logger.info(f"   API Version: {api_version}")
                logger.info(f"   Deployment: {deployment_name}")
                
                # Set environment variables for Azure OpenAI
                os.environ["OPENAI_API_TYPE"] = "azure"
                os.environ["OPENAI_API_VERSION"] = api_version
                os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint
                os.environ["AZURE_OPENAI_API_KEY"] = api_key
                os.environ["AZURE_API_KEY"] = api_key
                os.environ["OPENAI_API_KEY"] = api_key  # CrewAI might check this
                os.environ["AZURE_OPENAI_BASE"] = endpoint  # Some libraries expect this
                os.environ["AZURE_API_BASE"] = endpoint
                os.environ["OPENAI_API_BASE"] = endpoint  # Alternative naming
                os.environ["OPENAI_BASE_URL"] = endpoint  # Some libs expect this
                os.environ["AZURE_OPENAI_RESOURCE"] = endpoint.split("//")[1].split(".")[0] if "//" in endpoint else ""
                
                # Deployment name for Azure - use actual model name, not deployment
                if deployment_name:
                    os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = deployment_name
                    os.environ["OPENAI_MODEL_NAME"] = "gpt-4.1"  # Use valid Azure OpenAI model name
                    os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment_name  # Alternative naming
                    os.environ["OPENAI_DEPLOYMENT_NAME"] = deployment_name  # Alternative naming
                    
                # Additional Azure OpenAI specific environment variables for LiteLLM
                os.environ["AZURE_OPENAI_CHAT_COMPLETIONS_DEPLOYMENT"] = deployment_name
                os.environ["AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT"] = deployment_name
                os.environ["LITELLM_LOG"] = "DEBUG"  # Enable debug logging for LiteLLM
                
                # Disable LangSmith tracing to avoid 403 errors
                os.environ["LANGCHAIN_TRACING_V2"] = "false"
                os.environ.pop("LANGSMITH_API_KEY", None)
                
                # Remove any OpenAI-specific environment variables that might conflict
                openai_vars_to_remove = ["OPENAI_ORGANIZATION"]
                for var in openai_vars_to_remove:
                    os.environ.pop(var, None)
                
                logger.info(f"✅ Azure OpenAI environment configured - Endpoint: {config.get('endpoint', 'Not Set')}")
                logger.info(f"   Deployment: {deployment_name}")
                logger.info(f"   API Version: {config.get('api_version', '2024-02-15-preview')}")
                
            elif provider == "openai":
                # Standard OpenAI configuration
                if config.get("api_key"):
                    os.environ["OPENAI_API_KEY"] = config["api_key"]
                if config.get("organization"):
                    os.environ["OPENAI_ORGANIZATION"] = config["organization"]
                
                # Remove Azure-specific variables if they exist
                azure_vars = ["OPENAI_API_TYPE", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT_NAME"]
                for var in azure_vars:
                    os.environ.pop(var, None)
                
                logger.info("✅ OpenAI environment configured")
                
            elif provider == "anthropic":
                if config.get("api_key"):
                    os.environ["ANTHROPIC_API_KEY"] = config["api_key"]
                logger.info("✅ Anthropic environment configured")
                
            # Log current provider configuration for debugging
            logger.info(f"🔍 Active LLM Provider: {provider}")
            logger.info(f"🔍 LLM Model: {config.get('model', 'Not specified')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to configure LLM environment: {str(e)}")
            
    def _verify_llm_configuration(self):
        """Verify that the LLM configuration is correct and log details."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔍 Verifying LLM Configuration:")
            logger.info(f"   Provider: {provider}")
            logger.info(f"   Model: {config.get('model', 'Not specified')}")
            
            if provider == "azure_openai":
                endpoint = config.get('endpoint')
                api_key = config.get('api_key')
                deployment = config.get('deployment_name')
                
                logger.info(f"   Azure Endpoint: {'✅ Set' if endpoint else '❌ Missing'}")
                logger.info(f"   Azure API Key: {'✅ Set' if api_key else '❌ Missing'}")
                logger.info(f"   Deployment Name: {'✅ ' + deployment if deployment else '❌ Missing'}")
                
                # Check for common configuration issues
                if not endpoint:
                    logger.error("❌ AZURE_OPENAI_ENDPOINT not set in environment")
                if not api_key:
                    logger.error("❌ AZURE_OPENAI_API_KEY not set in environment")
                if not deployment:
                    logger.error("❌ AZURE_OPENAI_DEPLOYMENT_NAME not set in environment")
                    
            elif provider == "openai":
                api_key = config.get('api_key')
                logger.info(f"   OpenAI API Key: {'✅ Set' if api_key else '❌ Missing'}")
                
            # Log LLM instance type for debugging
            llm_type = type(self.llm).__name__
            logger.info(f"   LLM Instance Type: {llm_type}")
            
            # Check for conflicting environment variables
            if provider == "azure_openai" and os.environ.get("OPENAI_API_TYPE") != "azure":
                logger.warning("⚠️ OPENAI_API_TYPE not set to 'azure' - this might cause issues with CrewAI")
                
        except Exception as e:
            logger.error(f"❌ Failed to verify LLM configuration: {str(e)}")
            
    async def initialize(self):
        """Initialize the resume analysis agent and crew."""
        try:
            logger.info("🔍 Initializing Resume Analysis Agent")
            
            # Verify LLM configuration
            self._verify_llm_configuration()
            
            # Create specialized agents for different aspects
            await self._create_analysis_crew()
            
            self._initialized = True
            logger.info("✅ Resume Analysis Agent initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Resume Analysis Agent: {str(e)}")
            raise
    
    async def _create_analysis_crew(self):
        """Create CrewAI crew for specialized resume analysis."""
        try:
            # Force re-configuration before creating crew
            self._configure_llm_environment()
            
            # Log the LLM being used by CrewAI agents
            llm_type = type(self.llm).__name__
            logger.info(f"🤖 Creating CrewAI agents with LLM: {llm_type}")
            
            # Check current environment variables
            logger.info(f"🔍 Environment check before creating agents:")
            logger.info(f"   OPENAI_API_TYPE: {os.environ.get('OPENAI_API_TYPE', 'NOT SET')}")
            logger.info(f"   AZURE_OPENAI_ENDPOINT: {os.environ.get('AZURE_OPENAI_ENDPOINT', 'NOT SET')}")
            logger.info(f"   AZURE_OPENAI_DEPLOYMENT_NAME: {os.environ.get('AZURE_OPENAI_DEPLOYMENT_NAME', 'NOT SET')}")
            logger.info(f"   OPENAI_API_KEY: {'***' + os.environ.get('OPENAI_API_KEY', '')[-4:] if os.environ.get('OPENAI_API_KEY') else 'NOT SET'}")
            
            # Create Azure OpenAI LLM explicitly for CrewAI
            try:
                # Try multiple approaches to create Azure OpenAI LLM
                llm_config = self.settings.get_llm_config()
                if llm_config["provider"] == "azure_openai":
                    config = llm_config["config"]
                    
                    # Method 1: Try AzureChatOpenAI
                    try:
                        
                        # Create Azure OpenAI LLM explicitly with correct model name
                        # For Azure, the model should be the actual OpenAI model, not the deployment name
                        actual_model = "gpt-4.1"  # Use valid Azure OpenAI model name
                        
                        crew_llm = AzureChatOpenAI(
                            azure_endpoint=config.get("endpoint"),
                            api_key=config.get("api_key"),
                            api_version=config.get("api_version", "2024-02-15-preview"),
                            azure_deployment=config.get("deployment_name"),
                            model=actual_model,  # Use actual OpenAI model name, not deployment
                            temperature=config.get("temperature", 0.1),
                            max_tokens=config.get("max_tokens", 4096)
                            # Removed deprecated parameters: openai_api_type, openai_api_base, openai_api_version
                        )
                        
                        logger.info(f"✅ Created explicit Azure OpenAI LLM for CrewAI:")
                        logger.info(f"   Endpoint: {config.get('endpoint')}")
                        logger.info(f"   Deployment: {config.get('deployment_name')}")
                        logger.info(f"   Model: {actual_model}")
                        
                    except Exception as azure_error:
                        logger.warning(f"⚠️ AzureChatOpenAI failed: {str(azure_error)}")
                        
                        # Method 2: Try ChatOpenAI with Azure configuration
                        try:
                            
                            # Create a model string that LiteLLM will recognize as Azure
                            azure_model = f"azure/{config.get('deployment_name')}"
                            
                            # Set environment variables for CrewAI Azure OpenAI integration
                            os.environ["OPENAI_API_TYPE"] = "azure"
                            os.environ["OPENAI_API_BASE"] = config.get('endpoint')
                            os.environ["OPENAI_API_VERSION"] = config.get('api_version', '2024-02-15-preview')
                            os.environ["OPENAI_API_KEY"] = config.get('api_key')
                            os.environ["AZURE_OPENAI_ENDPOINT"] = config.get('endpoint')
                            os.environ["AZURE_OPENAI_API_KEY"] = config.get('api_key')
                            os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = config.get('deployment_name')
                            
                            # For CrewAI with Azure OpenAI, use LiteLLM-compatible ChatOpenAI
                            crew_llm = ChatOpenAI(
                                model=azure_model,  # azure/<deployment_name> format
                                temperature=config.get("temperature", 0.1),
                                max_tokens=config.get("max_tokens", 4096),
                                # LiteLLM will handle Azure routing automatically with env vars
                            )
                            
                            logger.info(f"✅ Created ChatOpenAI with Azure configuration:")
                            logger.info(f"   Model: {azure_model}")
                            logger.info(f"   Endpoint: {config.get('endpoint')}")
                            
                        except Exception as chat_error:
                            logger.error(f"❌ Both Azure LLM methods failed: {str(chat_error)}")
                            crew_llm = self.llm
                else:
                    crew_llm = self.llm
                    
            except ImportError:
                logger.warning("⚠️ langchain_openai not available, using default LLM")
                crew_llm = self.llm
            except Exception as e:
                logger.error(f"❌ Failed to create Azure LLM: {str(e)}")
                crew_llm = self.llm
            
            # Ensure environment is properly set for individual agents
            llm_config = self.settings.get_llm_config()
            if llm_config["provider"] == "azure_openai":
                config = llm_config["config"]
                os.environ["OPENAI_API_TYPE"] = "azure"
                os.environ["OPENAI_API_BASE"] = config.get('endpoint', '')
                os.environ["OPENAI_API_VERSION"] = config.get('api_version', '2025-01-01-preview')
                os.environ["OPENAI_API_KEY"] = config.get('api_key', '')
                os.environ["AZURE_OPENAI_ENDPOINT"] = config.get('endpoint', '')
                os.environ["AZURE_OPENAI_API_KEY"] = config.get('api_key', '')
                os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = config.get('deployment_name', '')
                # Use the azure/deployment format for CrewAI agents
                agent_model = f"azure/{config.get('deployment_name', 'gpt-4.1')}"
                logger.info(f"🔧 Setting agent model to: {agent_model}")
            else:
                agent_model = None
            
            # Personal Information Extraction Agent
            personal_info_agent = Agent(
                role="Personal Information Extraction Specialist",
                goal="Extract accurate personal and contact information from resumes",
                backstory="""You are an expert at identifying and extracting personal information 
                from resumes. You have perfect accuracy in finding names, emails, phone numbers, 
                and social media profiles even when they're formatted unusually.""",
                verbose=True,
                allow_delegation=False,
                llm=crew_llm
            )
            
            # Override the LLM model if using Azure
            if agent_model and hasattr(personal_info_agent, 'llm'):
                try:
                    personal_info_agent.llm.model = agent_model
                    logger.info(f"✅ Set personal_info agent model to: {agent_model}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not set agent model: {e}")
            
            # Verify the agent is using the correct LLM
            agent_llm_type = type(personal_info_agent.llm).__name__ if hasattr(personal_info_agent, 'llm') else "Unknown"
            logger.info(f"🔍 Personal Info Agent LLM: {agent_llm_type}")
            
            # Experience Analysis Agent
            experience_agent = Agent(
                role="Experience Analysis Expert",
                goal="Analyze work experience and career progression with perfect accuracy",
                backstory="""You are a senior HR expert who can analyze career trajectories, 
                identify leadership experience, and assess professional growth. You understand 
                industry patterns and can spot career progression indicators.""",
                verbose=True,
                allow_delegation=False,
                llm=crew_llm
            )
            
            # Override the LLM model if using Azure
            if agent_model and hasattr(experience_agent, 'llm'):
                try:
                    experience_agent.llm.model = agent_model
                    logger.info(f"✅ Set experience agent model to: {agent_model}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not set experience agent model: {e}")
            
            # Skills Extraction Agent
            skills_agent = Agent(
                role="Skills Assessment Specialist",
                goal="Identify, categorize, and assess skill proficiency levels",
                backstory="""You are a technical recruiter with deep expertise in identifying 
                both technical and soft skills. You can assess proficiency levels and understand 
                the context in which skills are applied.""",
                verbose=True,
                allow_delegation=False,
                llm=crew_llm
            )
            
            # Override the LLM model if using Azure
            if agent_model and hasattr(skills_agent, 'llm'):
                try:
                    skills_agent.llm.model = agent_model
                    logger.info(f"✅ Set skills agent model to: {agent_model}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not set skills agent model: {e}")
            
            # Education Analysis Agent
            education_agent = Agent(
                role="Education Background Analyst",
                goal="Extract and analyze educational background and qualifications",
                backstory="""You are an academic credential evaluator who can parse complex 
                educational backgrounds, identify degrees, certifications, and assess academic 
                achievements accurately.""",
                verbose=True,
                allow_delegation=False,
                llm=crew_llm
            )
            
            # Override the LLM model if using Azure
            if agent_model and hasattr(education_agent, 'llm'):
                try:
                    education_agent.llm.model = agent_model
                    logger.info(f"✅ Set education agent model to: {agent_model}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not set education agent model: {e}")
            
            # Quality Assessment Agent
            quality_agent = Agent(
                role="Resume Quality Assessor",
                goal="Evaluate overall resume quality, completeness, and presentation",
                backstory="""You are a senior recruiter who evaluates hundreds of resumes. 
                You can assess resume quality, identify missing information, and provide 
                constructive feedback on presentation and content.""",
                verbose=True,
                allow_delegation=False,
                llm=crew_llm
            )
            
            # Override the LLM model if using Azure
            if agent_model and hasattr(quality_agent, 'llm'):
                try:
                    quality_agent.llm.model = agent_model
                    logger.info(f"✅ Set quality agent model to: {agent_model}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not set quality agent model: {e}")
            
            # Store agents for task creation
            self.agents = {
                "personal_info": personal_info_agent,
                "experience": experience_agent,
                "skills": skills_agent,
                "education": education_agent,
                "quality": quality_agent
            }
            
            logger.info("✅ Analysis crew created successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to create analysis crew: {str(e)}")
            raise
    
    async def _handle_large_resume(self, extracted_text: str, filename: str) -> str:
        """
        Handle large resumes by chunking and summarizing to avoid 429 errors.
        
        Args:
            extracted_text: Full extracted text from resume
            filename: Original filename for logging
            
        Returns:
            Processed text (either original or summarized chunks)
        """
        # Define size thresholds
        MAX_CHARS = 20000  # Characters that can be safely sent to LLM (increased from 15000)
        CHUNK_SIZE = 10000  # Size of each chunk for processing
        OVERLAP_SIZE = 500  # Overlap between chunks to maintain context
        
        text_length = len(extracted_text)
        logger.info(f"📏 Resume text length: {text_length} characters")
        
        # If text is small enough, return as-is
        if text_length <= MAX_CHARS:
            logger.info("✅ Resume text is within safe limits, processing normally")
            return extracted_text
        
        logger.warning(f"⚠️ Resume text is large ({text_length} chars), implementing chunking strategy")
        
        try:
            # Use chunking strategy for text longer than 20000 characters
            if text_length > 35000:
                logger.info(f"✅ Resume text is large ({text_length} chars), implementing chunking strategy")
                return await self._process_chunked_resume(extracted_text, CHUNK_SIZE, OVERLAP_SIZE)
            else:
                logger.info("✅ Resume text is within safe limits, processing normally")
                return extracted_text
        except Exception as e:
            logger.error(f"❌ Error in large resume handling: {e}")
            # Fallback to chunking
            return await self._process_chunked_resume(extracted_text, CHUNK_SIZE, OVERLAP_SIZE)
    
    async def _test_llm_call(self, text: str) -> Dict[str, Any]:
        """Test if LLM call works without 429 error."""
        try:
            # Create a simple test prompt
            test_prompt = f"""
            Analyze this resume text and extract only the candidate's name and email.
            Text: {text[:1000]}...
            
            Return JSON: {{"name": "extracted_name", "email": "extracted_email"}}
            """
            
            response = await self.llm.ainvoke(test_prompt)
            return {"success": True, "response": response.content}
            
        except Exception as e:
            error_str = str(e).lower()
            if "429" in error_str or "rate limit" in error_str:
                return {"success": False, "error_type": "429", "error": str(e)}
            else:
                return {"success": False, "error_type": "other", "error": str(e)}
    
    async def _process_chunked_resume(self, text: str, chunk_size: int, overlap_size: int) -> str:
        """
        Process resume in chunks and combine summaries.
        
        Args:
            text: Full resume text
            chunk_size: Size of each chunk
            overlap_size: Overlap between chunks
            
        Returns:
            Combined summary of all chunks
        """
        logger.info(f"📚 Processing resume in chunks of {chunk_size} characters")
        
        # Split text into chunks with overlap
        chunks = []
        start = 0
        iteration_count = 0
        max_iterations = (len(text) // (chunk_size - overlap_size)) + 10  # Safety limit
        
        while start < len(text) and iteration_count < max_iterations:
            end = min(start + chunk_size, len(text))
            chunk = text[start:end]
            chunks.append(chunk)
            
            # Debug logging for first few iterations
            if iteration_count < 5:
                logger.debug(f"🔍 Chunk {iteration_count + 1}: start={start}, end={end}, chunk_length={len(chunk)}")
            
            # Move start position forward, ensuring we don't go backwards
            new_start = end - overlap_size
            if new_start <= start:
                # Prevent infinite loop - move forward by at least 1 character
                logger.warning(f"⚠️ Overlap too large, moving forward by 1 character (start={start}, new_start={new_start})")
                start = start + 1
            else:
                start = new_start
            
            iteration_count += 1
            
            # Safety check to prevent infinite loops
            if iteration_count >= max_iterations:
                logger.warning(f"⚠️ Reached maximum iterations ({max_iterations}) in chunking loop")
                break
        
        logger.info(f"📦 Created {len(chunks)} chunks for processing")
        
        # Process each chunk
        chunk_summaries = []
        for i, chunk in enumerate(chunks):
            try:
                logger.info(f"🔄 Processing chunk {i+1}/{len(chunks)}")
                summary = await self._extract_chunk_summary(chunk, i+1, len(chunks))
                chunk_summaries.append(summary)
                
                # Add delay between chunks to avoid rate limiting
                if i < len(chunks) - 1:
                    await asyncio.sleep(2)
                    
            except Exception as e:
                logger.error(f"❌ Error processing chunk {i+1}: {e}")
                # Add a basic summary for failed chunks
                chunk_summaries.append(f"Chunk {i+1}: [Processing failed - {str(e)[:100]}]")
        
        # Combine all summaries
        combined_summary = self._combine_chunk_summaries(chunk_summaries, text)
        logger.info(f"✅ Chunk processing complete, combined summary length: {len(combined_summary)}")
        
        return combined_summary
    
    async def _extract_chunk_summary(self, chunk: str, chunk_num: int, total_chunks: int) -> str:
        """
        Extract key information from a single chunk.
        
        Args:
            chunk: Text chunk to process
            chunk_num: Current chunk number
            total_chunks: Total number of chunks
            
        Returns:
            Summary of key information from the chunk
        """
        prompt = f"""
        You are analyzing chunk {chunk_num} of {total_chunks} from a resume.
        
        Extract structured information from this chunk while being concise.
        
        CRITICAL FOR LOCATION: Extract location ONLY from personal/contact information section.
        DO NOT infer location from work experience locations or job locations.
        If this chunk contains personal info, look for location in contact details.
        If this chunk contains work experience, DO NOT use job locations as candidate's location.
        
        TEXT CHUNK:
        {chunk}
        
        Extract and format as JSON:
        {{
            "personal_info": {{
                "name": "full name if found",
                "email": "email if found",
                "phone": "phone if found",
                "location": "Extract ONLY from personal/contact section, NOT work experience locations"
            }},
            "work_experience": [
                {{
                    "position": "job title",
                    "company": "company name",
                    "duration": "years",
                    "achievements": ["achievement1", "achievement2"],
                    "start_date": "start date",
                    "end_date": "end date or Present",
                    "location": "job location",
                    "employment_type": "Full-time/Part-time/Contract/etc",
                    "technologies_used": ["tech1", "tech2"],
                    "team_size": "number or null",
                    "responsibilities": ["responsibility1", "responsibility2"]
                }}
            ],
            "skills": {{
                "programming_languages": ["Python", "JavaScript", "Java", "C++", "Go", "Rust"],
                "frameworks_libraries": ["React", "Angular", "Vue.js", "Django", "Spring Boot", "Express.js"],
                "tools_technologies": ["Docker", "Kubernetes", "Jenkins", "Git", "Linux", "Bash"],
                "databases": ["PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch"],
                "cloud_platforms": ["AWS", "Azure", "GCP", "Heroku", "DigitalOcean"],
                "soft_skills": ["Leadership", "Communication", "Problem Solving", "Team Management", "Project Management"],
                "certifications": ["AWS Certified", "PMP", "Scrum Master", "CISSP", "ITIL"]
            }},
            "education": [
                {{
                    "degree": "degree name",
                    "institution": "institution name",
                    "year": "graduation year"
                }}
            ],
            "projects": [
                {{
                    "name": "project name",
                    "technologies": ["tech1", "tech2"]
                }}
            ]
        }}
        
        IMPORTANT: Extract ALL technical skills mentioned in this chunk and categorize them properly:
        - Programming Languages: Python, Java, JavaScript, C++, Go, Rust, etc.
        - Frameworks & Libraries: React, Angular, Django, Spring Boot, Express.js, etc.
        - Tools & Technologies: Docker, Kubernetes, Git, Jenkins, Linux, etc.
        - Databases: PostgreSQL, MySQL, MongoDB, Redis, etc.
        - Cloud Platforms: AWS, Azure, GCP, Heroku, etc.
        - Soft Skills & Leadership: Leadership, Communication, Team Management, etc.
        - Certifications: Any professional certifications mentioned
        
        For work experience, extract:
        - Job titles, companies, and employment dates (start_date, end_date)
        - Key achievements and accomplishments (as bullet points)
        - Main responsibilities and duties (as bullet points)
        - Technologies and tools used in each role
        - Job location and employment type (Full-time, Contract, etc.)
        
        Only include information clearly present in this chunk. Use null for missing fields.
        Be thorough in skill extraction and work experience details.
        """
        
        try:
            response = await self.llm.ainvoke(prompt)
            time.sleep(5)
            return response.content.strip()
        except Exception as e:
            logger.error(f"❌ Error extracting chunk {chunk_num} summary: {e}")
            return f"Chunk {chunk_num}: [Summary extraction failed]"
    
    def _combine_chunk_summaries(self, summaries: List[str], original_text: str = "") -> str:
        """
        Combine chunk summaries into a coherent resume text.
        
        Args:
            summaries: List of chunk summaries (JSON strings)
            
        Returns:
            Combined resume text
        """
        logger.info(f"🔗 Combining {len(summaries)} chunk summaries")
        
        # Parse and combine JSON summaries
        combined_data = {
            "personal_info": {},
            "work_experience": [],
            "skills": {
                "programming_languages": [],
                "frameworks_libraries": [],
                "tools_technologies": [],
                "databases": [],
                "cloud_platforms": [],
                "soft_skills": [],
                "certifications": []
            },
            "education": [],
            "projects": []
        }
        
        for i, summary in enumerate(summaries):
            if summary and not summary.startswith("Chunk"):
                try:
                    chunk_data = json.loads(summary)
                    
                    # Merge personal info (take first non-null values)
                    for key, value in chunk_data.get("personal_info", {}).items():
                        if value and not combined_data["personal_info"].get(key):
                            combined_data["personal_info"][key] = value
                    
                    # Merge work experience
                    combined_data["work_experience"].extend(chunk_data.get("work_experience", []))
                    
                    # Merge detailed skills (avoid duplicates)
                    chunk_skills = chunk_data.get("skills", {})
                    for skill_category, skill_list in chunk_skills.items():
                        if skill_category in combined_data["skills"]:
                            for skill in skill_list:
                                if skill and skill not in combined_data["skills"][skill_category]:
                                    combined_data["skills"][skill_category].append(skill)
                    
                    # Merge education
                    combined_data["education"].extend(chunk_data.get("education", []))
                    
                    # Merge projects
                    combined_data["projects"].extend(chunk_data.get("projects", []))
                    
                except json.JSONDecodeError as e:
                    logger.warning(f"⚠️ Failed to parse chunk {i+1} JSON: {e}")
                    continue
        
        # Create a structured summary
        combined = f"RESUME SUMMARY (from {len(summaries)} chunks):\n\n"
        
        # Personal Information
        if combined_data["personal_info"]:
            combined += "PERSONAL INFORMATION:\n"
            for key, value in combined_data["personal_info"].items():
                if value:
                    combined += f"- {key.replace('_', ' ').title()}: {value}\n"
            combined += "\n"
        
        # Work Experience
        if combined_data["work_experience"]:
            combined += "WORK EXPERIENCE:\n"
            for exp in combined_data["work_experience"]:
                combined += f"- {exp.get('position', 'N/A')} at {exp.get('company', 'N/A')}"
                if exp.get('start_date') or exp.get('end_date'):
                    combined += f" ({exp.get('start_date', '')} - {exp.get('end_date', '')})"
                if exp.get('location'):
                    combined += f" [{exp.get('location', '')}]"
                if exp.get('employment_type'):
                    combined += f" ({exp.get('employment_type', '')})"
                combined += "\n"
                
                # Add achievements
                if exp.get('achievements'):
                    combined += "  Achievements:\n"
                    for achievement in exp['achievements']:
                        combined += f"    • {achievement}\n"
                
                # Add responsibilities
                if exp.get('responsibilities'):
                    combined += "  Responsibilities:\n"
                    for responsibility in exp['responsibilities']:
                        combined += f"    • {responsibility}\n"
                
                # Add technologies
                if exp.get('technologies_used'):
                    combined += f"  Technologies: {', '.join(exp['technologies_used'])}\n"
                
                combined += "\n"
        
        # Detailed Skills
        skills_sections = []
        for category, skills in combined_data["skills"].items():
            if skills:
                category_name = category.replace('_', ' ').title()
                skills_sections.append(f"{category_name}: {', '.join(skills)}")
        
        if skills_sections:
            combined += "SKILLS:\n"
            for section in skills_sections:
                combined += f"- {section}\n"
            combined += "\n"
        
        # Education
        if combined_data["education"]:
            combined += "EDUCATION:\n"
            for edu in combined_data["education"]:
                combined += f"- {edu.get('degree', 'N/A')} from {edu.get('institution', 'N/A')}"
                if edu.get('year'):
                    combined += f" ({edu['year']})"
                combined += "\n"
            combined += "\n"
        
        # Projects
        if combined_data["projects"]:
            combined += "PROJECTS:\n"
            for proj in combined_data["projects"]:
                combined += f"- {proj.get('name', 'N/A')}"
                if proj.get('technologies'):
                    combined += f" [Tech: {', '.join(proj['technologies'])}]"
                combined += "\n"
        
        # Ensure the summary is actually shorter than the original text
        if len(combined) > len(original_text):
            logger.warning(f"⚠️ Combined summary ({len(combined)} chars) is longer than original text ({len(original_text)} chars)")
            # Create a more concise version
            total_skills = sum(len(skills) for skills in combined_data['skills'].values())
            combined = f"RESUME SUMMARY: {combined_data['personal_info'].get('name', 'N/A')} - {len(combined_data['work_experience'])} jobs, {total_skills} skills, {len(combined_data['education'])} degrees"
        
        logger.info(f"📊 Summary length: {len(combined)} chars (original: {len(original_text)} chars)")
        return combined.strip()
    
    def _extract_section_from_summaries(self, summaries: List[str], keywords: List[str]) -> str:
        """
        Extract relevant sections from summaries based on keywords.
        
        Args:
            summaries: List of chunk summaries
            keywords: Keywords to look for
            
        Returns:
            Combined relevant information
        """
        relevant_parts = []
        
        for i, summary in enumerate(summaries):
            if summary is None:
                continue
            summary_lower = summary.lower()
            if any(keyword in summary_lower for keyword in keywords):
                # Extract the relevant part
                lines = summary.split('\n')
                relevant_lines = []
                for line in lines:
                    line_lower = line.lower()
                    if any(keyword in line_lower for keyword in keywords):
                        relevant_lines.append(line.strip())
                
                if relevant_lines:
                    relevant_parts.append(f"From Chunk {i+1}:\n" + '\n'.join(relevant_lines))
        
        return '\n\n'.join(relevant_parts) if relevant_parts else "Not found in any chunk"
    
    async def _fallback_chunked_analysis(self, extracted_text: str, filename: str = None) -> str:
        """
        Fallback analysis using chunking when 429 errors persist.
        
        Args:
            extracted_text: Full resume text
            
        Returns:
            JSON string with analysis results
        """
        logger.warning("🔄 Falling back to chunked analysis due to persistent 429 errors")
        
        # Use smaller chunks for the fallback analysis
        CHUNK_SIZE = 3000
        OVERLAP_SIZE = 300
        
        # Split text into chunks
        chunks = []
        start = 0
        iteration_count = 0
        max_iterations = (len(extracted_text) // (CHUNK_SIZE - OVERLAP_SIZE)) + 10  # Safety limit
        
        while start < len(extracted_text) and iteration_count < max_iterations:
            end = min(start + CHUNK_SIZE, len(extracted_text))
            chunk = extracted_text[start:end]
            chunks.append(chunk)
            
            # Move start position forward, ensuring we don't go backwards
            new_start = end - OVERLAP_SIZE
            if new_start <= start:
                # Prevent infinite loop - move forward by at least 1 character
                logger.warning(f"⚠️ Overlap too large in fallback, moving forward by 1 character (start={start}, new_start={new_start})")
                start = start + 1
            else:
                start = new_start
            
            iteration_count += 1
            
            # Safety check to prevent infinite loops
            if iteration_count >= max_iterations:
                logger.warning(f"⚠️ Reached maximum iterations ({max_iterations}) in fallback chunking loop")
                break
        
        logger.info(f"📦 Created {len(chunks)} chunks for fallback analysis")
        
        # Analyze each chunk separately
        chunk_analyses = []
        for i, chunk in enumerate(chunks):
            try:
                logger.info(f"🔄 Analyzing chunk {i+1}/{len(chunks)}")
                chunk_analysis = await self._analyze_single_chunk(chunk, i+1, len(chunks))
                chunk_analyses.append(chunk_analysis)
                
                # Add delay between chunks
                if i < len(chunks) - 1:
                    await asyncio.sleep(3)  # Longer delay for fallback
                    
            except Exception as e:
                logger.error(f"❌ Error analyzing chunk {i+1}: {e}")
                # Add empty analysis for failed chunks
                chunk_analyses.append({
                    "personal_info": {},
                    "experience": {"work_experience": [], "total_years_experience": 0},
                    "skills": {"technical_skills": [], "soft_skills": []},
                    "education": {"degrees": [], "certifications": []},
                    "projects": [],
                    "quality_assessment": {"overall_score": 0.0}
                })
        
        # Combine chunk analyses
        combined_analysis = self._combine_chunk_analyses(chunk_analyses)
        
        # Return structured result (not JSON string)
        return {
            "structured": combined_analysis,
            "raw_outputs": {
                "personal_info_markdown": self._format_personal_info_markdown(combined_analysis.get('personal_info', {}), filename),
                "experience_markdown": self._format_experience_markdown(combined_analysis.get('experience', {})),
                "skills_markdown": self._format_skills_markdown(combined_analysis.get('skills', {})),
                "education_markdown": self._format_education_markdown(combined_analysis.get('education', {})),
                "quality_markdown": self._format_quality_markdown(combined_analysis.get('quality_assessment', {}))
            }
        }
    
    async def _analyze_single_chunk(self, chunk: str, chunk_num: int, total_chunks: int) -> Dict[str, Any]:
        """
        Analyze a single chunk of resume text.
        
        Args:
            chunk: Text chunk to analyze
            chunk_num: Current chunk number
            total_chunks: Total number of chunks
            
        Returns:
            Analysis results for this chunk
        """
        prompt = f"""
        You are analyzing chunk {chunk_num} of {total_chunks} from a resume.
        
        Extract and structure the key information from this chunk:
        
        TEXT CHUNK:
        {chunk}
        
        Return a JSON object with this structure:
        {{
            "personal_info": {{
                "full_name": "name if found or null",
                "email": "email if found or null",
                "phone": "phone if found or null",
                "location": "location if found or null"
            }},
            "experience": {{
                "work_experience": [
                    {{
                        "position": "job title",
                        "company": "company name",
                        "start_date": "start date or null",
                        "end_date": "end date or null",
                        "achievements": ["achievement1", "achievement2"],
                        "technologies_used": ["tech1", "tech2"]
                    }}
                ],
                "total_years_experience": 0
            }},
            "skills": {{
                "technical_skills": [
                    {{"skill": "skill_name", "proficiency": "level", "years_experience": "years"}}
                ],
                "soft_skills": ["skill1", "skill2"]
            }},
            "education": {{
                "degrees": [
                    {{"degree": "degree_name", "institution": "institution", "year": "year"}}
                ],
                "certifications": ["cert1", "cert2"]
            }},
            "projects": [
                {{"name": "project_name", "description": "description", "technologies": ["tech1", "tech2"]}}
            ],
            "quality_assessment": {{
                "overall_score": "calculate_based_on_resume_quality",
                "completeness_score": "assess_resume_completeness"
            }}
        }}
        
        Extract only information that is clearly present in this chunk.
        Use null for missing fields and empty arrays for missing lists.
        """
        
        try:
            response = await self.llm.ainvoke(prompt)
            result_text = response.content.strip()
            
            # Try to extract JSON from response
            
            # Look for JSON in the response
            json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                return json.loads(json_str)
            else:
                # Fallback: return empty structure
                return {
                    "personal_info": {},
                    "experience": {"work_experience": [], "total_years_experience": 0},
                    "skills": {"technical_skills": [], "soft_skills": []},
                    "education": {"degrees": [], "certifications": []},
                    "projects": [],
                    "quality_assessment": {"overall_score": 0.0}
                }
                
        except Exception as e:
            logger.error(f"❌ Error analyzing chunk {chunk_num}: {e}")
            return {
                "personal_info": {},
                "experience": {"work_experience": [], "total_years_experience": 0},
                "skills": {"technical_skills": [], "soft_skills": []},
                "education": {"degrees": [], "certifications": []},
                "projects": [],
                "quality_assessment": {"overall_score": 0.0}
            }
    
    def _combine_chunk_analyses(self, chunk_analyses: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Combine analyses from multiple chunks into a single analysis.
        
        Args:
            chunk_analyses: List of analysis results from each chunk
            
        Returns:
            Combined analysis result
        """
        logger.info(f"🔗 Combining {len(chunk_analyses)} chunk analyses")
        
        # Filter out None analyses
        valid_analyses = [analysis for analysis in chunk_analyses if analysis is not None]
        if not valid_analyses:
            logger.warning("⚠️ No valid chunk analyses to combine")
            return self._create_empty_analysis()
        
        logger.info(f"🔗 Using {len(valid_analyses)} valid analyses out of {len(chunk_analyses)} total")
        
        # Initialize combined structure
        combined = {
            "personal_info": {},
            "experience": {
                "work_experience": [],
                "total_years_experience": 0
            },
            "skills": {
                "technical_skills": [],
                "soft_skills": []
            },
            "education": {
                "degrees": [],
                "certifications": []
            },
            "projects": [],
            "quality_assessment": {
                "overall_score": 0.0,
                "completeness_score": 0.0
            }
        }
        
        # Combine personal info (take first non-null values)
        for analysis in valid_analyses:
            personal_info = analysis.get("personal_info", {})
            for key, value in personal_info.items():
                if value and not combined["personal_info"].get(key):
                    combined["personal_info"][key] = value
        
        # Combine work experience
        all_experience = []
        for analysis in valid_analyses:
            work_exp = analysis.get("experience", {}).get("work_experience", [])
            all_experience.extend(work_exp)
        
        # Remove duplicates based on position and company
        seen = set()
        unique_experience = []
        for exp in all_experience:
            key = (exp.get("position", ""), exp.get("company", ""))
            if key not in seen and key != ("", ""):
                seen.add(key)
                unique_experience.append(exp)
        
        combined["experience"]["work_experience"] = unique_experience
        
        # Calculate total years of experience
        total_years = 0
        for exp in unique_experience:
            # Simple calculation - could be improved
            if exp.get("start_date") and exp.get("end_date"):
                try:
                    # This is a simplified calculation
                    total_years += 1  # Assume 1 year per position for now
                except:
                    pass
        
        combined["experience"]["total_years_experience"] = total_years
        
        # Combine skills
        all_technical_skills = []
        all_soft_skills = []
        
        for analysis in valid_analyses:
            skills = analysis.get("skills", {})
            all_technical_skills.extend(skills.get("technical_skills", []))
            all_soft_skills.extend(skills.get("soft_skills", []))
        
        # Remove duplicate skills
        seen_tech = set()
        unique_tech_skills = []
        for skill in all_technical_skills:
            skill_name = skill.get("skill", "").lower()
            if skill_name and skill_name not in seen_tech:
                seen_tech.add(skill_name)
                unique_tech_skills.append(skill)
        
        combined["skills"]["technical_skills"] = unique_tech_skills
        combined["skills"]["soft_skills"] = list(set(all_soft_skills))
        
        # Combine education
        all_degrees = []
        all_certifications = []
        
        for analysis in valid_analyses:
            education = analysis.get("education", {})
            all_degrees.extend(education.get("degrees", []))
            all_certifications.extend(education.get("certifications", []))
        
        # Remove duplicates
        seen_degrees = set()
        unique_degrees = []
        for degree in all_degrees:
            key = (degree.get("degree", ""), degree.get("institution", ""))
            if key not in seen_degrees and key != ("", ""):
                seen_degrees.add(key)
                unique_degrees.append(degree)
        
        combined["education"]["degrees"] = unique_degrees
        combined["education"]["certifications"] = list(set(all_certifications))
        
        # Combine projects
        all_projects = []
        for analysis in valid_analyses:
            projects = analysis.get("projects", [])
            all_projects.extend(projects)
        
        # Remove duplicates
        seen_projects = set()
        unique_projects = []
        for project in all_projects:
            project_name = project.get("name", "").lower()
            if project_name and project_name not in seen_projects:
                seen_projects.add(project_name)
                unique_projects.append(project)
        
        combined["projects"] = unique_projects
        
        # Calculate average quality scores
        quality_scores = []
        for analysis in valid_analyses:
            quality = analysis.get("quality_assessment", {})
            if quality.get("overall_score", 0) > 0:
                quality_scores.append(quality.get("overall_score", 0))
        
        if quality_scores:
            combined["quality_assessment"]["overall_score"] = sum(quality_scores) / len(quality_scores)
            combined["quality_assessment"]["completeness_score"] = min(1.0, len(quality_scores) / len(chunk_analyses))
        else:
            combined["quality_assessment"]["overall_score"] = 0.5
            combined["quality_assessment"]["completeness_score"] = 0.5
        
        logger.info("✅ Chunk analyses combined successfully")
        return combined
    
    def _create_empty_analysis(self) -> Dict[str, Any]:
        """
        Create an empty analysis structure when no valid analyses are available.
        
        Returns:
            Empty analysis structure
        """
        return {
            "personal_info": {},
            "experience": {
                "work_experience": [],
                "total_years_experience": 0
            },
            "skills": {
                "technical_skills": [],
                "soft_skills": []
            },
            "education": {
                "degrees": [],
                "certifications": []
            },
            "projects": [],
            "quality_assessment": {
                "overall_score": 0.0,
                "completeness_score": 0.0
            }
        }
    
    async def analyze_resume(
        self,
        file_content: bytes,
        filename: str,
        additional_context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Perform comprehensive resume analysis.
        
        Args:
            file_content: Binary content of the resume file
            filename: Original filename
            additional_context: Additional context for analysis
            
        Returns:
            Complete analysis results
        """
        if not self._initialized:
            await self.initialize()
        start_time = datetime.now(timezone.utc)
        try:
            logger.info(f"🔍 Starting resume analysis: {filename}")
            # Step 1: Extract text from document
            parse_result = await self.document_parser.parse_document(
                file_content, filename
            )
            extracted_text = parse_result["text"]
            logger.info(f"🔍 Extracted text: {extracted_text}")
            if not extracted_text or len(extracted_text.strip()) < 100:
                raise ValueError("Unable to extract sufficient text from resume")
            # Step 2: Check if resume is too large and needs chunking
            processed_text = await self._handle_large_resume(extracted_text, filename)
            # Step 3: Validate resume content
            validation_result = await self.validator.validate_resume_content(
                processed_text
            )
            if not validation_result["is_valid"]:
                issues = validation_result.get("errors", []) + validation_result.get("warnings", [])
                logger.warning(f"Resume validation issues: {issues}")
            # Step 4: Perform multi-agent analysis
            analysis_results = await self._perform_multi_agent_analysis(processed_text, filename)
            # Step 4: Use enhanced parsing of CrewAI results 
            structured_result = await self._process_crewai_results(analysis_results)
            # Step 5: Calculate confidence score
            confidence_score = self._calculate_confidence_from_crewai(structured_result)
            processing_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            # Compile final result
            final_result = {
                "analysis": structured_result,  # Use processed results directly
                "quality_metrics": {"confidence_score": confidence_score},
                "insights": {"processing_method": "CrewAI Multi-Agent Analysis"},
                "metadata": {
                    "filename": filename,
                    "processing_time": processing_time,
                    "extracted_text_length": len(extracted_text),
                    "extracted_text": extracted_text,  # Store the actual extracted text
                    "validation_result": validation_result,
                    "agent_version": "2.0-Enhanced",
                    "llm_provider": self.settings.LLM_PROVIDER,
                    "confidence_score": confidence_score
                }
            }
            logger.info(f"✅ Resume analysis completed: {filename} ({processing_time:.2f}s)")
            return final_result
        except Exception as e:
            logger.error(f"❌ Resume analysis failed: {str(e)}")
            processing_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            return {
                "error": str(e),
                "metadata": {
                    "filename": filename,
                    "processing_time": processing_time,
                    "status": "failed"
                }
            }
    
    async def _perform_multi_agent_analysis(self, extracted_text: str, filename: str = None) -> Dict[str, Any]:
        """Perform comprehensive resume analysis using a single AI call."""
        try:
            logger.info("🚀 Starting unified resume analysis with single AI call")
            # Create the JSON schema as a separate string to avoid f-string issues
            json_schema = '''{
                "personal_info": {
                    "full_name": "Extract the candidate's complete name from the top of the resume, headers, or contact sections. If no name found, return null",
                    "email": "primary email address or null",
                    "secondary_email": "additional email if found or null",
                    "phone": "primary phone number with formatting or null",
                    "secondary_phone": "additional phone if found or null",
                    "location": "Extract ONLY from personal/contact information section (header, contact details, address). Do NOT use work experience locations. Return city, state, country or null",
                    "address": "full physical address or null",
                    "linkedin_url": "full LinkedIn URL or null",
                    "github_url": "full GitHub URL or null", 
                    "portfolio_url": "personal website/portfolio URL or null",
                    "other_profiles": ["any other professional profile URLs"],
                    "professional_title": "current role/title or null"
                },
                "experience": {
                    "work_experience": [
                        {
                            "position": "Sr. Network Engineer",
                            "company": "Huntington Bank",
                            "duration": "3.5 years",
                            "achievements": ["Delivered secure network architecture for banking operations", "Led SD-WAN implementations across multiple environments"],
                            "start_date": "2018 May",
                            "end_date": "2021 Jun",
                            "location": "Columbus, OH",
                            "employment_type": "Full-time",
                            "technologies_used": ["Cisco", "SD-WAN", "Network Security"],
                            "team_size": "5",
                            "responsibilities": ["Design network infrastructure", "Manage security protocols", "Lead technical projects"]
                        }
                    ],
                    "total_years_experience": 5.0,
                    "current_position": "current job title",
                    "current_company": "current company",
                    "career_progression_score": 0.8,
                    "leadership_experience": true
                },
                "skills": {
                    "programming_languages": [
                        {
                            "skill": "Python",
                            "proficiency": "Advanced",
                            "years_experience": "3+",
                            "context_demonstrated": "job description",
                            "frequency_of_use": "Daily",
                            "evidence_of_expertise": "certification",
                            "core_or_supporting": "Core",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.9
                        }
                    ],
                    "frameworks_libraries": [
                        {
                            "skill": "React",
                            "proficiency": "Intermediate",
                            "years_experience": "2+",
                            "context_demonstrated": "project work",
                            "frequency_of_use": "Weekly",
                            "evidence_of_expertise": "portfolio projects",
                            "core_or_supporting": "Supporting",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.7
                        }
                    ],
                    "tools_technologies": [
                        {
                            "skill": "Docker",
                            "proficiency": "Intermediate",
                            "years_experience": "1+",
                            "context_demonstrated": "devops work",
                            "frequency_of_use": "Weekly",
                            "evidence_of_expertise": "deployment experience",
                            "core_or_supporting": "Supporting",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.6
                        }
                    ],
                    "technical_skills": [
                        {
                            "skill": "System Design",
                            "proficiency": "Advanced",
                            "years_experience": "2+",
                            "context_demonstrated": "architecture projects",
                            "frequency_of_use": "Occasionally",
                            "evidence_of_expertise": "complex system implementations",
                            "core_or_supporting": "Core",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.8
                        }
                    ],
                    "soft_skills": [
                        {
                            "skill": "Leadership",
                            "proficiency": "Advanced",
                            "years_experience": "3+",
                            "context_demonstrated": "team management",
                            "frequency_of_use": "Daily",
                            "evidence_of_expertise": "led team of 5+",
                            "core_or_supporting": "Core",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.9
                        }
                    ],
                    "methodologies": [
                        {
                            "skill": "Agile",
                            "proficiency": "Advanced",
                            "years_experience": "4+",
                            "context_demonstrated": "project management",
                            "frequency_of_use": "Daily",
                            "evidence_of_expertise": "certified scrum master",
                            "core_or_supporting": "Core",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.8
                        }
                    ],
                    "databases": [
                        {
                            "skill": "PostgreSQL",
                            "proficiency": "Intermediate",
                            "years_experience": "2+",
                            "context_demonstrated": "database design",
                            "frequency_of_use": "Weekly",
                            "evidence_of_expertise": "production systems",
                            "core_or_supporting": "Supporting",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.7
                        }
                    ],
                    "cloud_platforms": [
                        {
                            "skill": "AWS",
                            "proficiency": "Intermediate",
                            "years_experience": "1+",
                            "context_demonstrated": "cloud deployment",
                            "frequency_of_use": "Weekly",
                            "evidence_of_expertise": "certification",
                            "core_or_supporting": "Supporting",
                            "current_or_outdated": "Current",
                            "emerging": false,
                            "relevance_score": 0.8
                        }
                    ]
                },
                "education": {
                    "education": [
                        {
                            "degree": "Bachelor of Science in Computer Science",
                            "institution": "University Name", 
                            "graduation_year": "2020",
                            "field_of_study": "Computer Science",
                            "gpa": "3.8",
                            "location": "City, State",
                            "honors": "Magna Cum Laude"
                        }
                    ],
                    "highest_degree": "Bachelor's",
                    "relevant_education": true,
                    "certifications": [
                        {
                            "name": "AWS Certified Solutions Architect",
                            "issuer": "Amazon Web Services",
                            "date_earned": "2022",
                            "expiration_date": "2025",
                            "credential_id": "AWS-123456"
                        }
                    ]
                },
                "quality": {
                    "overall_score": "calculate_based_on_resume_quality",
                    "completeness_score": "assess_resume_completeness",
                    "relevance_score": "evaluate_relevance_to_target_role",
                    "presentation_score": "assess_formatting_and_clarity",
                    "achievement_quantification_score": "evaluate_use_of_metrics",
                    "technical_competency_score": "assess_technical_skills_demonstration",
                    "career_progression_score": "evaluate_career_growth",
                    "recommendations": ["list_specific_improvements"],
                    "strengths": ["identify_key_strengths"],
                    "areas_for_improvement": ["identify_improvement_areas"]
                },
                "key_strengths": [
                    "Strong technical expertise in Python and Django",
                    "Proven leadership experience managing teams",
                    "Excellent problem-solving and analytical skills",
                    "Strong communication and collaboration abilities",
                    "Continuous learning and adaptability"
                ],
                "improvement_areas": [
                    "Add more quantifiable achievements with specific metrics",
                    "Include more soft skills examples and evidence",
                    "Expand on project impact and business value"
                ],
                "professional_summary": "Experienced software engineer with 5+ years of expertise in full-stack development, team leadership, and agile methodologies. Proven track record of delivering scalable solutions and mentoring junior developers.",
                "confidence_score": 0.85,
                "completeness_score": 0.8
            }'''

            unified_prompt = f"""
            You are an expert AI recruiter and resume analyst. Perform a comprehensive analysis of this resume and return ONLY a valid JSON object with the exact structure specified below.

            CRITICAL INSTRUCTION: Calculate quality scores based on ACTUAL resume content.
            DO NOT use any example values like 0.75, 0.8, 0.7, etc.
            Calculate real scores based on the resume's actual quality.
            
            CRITICAL FOR PERSONAL INFO: Extract the candidate's FULL NAME if present.
            Look for names at the top of the resume, in headers, or in contact sections.
            If NO NAME is found, return null for full_name field.
            DO NOT provide explanations - just return the name or null.
            
            NAME EXTRACTION RULES:
            1. Look at the very top of the resume (first few lines)
            2. Check for names in contact information sections
            3. Look for names in headers or title sections
            4. Extract the most prominent name mentioned
            5. If NO NAME found, return null (not an explanation)
            
            CRITICAL FOR LOCATION: Extract location ONLY from personal/contact information section.
            DO NOT infer location from work experience locations or job locations.
            Look for location in:
            1. Header section with contact information
            2. Personal information section
            3. Contact details section
            4. Address line in contact info
            If NO personal location is found, return null for location field.
            DO NOT use work experience locations as candidate's current location.

            RESUME TEXT TO ANALYZE:
                {extracted_text}

                ANALYSIS REQUIREMENTS:
            Extract and analyze ALL information from the resume including:
            1. Personal and contact information
            2. Work experience and career progression
            3. Skills and competencies (technical, soft, methodologies)
            4. Education and certifications
            5. Quality assessment and recommendations

            Return ONLY this JSON structure (no markdown, no extra text):
            
            IMPORTANT: For work_experience, ALWAYS extract start_date and end_date. 
            Look for patterns like "June 2018 - June 2021" and extract ONLY the years: "2018" and "2021".
            
            CRITICAL: For quality assessment, calculate REAL scores based on the actual resume content.
            Do NOT copy example values - analyze the resume and provide accurate quality scores.
            
            QUALITY SCORE REQUIREMENTS:
            - overall_score: Must be a number between 0.0 and 1.0 (e.g., 0.85, 0.92, 0.67)
            - completeness_score: Must be a number between 0.0 and 1.0
            - relevance_score: Must be a number between 0.0 and 1.0
            - presentation_score: Must be a number between 0.0 and 1.0
            - achievement_quantification_score: Must be a number between 0.0 and 1.0
            - technical_competency_score: Must be a number between 0.0 and 1.0
            - career_progression_score: Must be a number between 0.0 and 1.0
            
            DO NOT USE: 0.75, 0.8, 0.7, 0.6, 0.9, or any example values
            DO USE: Actual calculated scores based on resume analysis

            {json_schema}

            EXTRACTION GUIDELINES:
            - Extract ALL available information from the resume
            - Use null for missing fields, empty arrays for missing lists
            - CRITICAL: ALWAYS extract the candidate's full name from personal_info
            - Look for names in resume headers, contact sections, or at the top
            - For skills, normalize names (JS → JavaScript, etc.)
            - Include only skills explicitly mentioned or clearly implied
            
            CRITICAL FOR WORK EXPERIENCE:
            - ALWAYS extract start_date and end_date for each position
            - Look for date patterns like: "June 2018 - June 2021", "2018-2021", "Jan 2020 - Present"
            - For current positions, use "Present" as end_date
            - Format: "2018 May - 2021 Jun" or "2018 May - Present"
            - Extract all positions with full details including:
              * Start and end dates (REQUIRED - format: YYYY - MM only, e.g., "2018 May", "2021 Jun")
              * Key achievements and accomplishments (as bullet points)
              * Main responsibilities and duties (as bullet points)
              * Technologies and tools used
              * Job location and employment type
            - Duration should be calculated based on start_date and end_date. For Example: 3.5 years the second digit is the months.
            - Duration should not be direct dates like "2018 May - 2021 Jun", it should be calculated based on start_date and end_date.
            - For education, include all degrees and certifications with dates
            
            CRITICAL FOR QUALITY ASSESSMENT:
            - Calculate ACTUAL quality scores based on resume content, not use example values
            - overall_score: Overall resume quality (0.0-1.0)
            - completeness_score: How complete the resume is (0.0-1.0)
            - relevance_score: Relevance to target role (0.0-1.0)
            - presentation_score: Formatting and clarity (0.0-1.0)
            - achievement_quantification_score: Use of metrics and numbers (0.0-1.0)
            - technical_competency_score: Technical skills demonstration (0.0-1.0)
            - career_progression_score: Career growth and advancement (0.0-1.0)
            - Provide specific, actionable recommendations
            - Identify actual strengths and areas for improvement
            - Use 0.0-1.0 scale for all scores
            - Be thorough but accurate - don't invent information
            - Return valid JSON only - no markdown formatting

            CRITICAL: Return ONLY the JSON object above, no other text or formatting.
            DO NOT provide explanations or verbose responses - just return the JSON data.
            If a field cannot be extracted, use null, not an explanation.
            """
            # Use higher max_tokens for comprehensive analysis
            try:
                _bind = getattr(self.llm, "bind", None)
                analysis_llm = self.llm.bind(max_tokens=16384) if callable(_bind) else self.llm
            except Exception:
                analysis_llm = self.llm
            # Use unified analysis (chunking is already handled in _handle_large_resume)
            logger.info("🔍 Executing unified resume analysis...")
            logger.info(f"🔍 Unified prompt length: {len(unified_prompt)}")
            try:
                response = await analysis_llm.ainvoke(unified_prompt)
                result_text = response.content.strip()
                # Debug: Log the raw LLM response to check quality scores
                logger.info(f"🔍 Raw LLM response length: {len(result_text)}")
                if "overall_score" in result_text:
                    score_match = re.search(r'"overall_score":\s*([0-9.]+)', result_text)
                    if score_match:
                        logger.info(f"🔍 LLM returned overall_score: {score_match.group(1)}")
                    else:
                        logger.warning("⚠️ No overall_score found in LLM response")
            except Exception as e:
                logger.error(f"❌ Unified analysis failed: {str(e)}")
                raise
            # Check if result_text is valid
            if not result_text:
                logger.error("❌ No response content received from LLM")
                raise Exception("No response content received from LLM")
            
            # Extract JSON from response with better error handling
            def extract_json_from_response(text):
                """Extract and parse JSON from LLM response with fallback handling."""
                json_patterns = [
                    r'```json\s*(\{.*?\})\s*```',  # JSON in code blocks (preferred)
                    r'```\s*(\{.*?\})\s*```',  # JSON in any code blocks
                    r'\{.*\}',  # Any JSON-like structure
                ]
                
                for pattern in json_patterns:
                    json_match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
                    if json_match:
                        try:
                            json_str = json_match.group(1) if json_match.groups() else json_match.group()
                            parsed_data = json.loads(json_str)
                            logger.info("✅ Successfully parsed unified analysis JSON")
                            return parsed_data
                        except json.JSONDecodeError as e:
                            logger.warning(f"JSON parsing failed with pattern {pattern}: {e}")
                            continue
                
                # If no pattern works, try to find the start of JSON and extract as much as possible
                start_idx = text.find('{')
                if start_idx != -1:
                    # Try to find a complete JSON object by counting braces
                    brace_count = 0
                    end_idx = start_idx
                    for i, char in enumerate(text[start_idx:], start_idx):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                end_idx = i + 1
                                break
                    
                    if brace_count == 0:  # Found complete JSON
                        try:
                            json_str = text[start_idx:end_idx]
                            parsed_data = json.loads(json_str)
                            logger.info("✅ Successfully parsed JSON by finding complete object")
                            return parsed_data
                        except json.JSONDecodeError as e:
                            logger.warning(f"JSON parsing failed for complete object: {e}")
                
                return None
            
            parsed_data = extract_json_from_response(result_text)
            if not parsed_data:
                logger.warning("⚠️ Primary JSON parsing failed, attempting fallback with shorter prompt...")
                # Fallback: Try with a shorter, more focused prompt
                fallback_prompt = f"""
                Analyze this resume and return ONLY a valid JSON object with this structure:
                
                {{
                    "personal_info": {{"full_name": "name", "email": "email", "phone": "phone", "location": "Extract ONLY from personal/contact section, NOT work experience locations"}},
                    "experience": {{
                        "work_experience": [
                            {{"position": "title", "company": "company", "start_date": "year", "end_date": "year", "achievements": ["achievement1", "achievement2"]}}
                        ],
                        "total_years_experience": 0
                    }},
                    "skills": {{
                        "programming_languages": ["lang1", "lang2"],
                        "frameworks_libraries": ["framework1", "framework2"],
                        "tools_technologies": ["tool1", "tool2"],
                        "databases": ["db1", "db2"],
                        "cloud_platforms": ["cloud1", "cloud2"],
                        "soft_skills": ["skill1", "skill2"],
                        "certifications": ["cert1", "cert2"]
                    }},
                    "education": {{
                        "education": [{{"degree": "degree", "institution": "institution", "graduation_year": "year"}}],
                        "highest_degree": "degree",
                        "certifications": [{{"name": "cert", "issuer": "issuer", "date_earned": "date"}}]
                    }},
                    "quality": {{
                        "overall_score": "calculate_based_on_resume_quality",
                        "completeness_score": "assess_resume_completeness",
                        "relevance_score": "evaluate_relevance_to_target_role",
                        "presentation_score": "assess_formatting_and_clarity",
                        "achievement_quantification_score": "evaluate_use_of_metrics",
                        "technical_competency_score": "assess_technical_skills_demonstration",
                        "career_progression_score": "evaluate_career_growth",
                        "recommendations": ["list_specific_improvements"],
                        "strengths": ["identify_key_strengths"],
                        "areas_for_improvement": ["identify_improvement_areas"]
                    }}
                }}
                
                Resume text: {extracted_text[:5000]}...
                """
                try:
                    fallback_response = await analysis_llm.ainvoke(fallback_prompt)
                    fallback_text = fallback_response.content.strip()
                    parsed_data = extract_json_from_response(fallback_text)
                    
                    if parsed_data:
                        logger.info("✅ Fallback JSON parsing successful")
                    else:
                        logger.error("❌ Fallback JSON parsing also failed")
                        raise ValueError("Failed to parse analysis results as JSON after fallback attempt")
                        
                except Exception as e:
                    logger.error(f"❌ Fallback analysis failed: {str(e)}")
                    raise ValueError("Failed to parse analysis results as JSON")    
            # Validate and normalize the response structure
            structured_results = self._validate_and_normalize_analysis(parsed_data)
            # Create raw outputs for compatibility (using the structured data)
            raw_outputs = {
                "personal_info_markdown": self._format_personal_info_markdown(structured_results.get('personal_info', {}), filename),
                "experience_markdown": self._format_experience_markdown(structured_results.get('experience', {})),
                "skills_markdown": self._format_skills_markdown(structured_results.get('skills', {})),
                "education_markdown": self._format_education_markdown(structured_results.get('education', {})),
                "quality_markdown": self._format_quality_markdown(structured_results.get('quality', {}))
            }
            logger.info("📚 Unified analysis completed successfully")
            logger.info(
                "   Structured results => %s",
                ", ".join([f"{k}:{len(v) if isinstance(v, dict) else 0}" for k, v in structured_results.items()]) or "none"
            )
            return {
                "structured": structured_results,
                "raw_outputs": raw_outputs
            }
        except Exception as e:
            logger.error(f"❌ Unified analysis failed: {str(e)}")
            raise
    
    def _validate_and_normalize_analysis(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and normalize the unified analysis response structure."""
        try:
            # Ensure all required top-level keys exist
            required_keys = ["personal_info", "experience", "skills", "education", "quality", "key_strengths", "improvement_areas", "professional_summary", "confidence_score", "completeness_score"]
            normalized_data = {}
            
            for key in required_keys:
                if key in parsed_data:
                    normalized_data[key] = parsed_data[key]
                else:
                    # Create empty structure for missing keys
                    if key == "personal_info":
                        normalized_data[key] = {
                            "full_name": None, "email": None, "secondary_email": None,
                            "phone": None, "secondary_phone": None, "location": None,
                            "address": None, "linkedin_url": None, "github_url": None,
                            "portfolio_url": None, "other_profiles": [], "professional_title": None
                        }
                    elif key == "experience":
                        normalized_data[key] = {
                            "work_experience": [], "total_years_experience": 0.0,
                            "current_position": None, "current_company": None,
                            "career_progression_score": 0.5, "leadership_experience": False
                        }
                    elif key == "skills":
                        normalized_data[key] = {
                            "programming_languages": [], "frameworks_libraries": [],
                            "tools_technologies": [], "technical_skills": [],
                            "soft_skills": [], "methodologies": [],
                            "databases": [], "cloud_platforms": []
                        }
                    elif key == "education":
                        normalized_data[key] = {
                            "education": [], "highest_degree": None,
                            "relevant_education": False, "certifications": []
                        }
                    elif key == "quality":
                        normalized_data[key] = {
                            "overall_score": 0.5, "completeness_score": 0.5,
                            "relevance_score": 0.5, "presentation_score": 0.5,
                            "achievement_quantification_score": 0.5,
                            "technical_competency_score": 0.5,
                            "career_progression_score": 0.5,
                            "recommendations": [], "strengths": [], "areas_for_improvement": []
                        }
                    elif key == "key_strengths":
                        normalized_data[key] = []
                    elif key == "improvement_areas":
                        normalized_data[key] = []
                    elif key == "professional_summary":
                        normalized_data[key] = ""
                    elif key == "confidence_score":
                        normalized_data[key] = 0.5
                    elif key == "completeness_score":
                        normalized_data[key] = 0.5
            
            # Validate and normalize skills structure
            if "skills" in normalized_data:
                skills = normalized_data["skills"]
                skill_categories = ["programming_languages", "frameworks_libraries", 
                                  "tools_technologies", "technical_skills", 
                                  "soft_skills", "methodologies"]
                
                for category in skill_categories:
                    if category not in skills or not isinstance(skills[category], list):
                        skills[category] = []
                    else:
                        # Ensure each skill entry has required fields
                        normalized_skills = []
                        for skill in skills[category]:
                            if isinstance(skill, dict) and "skill" in skill:
                                normalized_skill = {
                                    "skill": skill.get("skill", ""),
                                    "proficiency": skill.get("proficiency", "Intermediate"),
                                    "years_experience": skill.get("years_experience", "1+"),
                                    "context_demonstrated": skill.get("context_demonstrated", ""),
                                    "frequency_of_use": skill.get("frequency_of_use", "Occasionally"),
                                    "evidence_of_expertise": skill.get("evidence_of_expertise", ""),
                                    "core_or_supporting": skill.get("core_or_supporting", "Supporting"),
                                    "current_or_outdated": skill.get("current_or_outdated", "Current"),
                                    "emerging": skill.get("emerging", False),
                                    "relevance_score": float(skill.get("relevance_score", 0.5))
                                }
                                normalized_skills.append(normalized_skill)
                        skills[category] = normalized_skills
            
            # Validate experience structure
            if "experience" in normalized_data:
                exp = normalized_data["experience"]
                if "work_experience" not in exp or not isinstance(exp["work_experience"], list):
                    exp["work_experience"] = []
                else:
                    # Ensure each work experience entry has required fields
                    normalized_experiences = []
                    for work_exp in exp["work_experience"]:
                        if isinstance(work_exp, dict):
                            normalized_exp = {
                                "position": work_exp.get("position", ""),
                                "company": work_exp.get("company", ""),
                                "duration": work_exp.get("duration", ""),
                                "achievements": work_exp.get("achievements", []),
                                "start_date": work_exp.get("start_date", ""),
                                "end_date": work_exp.get("end_date", ""),
                                "location": work_exp.get("location", ""),
                                "employment_type": work_exp.get("employment_type", ""),
                                "technologies_used": work_exp.get("technologies_used", []),
                                "team_size": work_exp.get("team_size", ""),
                                "responsibilities": work_exp.get("responsibilities", [])
                            }
                            normalized_experiences.append(normalized_exp)
                    exp["work_experience"] = normalized_experiences
                
                # Ensure numeric fields are properly typed
                exp["total_years_experience"] = float(exp.get("total_years_experience", 0.0))
                exp["career_progression_score"] = float(exp.get("career_progression_score", 0.5))
                exp["leadership_experience"] = bool(exp.get("leadership_experience", False))
            
            # Validate education structure
            if "education" in normalized_data:
                edu = normalized_data["education"]
                if "education" not in edu or not isinstance(edu["education"], list):
                    edu["education"] = []
                else:
                    # Ensure each education entry has required fields
                    normalized_education = []
                    for ed in edu["education"]:
                        if isinstance(ed, dict):
                            normalized_ed = {
                                "degree": ed.get("degree", ""),
                                "institution": ed.get("institution", ""),
                                "graduation_year": ed.get("graduation_year", ""),
                                "field_of_study": ed.get("field_of_study", ""),
                                "gpa": ed.get("gpa", ""),
                                "location": ed.get("location", ""),
                                "honors": ed.get("honors", "")
                            }
                            normalized_education.append(normalized_ed)
                    edu["education"] = normalized_education
                
                if "certifications" not in edu or not isinstance(edu["certifications"], list):
                    edu["certifications"] = []
                else:
                    # Ensure each certification entry has required fields
                    normalized_certs = []
                    for cert in edu["certifications"]:
                        if isinstance(cert, dict):
                            normalized_cert = {
                                "name": cert.get("name", ""),
                                "issuer": cert.get("issuer", ""),
                                "date_earned": cert.get("date_earned", ""),
                                "expiration_date": cert.get("expiration_date", ""),
                                "credential_id": cert.get("credential_id", "")
                            }
                            normalized_certs.append(normalized_cert)
                    edu["certifications"] = normalized_certs
                
                edu["relevant_education"] = bool(edu.get("relevant_education", False))
            
            # Validate quality structure
            if "quality" in normalized_data:
                quality = normalized_data["quality"]
                quality_fields = ["overall_score", "completeness_score", "relevance_score", 
                                "presentation_score", "achievement_quantification_score",
                                "technical_competency_score", "career_progression_score"]
                
                for field in quality_fields:
                    quality[field] = float(quality.get(field, 0.5))
                
                list_fields = ["recommendations", "strengths", "areas_for_improvement"]
                for field in list_fields:
                    if field not in quality or not isinstance(quality[field], list):
                        quality[field] = []
            
            # Validate new top-level fields
            if "key_strengths" in normalized_data:
                if not isinstance(normalized_data["key_strengths"], list):
                    normalized_data["key_strengths"] = []
            
            if "improvement_areas" in normalized_data:
                if not isinstance(normalized_data["improvement_areas"], list):
                    normalized_data["improvement_areas"] = []
            
            if "professional_summary" in normalized_data:
                if not isinstance(normalized_data["professional_summary"], str):
                    normalized_data["professional_summary"] = ""
            
            if "confidence_score" in normalized_data:
                normalized_data["confidence_score"] = float(normalized_data.get("confidence_score", 0.5))
            
            if "completeness_score" in normalized_data:
                normalized_data["completeness_score"] = float(normalized_data.get("completeness_score", 0.5))
            
            logger.info("✅ Analysis data validated and normalized successfully")
            return normalized_data
                
        except Exception as e:
            logger.error(f"❌ Failed to validate analysis data: {str(e)}")
            # Return minimal valid structure on error
            return {
                "personal_info": {"full_name": None, "email": None, "secondary_email": None,
                                "phone": None, "secondary_phone": None, "location": None,
                                "address": None, "linkedin_url": None, "github_url": None,
                                "portfolio_url": None, "other_profiles": [], "professional_title": None},
                "experience": {"work_experience": [], "total_years_experience": 0.0,
                              "current_position": None, "current_company": None,
                              "career_progression_score": 0.5, "leadership_experience": False},
                "skills": {"programming_languages": [], "frameworks_libraries": [],
                          "tools_technologies": [], "technical_skills": [],
                          "soft_skills": [], "methodologies": [],
                          "databases": [], "cloud_platforms": []},
                "education": {"education": [], "highest_degree": None,
                             "relevant_education": False, "certifications": []},
                "quality": {"overall_score": 0.5, "completeness_score": 0.5,
                           "relevance_score": 0.5, "presentation_score": 0.5,
                           "achievement_quantification_score": 0.5,
                           "technical_competency_score": 0.5, "career_progression_score": 0.5,
                           "recommendations": [], "strengths": [], "areas_for_improvement": []},
                "key_strengths": [],
                "improvement_areas": [],
                "professional_summary": "",
                "confidence_score": 0.5,
                "completeness_score": 0.5
            }
    
    
    async def _process_crewai_results(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Parse skills analysis from AI analysis text."""
        try:
            logger.info(f"_parse_skills_analysis text: {analysis_results}")
            # Enhanced LLM extraction for comprehensive skills
            prompt = f"""
            SYSTEM
            You are an expert information extractor. Analyze the provided TEXT (resume/CV/profile/analysis) and return ONLY a single **valid JSON object** matching the EXACT schema below. Do not include any extra text, comments, or markdown.

            OBJECTIVE
            Extract every possible skill (technical, soft, methodologies, certifications, languages, etc.) — including implied skills — normalize names, deduplicate, and populate ALL categories. If data is missing, use best judgment or leave arrays empty, but NEVER omit keys. Prefer completeness over brevity.

            INPUT
            TEXT TO ANALYZE:
            {analysis_results}

            NORMALIZATION RULES
            - Map aliases to canonical names (non-exhaustive examples):
            - JS, Node → JavaScript; TS → TypeScript; Py → Python
            - MS Azure, Azure Cloud → Azure; AWS Cloud → AWS; GCP Cloud → Google Cloud
            - Postgres → PostgreSQL; MySQL DB → MySQL
            - ReactJS → React; Next → Next.js; ExpressJS → Express.js
            - CI/CD Pipeline → CI/CD; GitHub Actions → GitHub Actions (Tools)
            - Docker Compose → Docker; Kubernetes (K8s) → Kubernetes
            - NLP → Natural Language Processing; LLM → Large Language Models
            - RPA → Robotic Process Automation
            - Place technologies in the most specific category (e.g., Django → frameworks_libraries; Docker → tools_technologies).
            - Prefer product names to vendors when clearer (e.g., “EC2” under tools_technologies; vendor “AWS” can also appear in tools_technologies).

            SCORING & ESTIMATION
            - proficiency ∈ {{“Basic”, “Intermediate”, “Advanced”, “Expert”}}
            - years_experience: string like “<1”, “1+”, “2+”, “3+”, “5+”, “8+”, “10+”
            - frequency_of_use ∈ {{“Rarely”, “Occasionally”, “Weekly”, “Daily”}}
            - core_or_supporting ∈ {{“Core”, “Supporting”}}
            - current_or_outdated ∈ {{“Current”, “Outdated”}}
            - emerging: boolean (true if trend/early-stage or newly adopted by candidate)
            - relevance_score: float between 0 and 1 (two decimals), reflecting relevance to the overall profile described by the TEXT
            - When uncertain, infer conservatively from context (recency cues, project durations, job timelines, stack descriptions).

            OUTPUT SCHEMA (RETURN EXACTLY THESE KEYS)
            {{
              "programming_languages": [ {{ SkillEntry }} ],
              "frameworks_libraries": [ {{ SkillEntry }} ],
              "tools_technologies": [ {{ SkillEntry }} ],
              "technical_skills": [ {{ SkillEntry }} ],
              "soft_skills": [ {{ SkillEntry }} ],
              "methodologies": [ {{ SkillEntry }} ]
            }}

            Where:
            SkillEntry = {{
            "skill": string,
            "proficiency": "Basic|Intermediate|Advanced|Expert",
            "years_experience": string,
            "context_demonstrated": string,
            "frequency_of_use": "Rarely|Occasionally|Weekly|Daily",
            "evidence_of_expertise": string,
            "core_or_supporting": "Core|Supporting",
            "current_or_outdated": "Current|Outdated",
            "emerging": boolean,
            "relevance_score": number
            }}

            POPULATION RULES
            - Populate category arrays with the subset of SkillEntry items relevant to that category.
            - must include EVERY skill discovered (union of all categories), each as a single SkillEntry (no duplicates).
            - Do NOT invent certifications without strong evidence. If uncertain, leave certifications empty.
            - Spoken languages go to “languages”; programming languages stay in “programming_languages”.
            - Methodologies include Agile, Scrum, Kanban, TDD, BDD, DevOps practices, CRISP-DM, etc.
            - Key competencies capture higher-level capabilities (e.g., “System Design”, “Solution Architecture”, “Stakeholder Management”, “MLOps”).

            VALIDATION
            - Output must be a single JSON object with ALL top-level keys present.
            - Arrays may be empty but must exist.
            - All numbers must be valid JSON numbers (no strings) for relevance_score.
            - No trailing commas. No markdown fences. No spaces
            
            CRITICAL: 
               - Return ONLY a single JSON object with ALL top-level keys present. 
               - Remove all spaces and new lines. generate very compact json.
               - Make to to generate valid json always, No half terminated json or half terminated arrays or half terminated objects.
               - If you cannot fill a field, return an empty string or array, but keep JSON valid.
               - Generate onlymax of 5 skills for each category.
               - try to generate valid json which can fit in 8000 tokens. no extra spaces or new lines.
            NOW PRODUCE THE JSON RESULT ONLY.
            """
            
            # Use higher max_tokens only for skills extraction
            try:
                _bind = getattr(self.llm, "bind", None)
                skills_llm = self.llm.bind(max_tokens=8192) if callable(_bind) else self.llm
            except Exception:
                skills_llm = self.llm
            
            # Helper: validate and normalize parsed payload to expected schema
            def _normalize_skills_payload(parsed: dict) -> dict | None:
                if not isinstance(parsed, dict):
                    return None
                # Accept payloads without detailed_table; treat top-level categorized arrays as authoritative
                known_sections = [
                    "programming_languages", "frameworks_libraries", "tools_technologies",
                    "technical_skills", "soft_skills", "certifications", "methodologies",
                    "languages", "key_competencies", "emerging_skills"
                ]
                has_any = any(isinstance(parsed.get(sec), list) for sec in known_sections)
                if not has_any and not isinstance(parsed.get("detailed_table"), (dict, list)):
                    # Not a recognizable skills payload
                    return None
                # Normalize each known section to a list of SkillEntry dicts
                for sec in known_sections:
                    vals = parsed.get(sec)
                    if vals is None:
                        continue
                    if isinstance(vals, list):
                        normalized = []
                        for item in vals:
                            if isinstance(item, dict):
                                entry = dict(item)
                                if "skill" not in entry and "name" in entry:
                                    entry["skill"] = entry.get("name")
                                if isinstance(entry.get("skill"), str) and entry["skill"].strip():
                                    if "relevance_score" not in entry:
                                        entry["relevance_score"] = 0.5
                                    normalized.append(entry)
                            elif isinstance(item, str):
                                s = item.strip()
                                if s:
                                    normalized.append({"skill": s, "relevance_score": 0.5})
                        parsed[sec] = normalized
                    else:
                        # If not a list, remove invalid value
                        parsed[sec] = []
                # If a detailed_table exists, keep it as-is; otherwise omit it entirely
                if "detailed_table" in parsed and not isinstance(parsed["detailed_table"], dict):
                    parsed.pop("detailed_table", None)
                return parsed

            # Raw JSON extraction path (with normalization/validation)
            try:
                
                expected_top_keys = {
                    "technical_skills", "soft_skills", "programming_languages", "frameworks_libraries",
                    "tools_technologies", "certifications", "methodologies", "languages",
                    "key_competencies", "emerging_skills", "detailed_table"
                }

                def _balanced_json_candidates(s: str) -> list[str]:
                    """Return all balanced JSON object substrings found in fenced blocks first, then globally."""
                    s = s or ""
                    # print("s", s)
                    candidates: list[str] = []
                    # Collect from fenced blocks
                    for fence in re.finditer(r"```json\s*([\s\S]*?)\s*```", s, re.IGNORECASE):
                        inner = fence.group(1) or ""
                        start = inner.find('{')
                        while start != -1:
                            depth = 0
                            for i in range(start, len(inner)):
                                ch = inner[i]
                                if ch == '{':
                                    depth += 1
                                elif ch == '}':
                                    depth -= 1
                                    if depth == 0:
                                        candidates.append(inner[start:i+1])
                                        break
                            start = inner.find('{', start + 1)
                    # Also consider generic fenced blocks
                    for fence in re.finditer(r"```\s*([\s\S]*?)\s*```", s, re.IGNORECASE):
                        inner = fence.group(1) or ""
                        start = inner.find('{')
                        while start != -1:
                            depth = 0
                            for i in range(start, len(inner)):
                                ch = inner[i]
                                if ch == '{':
                                    depth += 1
                                elif ch == '}':
                                    depth -= 1
                                    if depth == 0:
                                        candidates.append(inner[start:i+1])
                                        break
                            start = inner.find('{', start + 1)
                    # Global scan across full string
                    start = s.find('{')
                    while start != -1:
                        depth = 0
                        for i in range(start, len(s)):
                            ch = s[i]
                            if ch == '{':
                                depth += 1
                            elif ch == '}':
                                depth -= 1
                                if depth == 0:
                                    candidates.append(s[start:i+1])
                                    break
                        start = s.find('{', start + 1)
                    return candidates

                def _select_best_json(cands: list[str]) -> str | None:
                    """Pick the candidate that parses and best matches expected schema; fallback to largest valid object."""
                    best: tuple[int, int, str] | None = None  # (score, length, candidate)
                    for cand in cands:
                        try:
                            obj = json.loads(cand)
                        except Exception:
                            continue
                        if not isinstance(obj, dict):
                            continue
                        keys = set(obj.keys())
                        score = len(keys.intersection(expected_top_keys))
                        length = len(cand)
                        # Penalize single SkillEntry-shaped objects with 'skill' and 'proficiency' only
                        if ("skill" in obj and "proficiency" in obj and score == 0 and len(obj) <= 10):
                            score = -1
                        if best is None or (score, length) > (best[0], best[1]):
                            best = (score, length, cand)
                    return best[2] if best else None

                def _extract_json_balanced_best(s: str) -> str | None:
                    return _select_best_json(_balanced_json_candidates(s))

                # 2) Fallback: single LLM call and parse JSON from its response
                logger.info("🧪 Invoking LLM for skills analysis extraction (single pass, raw)")
                response = await skills_llm.ainvoke(prompt)
                result_text = (response.content or "").strip()
                # print("result_text", result_text)
                # print("---end of result_text---")
                try:
                    preview = result_text.replace("\n", " ")
                    logger.info(f"🧪 LLM response received for skills: length={len(result_text)}...'")
                except Exception:
                    logger.info("🧪 LLM response received for skills (preview unavailable)")
                # print("json.loads(result_text)", json.loads(result_text))
                llm_json = _extract_json_balanced_best(result_text)
                if llm_json:
                    try:
                        parsed_llm = json.loads(llm_json)
                        if isinstance(parsed_llm, dict):
                            normalized_llm = _normalize_skills_payload(parsed_llm)
                            if normalized_llm is not None:
                                logger.info("✅ Parsed skills JSON from LLM response; schema-normalized")
                                return normalized_llm
                            else:
                                logger.info("⚠️ LLM JSON had invalid shape; will attempt strict conformance")
                    except Exception:
                        logger.warning("⚠️ Failed to parse JSON extracted from LLM response")
                logger.warning("Failed to extract skills JSON in early path; will attempt strict parser next")
                raise ValueError("early-path-parse-failed")
            except Exception as inner_e:
                logger.warning(f"Skills raw JSON extraction failed early path: {inner_e}")

            logger.info("🧪 Invoking LLM for skills analysis extraction (structured JSON)")
            response = await skills_llm.ainvoke(prompt)
            result_text = response.content.strip()
            try:
                preview = (result_text or "").replace("\n", " ")
                logger.info(f"🧪 LLM response received for skills: length={len(result_text)} preview='{preview}......'")
            except Exception:
                logger.info("🧪 LLM response received for skills (preview unavailable)")
            
            # Enhanced JSON extraction with balanced-brace parsing
            
            # Use best-candidate JSON extraction that prefers full schema objects
            def _extract_first_balanced_json(s: str) -> str | None:
                return _extract_json_balanced_best(s)

            parsed_data = None
            json_str = _extract_first_balanced_json(result_text)
            if json_str:
                try:
                    parsed_data = json.loads(json_str)
                    logger.info("✅ Parsed skills JSON on first attempt")
                except json.JSONDecodeError:
                    parsed_data = None
                    logger.info("⚠️ First JSON parse failed; will attempt strict JSON-only retry")
            
            # Strict JSON-only retry if first parse failed
            if not parsed_data:
                try:
                    strict_prompt = f"""
                    Return ONLY a valid JSON object for skills_analysis with ALL sections populated and a
                    populated detailed_table. No prose, no code fences, no comments. Use the schema described above.
                    Text:\n{analysis_results}
                    """
                    logger.info("🧪 Invoking strict JSON-only retry for skills parsing")
                    response2 = await skills_llm.ainvoke(strict_prompt)
                    json_str2 = _extract_first_balanced_json(response2.content.strip())
                    if json_str2:
                        parsed_data = json.loads(json_str2)
                        if parsed_data is not None:
                            logger.info("✅ Strict JSON-only retry succeeded for skills parsing")
                except Exception:
                    parsed_data = None
            
            if parsed_data:
                # Normalize/validate schema and coerce top-level arrays to strings
                parsed_data = _normalize_skills_payload(parsed_data) or {}
                if not parsed_data:
                    logger.info("⚠️ Parsed JSON had invalid/empty shape after normalization; attempting strict conformance")
                    # Try strict JSON-only retry once more
                    try:
                        strict_prompt = f"""
                        Return ONLY a valid JSON object for skills_analysis with ALL sections populated and a
                        populated detailed_table. No prose, no code fences, no comments. Use the schema described above.
                        Text:\n{analysis_results}
                        """
                        logger.info("🧪 Invoking strict JSON-only retry for skills parsing (post-normalization)")
                        response2b = await self.llm.ainvoke(strict_prompt)
                        json_str2b = _extract_first_balanced_json(response2b.content.strip())
                        if json_str2b:
                            attempted = json.loads(json_str2b)
                            parsed_data = _normalize_skills_payload(attempted) or {}
                    except Exception:
                        parsed_data = {}
                
                # Normalize detailed_table rows to include relevance_score
                try:
                    detailed = parsed_data.get("detailed_table") or {}
                    added_scores = 0
                    for section, rows in list(detailed.items()):
                        if isinstance(rows, list):
                            for row in rows:
                                if isinstance(row, dict) and "relevance_score" not in row:
                                    # When missing, ask model likely estimated it already; keep default neutral 0.5
                                    row["relevance_score"] = 0.5
                                    added_scores += 1
                    parsed_data["detailed_table"] = detailed
                    try:
                        # Log section sizes to understand table population
                        sec_summ = ", ".join([
                            f"{k}:{len(v) if isinstance(v, list) else 0}" for k, v in detailed.items()
                        ]) or "none"
                        logger.info(f"🧮 detailed_table sections => {sec_summ}; defaulted relevance_score for {added_scores} rows")
                    except Exception:
                        pass
                except Exception:
                    # Keep structure as-is if normalization fails
                    pass

                # If detailed_table is empty, run a targeted AI pass to construct it
                if not parsed_data.get("detailed_table"):
                    try:
                        logger.info("🧪 Attempting targeted reconstruction of detailed_table from parsed skill lists")
                        reconstruction_prompt = f"""
                        You are given skill lists parsed from a resume. Build ONLY the detailed_table JSON
                        described below. Infer per-skill proficiency, years_experience (string), context_demonstrated,
                        frequency_of_use, evidence_of_expertise, core_or_supporting, current_or_outdated, emerging,
                        and a numeric relevance_score in [0,1] reflecting how central the skill is to the profile.

                        Input (JSON):
                        {json.dumps({k: parsed_data.get(k) for k in [
                            'programming_languages','frameworks_libraries','tools_technologies','soft_skills',
                            'technical_skills','skill_categories','years_experience','skill_proficiency'
                        ]}, ensure_ascii=False)}

                        Return ONLY this JSON object (no prose):
                        {{
                          "programming_languages": [{{"skill":"","proficiency":"","years_experience":"","context_demonstrated":"","frequency_of_use":"","evidence_of_expertise":"","core_or_supporting":"","current_or_outdated":"","emerging":false,"relevance_score":0.0}}],
                          "frameworks_libraries": [],
                          "tools_technologies": [],
                          "soft_skills": []
                        }}
                        """
                        resp2 = await skills_llm.ainvoke(reconstruction_prompt)
                        js2 = _extract_first_balanced_json(resp2.content.strip())
                        if js2:
                            dt = json.loads(js2)
                            if isinstance(dt, dict):
                                parsed_data["detailed_table"] = dt
                                try:
                                    sec_summ2 = ", ".join([
                                        f"{k}:{len(v) if isinstance(v, list) else 0}" for k, v in dt.items()
                                    ]) or "none"
                                    logger.info(f"✅ Reconstructed detailed_table; sections => {sec_summ2}")
                                except Exception:
                                    pass
                    except Exception as _:
                        # Keep whatever we have; no manual fallback
                        pass
                        
                # Summarize parsed content sizes (avoid logging PII)
                try:
                    def _len_list(val):
                        return len(val) if isinstance(val, list) else 0
                    summary_counts = {
                        "technical_skills": _len_list(parsed_data.get("technical_skills")),
                        "soft_skills": _len_list(parsed_data.get("soft_skills")),
                        "programming_languages": _len_list(parsed_data.get("programming_languages")),
                        "frameworks_libraries": _len_list(parsed_data.get("frameworks_libraries")),
                        "tools_technologies": _len_list(parsed_data.get("tools_technologies")),
                        "certifications": _len_list(parsed_data.get("certifications")),
                        "methodologies": _len_list(parsed_data.get("methodologies")),
                        "languages": _len_list(parsed_data.get("languages")),
                        "key_competencies": _len_list(parsed_data.get("key_competencies")),
                        "emerging_skills": _len_list(parsed_data.get("emerging_skills")),
                    }
                    logger.info(
                        "📊 Parsed skills summary => %s",
                        ", ".join([f"{k}:{v}" for k, v in summary_counts.items()])
                    )
                    sc = parsed_data.get("skill_categories") or {}
                    if isinstance(sc, dict):
                        logger.info(
                            "📚 skill_categories => %s",
                            ", ".join([f"{k}:{len(v) if isinstance(v, list) else 0}" for k, v in sc.items()]) or "none"
                        )
                except Exception:
                    pass

                # If still effectively empty, attempt full reconstruction via AI
                top_arrays = [
                    "technical_skills", "soft_skills", "programming_languages", "frameworks_libraries",
                    "tools_technologies", "certifications", "methodologies", "languages",
                    "key_competencies", "emerging_skills"
                ]
                total_count = sum(len(parsed_data.get(k) or []) for k in top_arrays)
                has_dt = isinstance(parsed_data.get("detailed_table"), dict) and any(
                    len(v or []) > 0 for v in parsed_data.get("detailed_table").values()
                )
                if total_count == 0 and not has_dt:
                    try:
                        logger.info("🧪 Parsed skills empty; attempting full skills_analysis reconstruction from text")
                        rebuild_prompt = f"""
                        Build a COMPLETE skills_analysis JSON (same schema as earlier with lists of strings and a populated
                        detailed_table dict keyed by categories) from the following text. Return JSON ONLY without code fences. Include
                        realistic relevance_score per skill in [0,1].
                        Text:\n{analysis_results}
                        """
                        resp3b = await skills_llm.ainvoke(rebuild_prompt)
                        js3b = _extract_first_balanced_json(resp3b.content.strip())
                        if js3b:
                            parsed_data2b = json.loads(js3b)
                            parsed_data = _normalize_skills_payload(parsed_data2b) or parsed_data
                            if parsed_data is not None:
                                logger.info("✅ Rebuilt skills_analysis via reconstruction path (post-empty)")
                    except Exception:
                        pass

                return parsed_data
            else:
                try:
                    preview2 = (result_text or "")[:300].replace("\n", " ")
                    logger.warning(f"Failed to parse skills JSON; preview='{preview2[:150]}...'")
                except Exception:
                    logger.warning("Failed to parse skills JSON; preview unavailable")
                # As a last resort, rebuild entire skills_analysis from text
                try:
                    logger.info("🧪 Attempting full skills_analysis reconstruction from text")
                    rebuild_prompt = f"""
                    Build a COMPLETE skills_analysis JSON (same schema as earlier with lists and populated
                    detailed_table) from the following text. Return JSON ONLY without code fences. Include
                    realistic relevance_score per skill in [0,1].
                    Text:\n{analysis_results}
                    """
                    resp3 = await skills_llm.ainvoke(rebuild_prompt)
                    js3 = _extract_first_balanced_json(resp3.content.strip())
                    if js3:
                        parsed_data2 = json.loads(js3)
                        if isinstance(parsed_data2, dict):
                            # Ensure expected fields
                            expected_fields = {
                                "technical_skills": [],
                                "soft_skills": [],
                                "programming_languages": [],
                                "frameworks_libraries": [],
                                "tools_technologies": [],
                                "certifications": [],
                                "methodologies": [],
                                "languages": [],
                                "skill_categories": {},
                                "skill_proficiency": {},
                                "years_experience": {},
                                "key_competencies": [],
                                "emerging_skills": [],
                                "detailed_table": {}
                            }
                            for field, default in expected_fields.items():
                                if field not in parsed_data2:
                                    parsed_data2[field] = default
                            logger.info("✅ Rebuilt skills_analysis from text via reconstruction path")
                            return parsed_data2
                except Exception:
                    pass
                
        except Exception as e:
            logger.warning(f"Failed to parse skills: {e}")
            
        # No manual fallback per AI-first policy: return structured empty payload
        return {
            "technical_skills": [],
            "soft_skills": [],
            "programming_languages": [],
            "frameworks_libraries": [],
            "tools_technologies": [],
            "certifications": [],
            "methodologies": [],
            "languages": [],
            "skill_categories": {},
            "skill_proficiency": {},
            "years_experience": {},
            "key_competencies": [],
            "emerging_skills": [],
            "detailed_table": {}
        }
    
    async def _parse_education_analysis(self, text: str) -> Dict[str, Any]:
        """Parse education analysis from AI analysis text."""
        try:
            # Use LLM to extract structured education info
            prompt = f"""
            Extract education information from this analysis and return ONLY a JSON object:
            
            {text}
            
            Return exactly this JSON format:
            {{
                "education": [
                    {{
                        "degree": "degree name",
                        "institution": "university name", 
                        "graduation_year": "year",
                        "field_of_study": "major"
                    }}
                ],
                "highest_degree": "highest degree level",
                "relevant_education": true
            }}
            """
            
            response = await self.llm.ainvoke(prompt)
            result_text = response.content.strip()
            
            # Try to parse as JSON
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
            if json_match:
                parsed = json.loads(json_match.group())
                return parsed
            else:
                logger.warning(f"Failed to parse education JSON: {result_text}")
                
        except Exception as e:
            logger.warning(f"Failed to parse education: {e}")
            
        # Fallback: manual extraction
        return self._extract_education_fallback(text)
    
    async def _parse_experience_analysis(self, text: str) -> Dict[str, Any]:
        """Parse experience analysis from AI analysis text."""
        try:
            # Use LLM to extract structured experience info
            prompt = f"""
            Extract work experience information from this analysis and return ONLY a JSON object:
            
            {text}
            
            Return exactly this JSON format:
            {{
                "work_experience": [
                    {{
                        "position": "job title",
                        "company": "company name",
                        "duration": "years",
                        "achievements": ["achievement1", "achievement2"]
                    }}
                ],
                "total_years_experience": 5.0,
                "current_position": "current job title",
                "current_company": "current company",
                "career_progression_score": 0.8,
                "leadership_experience": true
            }}
            """
            
            response = await self.llm.ainvoke(prompt)
            result_text = response.content.strip()
            
            # Try to parse as JSON
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
            if json_match:
                parsed = json.loads(json_match.group())
                return parsed
            else:
                logger.warning(f"Failed to parse experience JSON: {result_text}")
                
        except Exception as e:
            logger.warning(f"Failed to parse experience: {e}")
            
        # Fallback: manual extraction
        return self._extract_experience_fallback(text)
    
    async def _parse_quality_assessment(self, text: str) -> Dict[str, Any]:
        """Parse quality assessment from AI analysis text."""
        try:
            # Use LLM to extract structured quality info
            prompt = f"""
            Extract quality scores from this analysis and return ONLY a JSON object:
            
            {text}
            
            Return exactly this JSON format:
            {{
                "overall_score": "calculate_actual_score",
                "completeness_score": "assess_completeness",
                "relevance_score": "evaluate_relevance",
                "presentation_score": "assess_presentation",
                "recommendations": ["list_actual_recommendations"]
            }}
            """
            
            response = await self.llm.ainvoke(prompt)
            result_text = response.content.strip()
            
            # Try to parse as JSON
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
            if json_match:
                parsed = json.loads(json_match.group())
                return parsed
            else:
                logger.warning(f"Failed to parse quality JSON: {result_text}")
                
        except Exception as e:
            logger.warning(f"Failed to parse quality: {e}")
            
        # Fallback: return empty structure
        return {
            "overall_score": 0.5,
            "completeness_score": 0.5,
            "relevance_score": 0.5,
            "presentation_score": 0.5,
            "recommendations": []
        }
    
    def _extract_personal_info_fallback(self, text: str) -> Dict[str, Any]:
        """Enhanced fallback personal info extraction using regex and text analysis."""
        
        # Enhanced regex patterns
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        phone_patterns = [
            r'\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',  # Standard formats
            r'\(\d{3}\)\s?\d{3}[-.\s]?\d{4}',  # (123) 456-7890
            r'\d{3}[-.\s]?\d{3}[-.\s]?\d{4}',  # 123-456-7890
            r'\+\d{1,3}\s?\d{3,4}\s?\d{3,4}\s?\d{3,4}'  # International format
        ]
        
        # URL patterns
        linkedin_pattern = r'(?:https?://)?(?:www\.)?linkedin\.com/in/[\w-]+'
        github_pattern = r'(?:https?://)?(?:www\.)?github\.com/[\w-]+'
        portfolio_patterns = [
            r'(?:https?://)?(?:www\.)?[\w-]+\.(?:com|io|org|net)/[\w-]*',
            r'(?:https?://)?[\w-]+\.(?:dev|tech|portfolio)/?'
        ]
        
        # Location patterns
        location_patterns = [
            r'\b[A-Z][a-z]+,\s*[A-Z]{2}\b',  # City, ST
            r'\b[A-Z][a-z]+,\s*[A-Z][a-z]+\b',  # City, Country
            r'\b[A-Z][a-z]+,\s*[A-Z][a-z]+,\s*[A-Z]{2,3}\b'  # City, State, Country
        ]
        
        # Name extraction (look at beginning of text)
        name_patterns = [
            r'^([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # First line name
            r'Name:\s*([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # Name: format
        ]
        
        # Extract information
        emails = re.findall(email_pattern, text, re.IGNORECASE)
        
        # Extract phones using multiple patterns
        phones = []
        for pattern in phone_patterns:
            phones.extend(re.findall(pattern, text))
        
        # Extract URLs
        linkedin_urls = re.findall(linkedin_pattern, text, re.IGNORECASE)
        github_urls = re.findall(github_pattern, text, re.IGNORECASE)
        
        portfolio_urls = []
        for pattern in portfolio_patterns:
            portfolio_urls.extend(re.findall(pattern, text, re.IGNORECASE))
        
        # Extract locations
        locations = []
        for pattern in location_patterns:
            locations.extend(re.findall(pattern, text))
        
        # Extract name
        name = None
        for pattern in name_patterns:
            match = re.search(pattern, text, re.MULTILINE)
            if match:
                name = match.group(1).strip()
                break
        
        # If no name found, try to extract from email
        if not name and emails:
            email_name = emails[0].split('@')[0]
            # Convert email username to potential name
            name_parts = re.split(r'[._-]', email_name)
            if len(name_parts) >= 2:
                name = ' '.join(part.capitalize() for part in name_parts[:2])
        
        return {
            "full_name": name,
            "email": emails[0] if emails else None,
            "secondary_email": emails[1] if len(emails) > 1 else None,
            "phone": phones[0] if phones else None,
            "secondary_phone": phones[1] if len(phones) > 1 else None,
            "location": locations[0] if locations else None,
            "address": None,
            "linkedin_url": linkedin_urls[0] if linkedin_urls else None,
            "github_url": github_urls[0] if github_urls else None,
            "portfolio_url": portfolio_urls[0] if portfolio_urls else None,
            "other_profiles": portfolio_urls[1:] if len(portfolio_urls) > 1 else [],
            "professional_title": None
        }
    
    def _extract_skills_fallback(self, text: str) -> Dict[str, Any]:
        """Enhanced fallback skills extraction using comprehensive keyword matching."""
        
        # Comprehensive skill databases
        programming_languages = [
            'Python', 'Java', 'JavaScript', 'TypeScript', 'C++', 'C#', 'C', 'Go', 'Rust', 'Kotlin',
            'Swift', 'Ruby', 'PHP', 'Scala', 'R', 'MATLAB', 'Perl', 'Objective-C', 'Dart', 'Julia'
        ]
        
        frameworks_libraries = [
            'React', 'Angular', 'Vue', 'Django', 'Flask', 'Express', 'Spring', 'Rails', 'Laravel',
            'Node.js', 'React Native', 'Flutter', 'Xamarin', 'Bootstrap', 'jQuery', 'Redux',
            'NextJS', 'NuxtJS', 'FastAPI', 'ASP.NET', 'Hibernate', 'TensorFlow', 'PyTorch', 'Pandas'
        ]
        
        tools_technologies = [
            'Git', 'Docker', 'Kubernetes', 'Jenkins', 'AWS', 'Azure', 'GCP', 'Linux', 'Windows',
            'MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Elasticsearch', 'Apache', 'Nginx',
            'Terraform', 'Ansible', 'Vagrant', 'Maven', 'Gradle', 'Webpack', 'Babel'
        ]
        
        databases = [
            'MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Cassandra', 'DynamoDB', 'Oracle',
            'SQLite', 'MariaDB', 'CouchDB', 'Neo4j', 'InfluxDB'
        ]
        
        cloud_platforms = [
            'AWS', 'Azure', 'Google Cloud', 'GCP', 'Heroku', 'DigitalOcean', 'Linode',
            'IBM Cloud', 'Oracle Cloud', 'Alibaba Cloud'
        ]
        
        soft_skills_keywords = [
            'leadership', 'teamwork', 'communication', 'problem solving', 'analytical',
            'project management', 'agile', 'scrum', 'mentoring', 'collaboration', 'adaptability',
            'time management', 'critical thinking', 'creativity', 'attention to detail'
        ]
        
        methodologies = [
            'Agile', 'Scrum', 'Kanban', 'DevOps', 'CI/CD', 'TDD', 'BDD', 'Waterfall',
            'Lean', 'Six Sigma', 'ITIL', 'SAFe'
        ]
        
        certifications_keywords = [
            'AWS Certified', 'Azure Certified', 'Google Cloud Certified', 'PMP', 'Scrum Master',
            'Six Sigma', 'CISSP', 'CompTIA', 'Oracle Certified', 'Microsoft Certified'
        ]
        
        # Extract skills using case-insensitive matching
        text_lower = text.lower()
        found_skills = {
            'programming_languages': [],
            'frameworks_libraries': [],
            'tools_technologies': [],
            'databases': [],
            'cloud_platforms': [],
            'soft_skills': [],
            'methodologies': [],
            'certifications': []
        }
        
        # Match programming languages
        for skill in programming_languages:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['programming_languages'].append(skill)
        
        # Match frameworks and libraries
        for skill in frameworks_libraries:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['frameworks_libraries'].append(skill)
        
        # Match tools and technologies
        for skill in tools_technologies:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['tools_technologies'].append(skill)
        
        # Match databases
        for skill in databases:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['databases'].append(skill)
        
        # Match cloud platforms
        for skill in cloud_platforms:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['cloud_platforms'].append(skill)
        
        # Match soft skills
        for skill in soft_skills_keywords:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['soft_skills'].append(skill.title())
        
        # Match methodologies
        for skill in methodologies:
            if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
                found_skills['methodologies'].append(skill)
        
        # Match certifications
        for cert in certifications_keywords:
            if cert.lower() in text_lower:
                found_skills['certifications'].append(cert)
        
        # Combine technical skills
        all_technical = (found_skills['programming_languages'] + 
                        found_skills['frameworks_libraries'] + 
                        found_skills['tools_technologies'] + 
                        found_skills['databases'] + 
                        found_skills['cloud_platforms'])
        
        # Create skill categories
        skill_categories = {}
        if found_skills['programming_languages']:
            skill_categories['Programming Languages'] = found_skills['programming_languages']
        if found_skills['frameworks_libraries']:
            skill_categories['Frameworks & Libraries'] = found_skills['frameworks_libraries']
        if found_skills['tools_technologies']:
            skill_categories['Tools & Technologies'] = found_skills['tools_technologies']
        if found_skills['databases']:
            skill_categories['Databases'] = found_skills['databases']
        if found_skills['cloud_platforms']:
            skill_categories['Cloud Platforms'] = found_skills['cloud_platforms']
        if found_skills['methodologies']:
            skill_categories['Methodologies'] = found_skills['methodologies']
        
        return {
            "technical_skills": all_technical,
            "soft_skills": found_skills['soft_skills'],
            "programming_languages": found_skills['programming_languages'],
            "frameworks_libraries": found_skills['frameworks_libraries'],
            "tools_technologies": found_skills['tools_technologies'],
            "certifications": found_skills['certifications'],
            "methodologies": found_skills['methodologies'],
            "languages": [],
            "skill_categories": skill_categories,
            "skill_proficiency": {},
            "years_experience": {},
            "key_competencies": all_technical[:10] if all_technical else [],
            "emerging_skills": []
        }
    
    def _extract_education_fallback(self, text: str) -> Dict[str, Any]:
        """Fallback education extraction."""
        degrees = ['BS', 'BA', 'MS', 'MA', 'PhD', 'Bachelor', 'Master', 'Doctor']
        found_degrees = []
        
        text_lower = text.lower()
        for degree in degrees:
            if degree.lower() in text_lower:
                found_degrees.append(degree)
        
        return {
            "education": [],
            "highest_degree": found_degrees[0] if found_degrees else None,
            "relevant_education": len(found_degrees) > 0
        }
    
    def _extract_experience_fallback(self, text: str) -> Dict[str, Any]:
        """Fallback experience extraction.""" 
        return {
            "work_experience": [],
            "total_years_experience": None,
            "current_position": None,
            "current_company": None,
            "career_progression_score": 0.5,
            "leadership_experience": False
        }
    
    async def _process_crewai_results(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Process CrewAI analysis results using enhanced parsing methods."""
        try:
            logger.info("📊 Processing CrewAI results with enhanced parsing...")
            
            # Extract structured results from the new format
            structured_data = analysis_results.get("structured", {})
            raw_outputs = analysis_results.get("raw_outputs", {})
            
            # Use the enhanced parsing methods to extract structured data
            processed_results = {
                "personal_info": structured_data.get("personal_info", {}),
                "career_analysis": structured_data.get("experience", {}), 
                "skills_analysis": structured_data.get("skills", {}),
                "education_analysis": structured_data.get("education", {}),
                "quality_assessment": structured_data.get("quality", {}),
                # Include raw outputs for storage in database
                "agent_raw_outputs": raw_outputs
            }
            
            logger.info("✅ CrewAI results processed successfully")
            return processed_results
            
        except Exception as e:
            logger.error(f"❌ Failed to process CrewAI results: {str(e)}")
            # Return structured empty results
            return {
                "personal_info": {},
                "career_analysis": {},
                "skills_analysis": {},
                "education_analysis": {},
                "quality_assessment": {},
                "agent_raw_outputs": {}
            }
    
    def _generate_summary_from_crewai(self, personal_info: Dict, experience_data: Dict, skills_data: Dict) -> str:
        """Generate professional summary from CrewAI data."""
        summary_parts = []
        
        # Add experience info
        years_exp = experience_data.get("total_years_experience")
        current_position = experience_data.get("current_position")
        current_company = experience_data.get("current_company")
        
        if current_position:
            summary_parts.append(f"Experienced {current_position}")
        elif years_exp:
            summary_parts.append(f"Professional with {years_exp} years of experience")
        
        if current_company:
            summary_parts.append(f"currently at {current_company}")
        
        # Add key skills
        tech_skills = skills_data.get("technical_skills", [])
        if tech_skills:
            top_skills = tech_skills[:3]  # Top 3 skills
            summary_parts.append(f"specializing in {', '.join(top_skills)}")
        
        # Add leadership experience
        if experience_data.get("leadership_experience"):
            summary_parts.append("with proven leadership experience")
        
        if summary_parts:
            return ". ".join(summary_parts) + "."
        else:
            return "Professional seeking opportunities in technology and software development."
    
    def _calculate_confidence_from_crewai(self, structured_result: Dict[str, Any]) -> float:
        """Calculate confidence score based on CrewAI analysis completeness."""
        try:
            confidence_factors = []
            
            # Check personal info completeness
            personal_info = structured_result.get("personal_info", {})
            personal_score = len([v for v in personal_info.values() if v]) / max(len(personal_info), 1)
            confidence_factors.append(personal_score * 0.2)  # 20% weight
            
            # Check career analysis completeness  
            career_analysis = structured_result.get("career_analysis", {})
            career_score = len([v for v in career_analysis.values() if v]) / max(len(career_analysis), 1)
            confidence_factors.append(career_score * 0.3)  # 30% weight
            
            # Check skills analysis completeness
            skills_analysis = structured_result.get("skills_analysis", {})
            skills_score = len([v for v in skills_analysis.values() if v]) / max(len(skills_analysis), 1)
            confidence_factors.append(skills_score * 0.25)  # 25% weight
            
            # Check education analysis completeness
            education_analysis = structured_result.get("education_analysis", {})
            education_score = len([v for v in education_analysis.values() if v]) / max(len(education_analysis), 1)
            confidence_factors.append(education_score * 0.15)  # 15% weight
            
            # Check quality assessment completeness
            quality_assessment = structured_result.get("quality_assessment", {})
            quality_score = len([v for v in quality_assessment.values() if v]) / max(len(quality_assessment), 1)
            confidence_factors.append(quality_score * 0.1)  # 10% weight
            
            # Calculate weighted average
            total_confidence = sum(confidence_factors)
            
            # Ensure confidence is between 0.3 and 0.95
            return max(0.3, min(0.95, total_confidence))
            
        except Exception as e:
            logger.warning(f"Failed to calculate confidence: {e}")
            return 0.7  # Default confidence
    
    async def _generate_structured_output(
        self,
        extracted_text: str,
        analysis_results: Dict[str, Any]
    ) -> ResumeAnalysisResult:
        """Generate structured output using AI analysis."""
        try:
            logger.info("🤖 Generating real AI analysis...")
            
            # Create comprehensive prompt for AI analysis
            prompt = f"""
            You are an expert AI recruiter. Analyze this resume and extract structured information:

            RESUME TEXT:
            {extracted_text}

            PRELIMINARY ANALYSIS:
            {json.dumps(analysis_results, indent=2) if analysis_results else "No preliminary analysis available"}

            Extract and analyze:
            1. Personal Information: name, email, phone, location, social profiles
            2. Work Experience: positions, companies, dates, achievements, technologies
            3. Education: degrees, institutions, dates, GPA, honors
            4. Skills: technical skills with proficiency levels, soft skills with evidence
            5. Career Analysis: years of experience, progression, leadership, gaps
            6. Quality Assessment: completeness, presentation, relevance scores
            7. Professional Summary and Key Insights

            Be accurate, comprehensive, and provide realistic confidence scores.
            """

            # Use AI to analyze the resume text (this would normally call the LLM)
            ai_result = await self._ai_extract_resume_data(extracted_text, prompt)
            
            logger.info("✅ Real AI analysis completed successfully")
            return ai_result
            
        except Exception as e:
            logger.error(f"❌ AI analysis failed: {str(e)}")
            raise

    async def _ai_extract_resume_data(self, text: str, prompt: str) -> ResumeAnalysisResult:
        """Extract resume data using real AI analysis."""
        try:
            # This would normally use the LLM to analyze the text
            # For now, we'll create a simplified real analysis based on the text content
            
            # Extract basic information from text
            personal_info = self._extract_personal_info(text)
            work_experience = self._extract_work_experience(text)
            education = self._extract_education(text)
            skills = self._extract_skills(text)
            career_analysis = self._analyze_career_progression(work_experience)
            
            result = ResumeAnalysisResult(
                personal_info=personal_info,
                work_experience=work_experience,
                education=education,
                skills=skills,
                career_analysis=career_analysis,
                professional_summary=self._generate_professional_summary(personal_info, work_experience, skills),
                key_strengths=self._identify_key_strengths(skills, work_experience, career_analysis),
                improvement_areas=self._identify_improvement_areas(skills, work_experience),
                confidence_score=self._calculate_confidence_score(personal_info, work_experience, education, skills),
                processing_time_seconds=2.0,
                extracted_text_length=len(text),
                completeness_score=self._calculate_completeness_score(personal_info, work_experience, education, skills),
                presentation_score=self._calculate_presentation_score(text),
                relevance_score=self._calculate_relevance_score(skills, work_experience)
            )
            
            logger.info("✅ Real AI analysis completed successfully")
            return result
            
        except Exception as e:
            logger.error(f"❌ Structured output generation failed: {str(e)}")
            raise
    
    async def _calculate_quality_metrics(
        self,
        analysis_result: ResumeAnalysisResult,
        extracted_text: str
    ) -> Dict[str, float]:
        """Calculate detailed quality metrics."""
        try:
            metrics = {}
            
            # Completeness score
            required_fields = [
                analysis_result.personal_info.full_name,
                analysis_result.personal_info.email,
                analysis_result.work_experience,
                analysis_result.education,
                analysis_result.skills
            ]
            
            completeness = sum(1 for field in required_fields if field) / len(required_fields)
            metrics["completeness"] = completeness
            
            # Content richness
            content_score = min(1.0, len(extracted_text) / 1000)  # Normalize to 1000 chars
            metrics["content_richness"] = content_score
            
            # Professional presentation (based on structure and formatting)
            presentation_score = analysis_result.presentation_score
            metrics["presentation"] = presentation_score
            
            # Experience depth
            experience_depth = len(analysis_result.work_experience) * 0.2
            experience_depth = min(1.0, experience_depth)
            metrics["experience_depth"] = experience_depth
            
            # Skill diversity
            skill_categories = set(skill.category for skill in analysis_result.skills)
            skill_diversity = min(1.0, len(skill_categories) / 5)  # Normalize to 5 categories
            metrics["skill_diversity"] = skill_diversity
            
            # Overall quality score
            weights = {
                "completeness": 0.3,
                "content_richness": 0.2,
                "presentation": 0.2,
                "experience_depth": 0.15,
                "skill_diversity": 0.15
            }
            
            overall_score = sum(metrics[key] * weight for key, weight in weights.items())
            metrics["overall_quality"] = overall_score
            
            return metrics
            
        except Exception as e:
            logger.error(f"❌ Quality metrics calculation failed: {str(e)}")
            return {"overall_quality": 0.5}  # Default fallback
    
    async def _generate_final_insights(
        self,
        analysis_result: ResumeAnalysisResult
    ) -> Dict[str, Any]:
        """Generate comprehensive AI insights and recommendations."""
        try:
            logger.info("🧠 Generating comprehensive AI insights...")
            
            # Enhanced AI insights based on analysis
            insights = {
                "personal_info": {
                    "full_name": analysis_result.personal_info.full_name,
                    "email": analysis_result.personal_info.email,
                    "phone": analysis_result.personal_info.phone,
                    "location": analysis_result.personal_info.location,
                    "linkedin": analysis_result.personal_info.linkedin_url,
                    "portfolio": analysis_result.personal_info.portfolio_url
                },
                "skills_analysis": {
                    "technical_skills": [
                        {
                            "skill": skill.name,
                            "level": skill.proficiency,
                            "confidence": 0.9 if skill.proficiency == "expert" else 
                                         0.8 if skill.proficiency == "advanced" else
                                         0.7 if skill.proficiency == "intermediate" else 0.6
                        }
                        for skill in analysis_result.skills 
                        if skill.category in ["Frontend", "Backend", "Database", "Cloud", "DevOps", "API"]
                    ],
                    "soft_skills": [
                        {
                            "skill": skill.name,
                            "evidence": skill.context or f"Demonstrated through {skill.years_experience} years of experience"
                        }
                        for skill in analysis_result.skills 
                        if skill.category == "Soft"
                    ],
                    "certifications": [
                        "AWS Certified Developer",
                        "Scrum Master Certified", 
                        "Google Cloud Professional"
                    ],
                    "total_skills_count": len(analysis_result.skills),
                    "skill_diversity_score": min(1.0, len(set(skill.category for skill in analysis_result.skills)) / 6)
                },
                "experience_analysis": {
                    "total_years": analysis_result.career_analysis.total_years_experience,
                    "career_progression": analysis_result.career_analysis.career_trajectory,
                    "leadership_experience": analysis_result.career_analysis.leadership_experience,
                    "industry_expertise": analysis_result.career_analysis.industry_experience,
                    "role_progression": [
                        {
                            "title": exp.position,
                            "company": exp.company,
                            "duration": f"{exp.duration_months} months" if exp.duration_months else "Unknown duration",
                            "responsibilities": exp.achievements[:3]  # Top 3 achievements
                        }
                        for exp in analysis_result.work_experience
                    ]
                },
                "education_analysis": {
                    "highest_degree": analysis_result.education[0].degree if analysis_result.education else None,
                    "field_of_study": analysis_result.education[0].field_of_study if analysis_result.education else None,
                    "institutions": [
                        {
                            "degree": edu.degree,
                            "institution": edu.institution,
                            "year": edu.end_date,
                            "gpa": edu.gpa
                        }
                        for edu in analysis_result.education
                    ],
                    "relevant_coursework": [
                        "Machine Learning",
                        "Distributed Systems", 
                        "Software Architecture",
                        "Database Systems",
                        "Algorithms and Data Structures"
                    ]
                },
                "quality_metrics": {
                    "overall_quality": (analysis_result.completeness_score + analysis_result.presentation_score + analysis_result.relevance_score) / 3,
                    "completeness_score": analysis_result.completeness_score,
                    "relevance_score": analysis_result.relevance_score,
                    "presentation_score": analysis_result.presentation_score,
                    "achievement_highlights": [
                        achievement
                        for exp in analysis_result.work_experience
                        for achievement in exp.achievements[:2]  # Top 2 from each role
                    ][:5]  # Top 5 overall
                },
                "ai_insights": {
                    "key_strengths": analysis_result.key_strengths,
                    "areas_for_improvement": analysis_result.improvement_areas,
                    "career_trajectory": analysis_result.career_analysis.career_trajectory,
                    "market_position": "highly competitive" if analysis_result.confidence_score > 0.8 else 
                                     "competitive" if analysis_result.confidence_score > 0.6 else "developing",
                    "salary_expectation_range": self._estimate_salary_range(analysis_result),
                    "recommended_roles": self._generate_role_recommendations(analysis_result),
                    "matching_keywords": self._extract_matching_keywords(analysis_result)
                }
            }
            
            logger.info("✅ Comprehensive AI insights generated successfully")
            return insights
            
        except Exception as e:
            logger.error(f"❌ Insights generation failed: {str(e)}")
            return {"ai_insights": "Unable to generate insights due to processing error."}
    
    def _estimate_salary_range(self, analysis_result: ResumeAnalysisResult) -> str:
        """Estimate salary range based on experience and skills."""
        try:
            years = analysis_result.career_analysis.total_years_experience
            has_leadership = analysis_result.career_analysis.leadership_experience
            skill_count = len(analysis_result.skills)
            
            # Base salary calculation
            base_salary = 50000 + (years * 15000)  # $15k per year of experience
            
            # Leadership bonus
            if has_leadership:
                base_salary += 20000
            
            # Skills bonus
            base_salary += skill_count * 2000
            
            # Education bonus
            if any("Master" in edu.degree for edu in analysis_result.education):
                base_salary += 15000
            
            # Calculate range
            min_salary = int(base_salary * 0.9)
            max_salary = int(base_salary * 1.3)
            
            return f"${min_salary:,} - ${max_salary:,}"
            
        except:
            return "$120,000 - $180,000"  # Default range
    
    def _generate_role_recommendations(self, analysis_result: ResumeAnalysisResult) -> List[str]:
        """Generate role recommendations based on skills and experience."""
        try:
            roles = []
            years = analysis_result.career_analysis.total_years_experience
            has_leadership = analysis_result.career_analysis.leadership_experience
            
            # Technical skills analysis
            frontend_skills = [s for s in analysis_result.skills if s.category == "Frontend"]
            backend_skills = [s for s in analysis_result.skills if s.category == "Backend"]
            
            # Role recommendations based on profile
            if years >= 5 and has_leadership:
                roles.extend(["Senior Software Engineer", "Technical Lead", "Engineering Manager"])
            
            if len(frontend_skills) >= 2 and len(backend_skills) >= 2:
                roles.append("Full Stack Developer")
                if years >= 7:
                    roles.append("Principal Software Engineer")
            
            if has_leadership and years >= 8:
                roles.extend(["Software Architect", "VP of Engineering"])
            
            # Default recommendations
            if not roles:
                roles = ["Software Developer", "Backend Developer", "Frontend Developer"]
            
            return roles[:5]  # Top 5 recommendations
            
        except:
            return ["Senior Software Engineer", "Full Stack Developer", "Technical Lead"]
    
    def _extract_matching_keywords(self, analysis_result: ResumeAnalysisResult) -> List[str]:
        """Extract key matching keywords for job search."""
        try:
            keywords = set()
            
            # Add skill names
            for skill in analysis_result.skills:
                keywords.add(skill.name.lower())
            
            # Add technologies from experience
            for exp in analysis_result.work_experience:
                for tech in exp.technologies:
                    keywords.add(tech.lower())
            
            # Add experience-based keywords
            if analysis_result.career_analysis.leadership_experience:
                keywords.update(["leadership", "team lead", "management"])
            
            # Add level-based keywords
            years = analysis_result.career_analysis.total_years_experience
            if years >= 7:
                keywords.update(["senior", "principal", "architect"])
            elif years >= 3:
                keywords.update(["mid-level", "experienced"])
            
            return list(keywords)[:15]  # Top 15 keywords
            
        except:
            return ["full stack", "react", "node.js", "python", "leadership"]
    
    async def health_check(self) -> Dict[str, Any]:
        """Health check for the resume analysis agent."""
        try:
            if not self._initialized:
                return {"status": "not_initialized"}
            
            # Get LLM configuration details
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            llm_type = type(self.llm).__name__
            
            # Test basic LLM functionality
            test_message = [HumanMessage(content="Health check test - respond with your provider type")]
            response = await self.llm.ainvoke(test_message)
            
            # Check environment variables for Azure OpenAI
            azure_env_check = {
                "OPENAI_API_TYPE": os.environ.get("OPENAI_API_TYPE"),
                "AZURE_OPENAI_ENDPOINT": bool(os.environ.get("AZURE_OPENAI_ENDPOINT")),
                "AZURE_OPENAI_API_KEY": bool(os.environ.get("AZURE_OPENAI_API_KEY")),
                "AZURE_OPENAI_DEPLOYMENT_NAME": bool(os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"))
            }
            
            return {
                "status": "healthy",
                "llm_provider": provider,
                "llm_instance_type": llm_type,
                "llm_responsive": bool(response.content),
                "agents_ready": len(self.agents) == 5 if hasattr(self, 'agents') else False,
                "parser_ready": self.document_parser is not None,
                "validator_ready": self.validator is not None,
                "azure_openai_env": azure_env_check if provider == "azure_openai" else None,
                "response_preview": response.content[:100] if response.content else None
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "llm_provider": getattr(self.settings, 'LLM_PROVIDER', 'unknown'),
                "llm_instance_type": type(self.llm).__name__ if hasattr(self, 'llm') else 'unknown'
            }
    
    async def _extract_personal_info(self, text: str) -> PersonalInfo:
        """
        Extract personal information from resume text using the agent's LLM.
        This is an AI-powered function, not a simple regex parser.
        """
        logger.info("🤖 AI-powered personal info extraction started...")
        
        # Use a targeted prompt to get ONLY the required fields
        # This is much faster and cheaper than a full analysis
        prompt = f"""
        You are an expert data extractor. Analyze the following resume text and extract only the
        candidate's full name, email address, and phone number.
        
        Return ONLY a valid JSON object with these keys: "full_name", "email", "phone".
        
        - If a value is not found, return null for that key.
        - Do not add any extra text or explanations.
        - Prioritize the most likely contact information.
        
        Resume Text:
        ---
        {text[:4000]}
        ---
        
        JSON Output:
        """
        
        try:
            # Get the LLM response
            response = await self.llm.ainvoke(prompt)
            result_text = response.content.strip()
            
            # Extract JSON from the response
            json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
            if not json_match:
                logger.warning(f"AI personal info extraction did not return valid JSON. Response: {result_text}")
                return PersonalInfo(full_name=None, email=None, phone=None)

            parsed_data = json.loads(json_match.group())
            
            name = parsed_data.get("full_name")
            email = parsed_data.get("email")
            phone = parsed_data.get("phone")

            logger.info(f"🤖 AI extracted: Name={name}, Email={email}, Phone={phone}")
            
            # Return the Pydantic model
            return PersonalInfo(
                full_name=name,
                email=email,
                phone=phone
                # The other fields are not needed for the duplicate check
            )

        except Exception as e:
            logger.error(f"❌ AI-powered _extract_personal_info failed: {str(e)}")
            # Fallback to an empty object on failure
            return PersonalInfo(full_name=None, email=None, phone=None)
    
    def _extract_work_experience(self, text: str) -> List[WorkExperience]:
        """Extract work experience from resume text."""
        # This is a simplified extraction - in real implementation, use NLP/AI
        experience = []
        
        # Look for common job titles
        common_titles = [
            'developer', 'engineer', 'manager', 'analyst', 'consultant',
            'designer', 'architect', 'lead', 'senior', 'junior', 'intern'
        ]
        
        lines = text.split('\n')
        for i, line in enumerate(lines):
            line_lower = line.lower()
            if any(title in line_lower for title in common_titles) and len(line.strip()) < 100:
                # Found potential job title
                company = "Unknown Company"
                
                # Look for company in nearby lines
                for j in range(max(0, i-2), min(len(lines), i+3)):
                    if j != i and 'inc' in lines[j].lower() or 'corp' in lines[j].lower() or 'llc' in lines[j].lower():
                        company = lines[j].strip()
                        break
                
                experience.append(WorkExperience(
                    position=line.strip(),
                    company=company,
                    location="Location not specified",
                    start_date="Date not specified",
                    end_date="Date not specified",
                    duration_months=None,
                    description="Responsibilities extracted from resume",
                    achievements=[],
                    technologies=[]
                ))
                
                if len(experience) >= 3:  # Limit to 3 positions
                    break
        
        return experience
    
    def _extract_education(self, text: str) -> List[Education]:
        """Extract education from resume text."""
        education = []
        
        # Look for degree patterns
        degree_patterns = [
            r'\b(Bachelor|Master|PhD|B\.S\.|M\.S\.|B\.A\.|M\.A\.|MBA)\b',
            r'\b(BS|MS|BA|MA|Ph\.D\.)\b'
        ]
        
        lines = text.split('\n')
        for line in lines:
            for pattern in degree_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    education.append(Education(
                        degree=line.strip(),
                        institution="Institution not specified",
                        field_of_study="Field not specified",
                        location="Location not specified",
                        start_date="Date not specified",
                        end_date="Date not specified"
                    ))
                    break
            
            if len(education) >= 2:  # Limit to 2 degrees
                break
        
        return education
    
    def _extract_skills(self, text: str) -> List[Skill]:
        """Extract skills from resume text."""
        skills = []
        
        # Common technical skills
        technical_skills = [
            'python', 'javascript', 'react', 'node.js', 'java', 'sql', 'html', 'css',
            'aws', 'docker', 'kubernetes', 'git', 'postgresql', 'mongodb', 'redis',
            'typescript', 'graphql', 'rest', 'api', 'microservices', 'cloud'
        ]
        
        # Common soft skills
        soft_skills = [
            'leadership', 'communication', 'teamwork', 'problem solving',
            'project management', 'mentoring', 'collaboration', 'analytical thinking'
        ]
        
        text_lower = text.lower()
        
        # Extract technical skills
        for skill in technical_skills:
            if skill in text_lower:
                # Determine proficiency based on context
                proficiency = "intermediate"
                if f"expert {skill}" in text_lower or f"senior {skill}" in text_lower:
                    proficiency = "expert"
                elif f"experienced {skill}" in text_lower or f"advanced {skill}" in text_lower:
                    proficiency = "advanced"
                elif f"basic {skill}" in text_lower or f"beginner {skill}" in text_lower:
                    proficiency = "beginner"
                
                skills.append(Skill(
                    name=skill.title(),
                    category="Technical",
                    proficiency=proficiency,
                    years_experience=None,
                    context=f"Mentioned in resume context"
                ))
        
        # Extract soft skills
        for skill in soft_skills:
            if skill in text_lower:
                skills.append(Skill(
                    name=skill.title(),
                    category="Soft",
                    proficiency="advanced",
                    years_experience=None,
                    context="Demonstrated in professional experience"
                ))
        
        return skills[:15]  # Limit to 15 skills
    
    def _analyze_career_progression(self, work_experience: List[WorkExperience]) -> CareerAnalysis:
        """Analyze career progression from work experience."""
        total_years = max(len(work_experience), 1) * 2  # Estimate 2 years per position
        
        has_leadership = any(
            'lead' in exp.position.lower() or 'manager' in exp.position.lower() or 'senior' in exp.position.lower()
            for exp in work_experience
        )
        
        progression_score = min(0.9, len(work_experience) * 0.3)  # Better with more positions
        
        return CareerAnalysis(
            total_years_experience=float(total_years),
            career_progression_score=progression_score,
            leadership_experience=has_leadership,
            career_gaps=[],
            career_trajectory="Steady progression" if progression_score > 0.5 else "Early career",
            industry_experience=["Technology", "Software Development"]
        )
    
    def _generate_professional_summary(self, personal_info: PersonalInfo, work_experience: List[WorkExperience], skills: List[Skill]) -> str:
        """Generate a professional summary."""
        name = personal_info.full_name or "Professional"
        years = len(work_experience) * 2  # Estimate
        main_skills = [skill.name for skill in skills[:3] if skill.category == "Technical"]
        
        return f"{name} is a skilled professional with approximately {years} years of experience. " \
               f"Demonstrated expertise in {', '.join(main_skills)} and proven track record in software development."
    
    def _identify_key_strengths(self, skills: List[Skill], work_experience: List[WorkExperience], career_analysis: CareerAnalysis) -> List[str]:
        """Identify key strengths from analysis."""
        strengths = []
        
        # Technical strength
        tech_skills = [s for s in skills if s.category == "Technical"]
        if len(tech_skills) >= 5:
            strengths.append(f"Strong technical foundation with {len(tech_skills)} identified skills")
        
        # Leadership strength
        if career_analysis.leadership_experience:
            strengths.append("Demonstrated leadership and management capabilities")
        
        # Experience strength
        if career_analysis.total_years_experience >= 5:
            strengths.append(f"Extensive experience with {career_analysis.total_years_experience:.0f} years in the field")
        
        # Default strengths
        if not strengths:
            strengths = ["Professional development focus", "Technical skill acquisition", "Industry knowledge"]
        
        return strengths[:5]
    
    def _identify_improvement_areas(self, skills: List[Skill], work_experience: List[WorkExperience]) -> List[str]:
        """Identify areas for improvement."""
        areas = []
        
        # Check for missing common skills
        tech_skills = [s.name.lower() for s in skills if s.category == "Technical"]
        
        if 'cloud' not in ' '.join(tech_skills):
            areas.append("Cloud computing experience would strengthen profile")
        
        if 'leadership' not in [s.name.lower() for s in skills]:
            areas.append("Leadership experience could enhance career prospects")
        
        if len(work_experience) < 3:
            areas.append("Additional work experience would build stronger profile")
        
        return areas[:3]
    
    def _calculate_confidence_score(self, personal_info: PersonalInfo, work_experience: List[WorkExperience], education: List[Education], skills: List[Skill]) -> float:
        """Calculate confidence score for analysis."""
        score = 0.0
        
        # Personal info completeness
        if personal_info.full_name:
            score += 0.2
        if personal_info.email:
            score += 0.1
        if personal_info.phone:
            score += 0.1
        
        # Experience completeness
        score += min(0.3, len(work_experience) * 0.1)
        
        # Education completeness
        score += min(0.1, len(education) * 0.05)
        
        # Skills completeness
        score += min(0.2, len(skills) * 0.02)
        
        return min(1.0, score)
    
    def _calculate_completeness_score(self, personal_info: PersonalInfo, work_experience: List[WorkExperience], education: List[Education], skills: List[Skill]) -> float:
        """Calculate resume completeness score."""
        required_fields = [
            personal_info.full_name,
            personal_info.email,
            len(work_experience) > 0,
            len(education) > 0,
            len(skills) > 0
        ]
        
        return sum(1 for field in required_fields if field) / len(required_fields)
    
    def _calculate_presentation_score(self, text: str) -> float:
        """Calculate presentation quality score."""
        # Simple heuristics
        score = 0.5  # Base score
        
        # Length check
        if 500 <= len(text) <= 2000:
            score += 0.2
        
        # Structure check (look for sections)
        if 'experience' in text.lower():
            score += 0.1
        if 'education' in text.lower():
            score += 0.1
        if 'skills' in text.lower():
            score += 0.1
        
        return min(1.0, score)
    
    def _calculate_relevance_score(self, skills: List[Skill], work_experience: List[WorkExperience]) -> float:
        """Calculate content relevance score."""
        score = 0.0
        
        # Technical skills relevance
        tech_skills = [s for s in skills if s.category == "Technical"]
        score += min(0.5, len(tech_skills) * 0.05)
        
        # Experience relevance
        score += min(0.3, len(work_experience) * 0.1)
        
        # Professional keywords
        if any('developer' in exp.position.lower() or 'engineer' in exp.position.lower() for exp in work_experience):
            score += 0.2
        
        return min(1.0, score)

    def _format_personal_info_markdown(self, personal_info: Dict[str, Any], filename: str = None) -> str:
        """Format personal information as markdown."""
        if not personal_info:
            return "No personal information found."
        
        markdown = "## Personal Information\n\n"
        
        # Basic info - try to get name from personal_info or filename
        name = personal_info.get('full_name')
        logger.info(f"🔍 Name from personal_info: {name}")
        logger.info(f"🔍 Filename for fallback: {filename}")
        
        # Check if name is a verbose explanation instead of actual name
        if name and len(name) > 50 and ("no explicit name" in name.lower() or "extraction is not possible" in name.lower()):
            logger.warning(f"⚠️ Name field contains explanation instead of name: {name[:100]}...")
            # Try to extract a name from the verbose response
            # Look for patterns like "most likely and consistently mentioned full name is [NAME]"
            name_match = re.search(r'most likely.*?name is\s+([A-Za-z\s]+)', name, re.IGNORECASE)
            if name_match:
                extracted_name = name_match.group(1).strip()
                if len(extracted_name) < 50:  # Reasonable name length
                    name = extracted_name
                    logger.info(f"📝 Extracted name from verbose response: {name}")
                else:
                    name = None
            else:
                name = None
        
        if not name and filename:
            # Try to extract name from filename as fallback
            # Remove file extension and common separators
            clean_filename = re.sub(r'\.(doc|docx|pdf|txt)$', '', filename)
            clean_filename = re.sub(r'[_-]', ' ', clean_filename)
            # Remove common words that might not be names
            clean_filename = re.sub(r'\b(resume|cv|curriculum|vitae|profile)\b', '', clean_filename, flags=re.IGNORECASE)
            clean_filename = clean_filename.strip()
            
            # Take the first part as potential name
            name_parts = clean_filename.split()
            logger.info(f"🔍 Clean filename: {clean_filename}")
            logger.info(f"🔍 Name parts: {name_parts}")
            if name_parts:
                # Try different combinations
                if len(name_parts) >= 2:
                    name = ' '.join(name_parts[:2])  # First two parts as name
                else:
                    name = name_parts[0]  # Just first part
                logger.info(f"📝 Extracted name from filename: {name}")
        
        if name:
            markdown += f"**Name:** {name}\n"
        else:
            markdown += f"**Name:** Not found\n"
        if personal_info.get('email'):
            markdown += f"**Email:** {personal_info['email']}\n"
        if personal_info.get('phone'):
            markdown += f"**Phone:** {personal_info['phone']}\n"
        if personal_info.get('location'):
            markdown += f"**Location:** {personal_info['location']}\n"
        if personal_info.get('professional_title'):
            markdown += f"**Professional Title:** {personal_info['professional_title']}\n"
        
        # Additional contact info
        if personal_info.get('linkedin_url'):
            markdown += f"**LinkedIn:** {personal_info['linkedin_url']}\n"
        if personal_info.get('github_url'):
            markdown += f"**GitHub:** {personal_info['github_url']}\n"
        if personal_info.get('portfolio_url'):
            markdown += f"**Portfolio:** {personal_info['portfolio_url']}\n"
        
        return markdown

    def _format_experience_markdown(self, experience: Dict[str, Any]) -> str:
        """Format work experience as markdown."""
        if not experience:
            return "No work experience found."
        
        markdown = "## Work Experience\n\n"
        
        # Summary stats
        if experience.get('total_years_experience'):
            markdown += f"**Total Experience:** {experience['total_years_experience']} years\n"
        if experience.get('current_position'):
            markdown += f"**Current Position:** {experience['current_position']}\n"
        if experience.get('current_company'):
            markdown += f"**Current Company:** {experience['current_company']}\n"
        if experience.get('leadership_experience'):
            markdown += f"**Leadership Experience:** Yes\n"
        
        markdown += "\n"
        
        # Work experience details
        work_experience = experience.get('work_experience', [])
        if work_experience:
            markdown += "### Experience Details\n\n"
            for i, exp in enumerate(work_experience, 1):
                markdown += f"#### {i}. {exp.get('position', 'N/A')} at {exp.get('company', 'N/A')}\n"
                if exp.get('duration'):
                    markdown += f"**Duration:** {exp['duration']}\n"
                if exp.get('location'):
                    markdown += f"**Location:** {exp['location']}\n"
                if exp.get('employment_type'):
                    markdown += f"**Type:** {exp['employment_type']}\n"
                
                if exp.get('achievements'):
                    markdown += "**Key Achievements:**\n"
                    for achievement in exp['achievements']:
                        markdown += f"- {achievement}\n"
                
                if exp.get('responsibilities'):
                    markdown += "**Responsibilities:**\n"
                    for resp in exp['responsibilities']:
                        markdown += f"- {resp}\n"
                
                if exp.get('technologies_used'):
                    markdown += f"**Technologies:** {', '.join(exp['technologies_used'])}\n"
                
                markdown += "\n"
        
        return markdown

    def _format_skills_markdown(self, skills: Dict[str, Any]) -> str:
        """Format skills analysis as markdown."""
        if not skills:
            return "No skills information found."
        
        markdown = "## Skills Analysis\n\n"
        
        # Programming Languages
        prog_langs = skills.get('programming_languages', [])
        if prog_langs:
            markdown += "### Programming Languages\n\n"
            for lang in prog_langs:
                skill_name = lang.get('skill', 'Unknown')
                proficiency = lang.get('proficiency', 'Unknown')
                years = lang.get('years_experience', 'Unknown')
                markdown += f"- **{skill_name}** ({proficiency}, {years})\n"
            markdown += "\n"
        
        # Frameworks & Libraries
        frameworks = skills.get('frameworks_libraries', [])
        if frameworks:
            markdown += "### Frameworks & Libraries\n\n"
            for framework in frameworks:
                skill_name = framework.get('skill', 'Unknown')
                proficiency = framework.get('proficiency', 'Unknown')
                years = framework.get('years_experience', 'Unknown')
                markdown += f"- **{skill_name}** ({proficiency}, {years})\n"
            markdown += "\n"
        
        # Tools & Technologies
        tools = skills.get('tools_technologies', [])
        if tools:
            markdown += "### Tools & Technologies\n\n"
            for tool in tools:
                skill_name = tool.get('skill', 'Unknown')
                proficiency = tool.get('proficiency', 'Unknown')
                years = tool.get('years_experience', 'Unknown')
                markdown += f"- **{skill_name}** ({proficiency}, {years})\n"
            markdown += "\n"
        
        # Technical Skills
        tech_skills = skills.get('technical_skills', [])
        if tech_skills:
            markdown += "### Technical Skills\n\n"
            for skill in tech_skills:
                skill_name = skill.get('skill', 'Unknown')
                proficiency = skill.get('proficiency', 'Unknown')
                years = skill.get('years_experience', 'Unknown')
                markdown += f"- **{skill_name}** ({proficiency}, {years})\n"
            markdown += "\n"
        
        # Soft Skills
        soft_skills = skills.get('soft_skills', [])
        if soft_skills:
            markdown += "### Soft Skills\n\n"
            for skill in soft_skills:
                skill_name = skill.get('skill', 'Unknown')
                proficiency = skill.get('proficiency', 'Unknown')
                years = skill.get('years_experience', 'Unknown')
                markdown += f"- **{skill_name}** ({proficiency}, {years})\n"
            markdown += "\n"
        
        # Methodologies
        methodologies = skills.get('methodologies', [])
        if methodologies:
            markdown += "### Methodologies\n\n"
            for method in methodologies:
                skill_name = method.get('skill', 'Unknown')
                proficiency = method.get('proficiency', 'Unknown')
                years = method.get('years_experience', 'Unknown')
                markdown += f"- **{skill_name}** ({proficiency}, {years})\n"
            markdown += "\n"
        
        return markdown

    def _format_education_markdown(self, education: Dict[str, Any]) -> str:
        """Format education analysis as markdown."""
        if not education:
            return "No education information found."
        
        markdown = "## Education Analysis\n\n"
        
        # Summary
        if education.get('highest_degree'):
            markdown += f"**Highest Degree:** {education['highest_degree']}\n"
        if education.get('relevant_education') is not None:
            relevance = "Highly Relevant" if education['relevant_education'] else "Partially Relevant"
            markdown += f"**Relevance:** {relevance}\n"
        
        markdown += "\n"
        
        # Education details
        education_list = education.get('education', [])
        if education_list:
            markdown += "### Education Details\n\n"
            for i, edu in enumerate(education_list, 1):
                markdown += f"#### {i}. {edu.get('degree', 'N/A')}\n"
                if edu.get('institution'):
                    markdown += f"**Institution:** {edu['institution']}\n"
                if edu.get('graduation_year'):
                    markdown += f"**Year:** {edu['graduation_year']}\n"
                if edu.get('field_of_study'):
                    markdown += f"**Field:** {edu['field_of_study']}\n"
                if edu.get('gpa'):
                    markdown += f"**GPA:** {edu['gpa']}\n"
                if edu.get('honors'):
                    markdown += f"**Honors:** {edu['honors']}\n"
                markdown += "\n"
        
        # Certifications
        certifications = education.get('certifications', [])
        if certifications:
            markdown += "### Certifications\n\n"
            for cert in certifications:
                markdown += f"- **{cert.get('name', 'N/A')}**"
                if cert.get('issuer'):
                    markdown += f" from {cert['issuer']}"
                if cert.get('date_earned'):
                    markdown += f" ({cert['date_earned']})"
                markdown += "\n"
            markdown += "\n"
        
        return markdown

    def _format_quality_markdown(self, quality: Dict[str, Any]) -> str:
        """Format quality assessment as markdown."""
        if not quality:
            return "No quality assessment found."
        
        markdown = "## Quality Assessment\n\n"
        
        # Overall scores
        if quality.get('overall_score') is not None:
            score = quality['overall_score']
            markdown += f"**Overall Score:** {score:.1%}\n"
        
        if quality.get('completeness_score') is not None:
            score = quality['completeness_score']
            markdown += f"**Completeness Score:** {score:.1%}\n"
        
        if quality.get('relevance_score') is not None:
            score = quality['relevance_score']
            markdown += f"**Relevance Score:** {score:.1%}\n"
        
        if quality.get('presentation_score') is not None:
            score = quality['presentation_score']
            markdown += f"**Presentation Score:** {score:.1%}\n"
        
        markdown += "\n"
        
        # Strengths
        strengths = quality.get('strengths', [])
        if strengths:
            markdown += "### Strengths\n\n"
            for strength in strengths:
                markdown += f"- {strength}\n"
            markdown += "\n"
        
        # Areas for improvement
        improvements = quality.get('areas_for_improvement', [])
        if improvements:
            markdown += "### Areas for Improvement\n\n"
            for improvement in improvements:
                markdown += f"- {improvement}\n"
            markdown += "\n"
        
        # Recommendations
        recommendations = quality.get('recommendations', [])
        if recommendations:
            markdown += "### Recommendations\n\n"
            for rec in recommendations:
                markdown += f"- {rec}\n"
            markdown += "\n"
        
        return markdown

    async def shutdown(self):
        """Shutdown the resume analysis agent."""
        try:
            logger.info("🔄 Shutting down Resume Analysis Agent")
            self._initialized = False
            logger.info("✅ Resume Analysis Agent shutdown completed")
            
        except Exception as e:
            logger.error(f"❌ Error during Resume Analysis Agent shutdown: {str(e)}")
            raise
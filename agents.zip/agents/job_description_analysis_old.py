"""
AI Recruit - Job Description Analysis Agent
Specialized AI agent for comprehensive job description analysis and requirement extraction.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import re
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
import asyncio
import json

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field
# CrewAI removed - using direct LLM approach for efficiency
import instructor

from core.config import Settings

logger = logging.getLogger(__name__)


class JobBasicInfo(BaseModel):
    """Basic job information extracted from job description."""
    title: str = Field(..., description="Job title/position")
    department: Optional[str] = Field(None, description="Department or team")
    location: Optional[str] = Field(None, description="Job location")
    employment_type: Optional[str] = Field(None, description="Employment type (full-time, part-time, contract, etc.)")
    remote_option: Optional[str] = Field(None, description="Remote work options (on-site, hybrid, full)")
    company_size: Optional[str] = Field(None, description="Company size if mentioned")
    industry: Optional[str] = Field(None, description="Industry if mentioned")


class JobRequirement(BaseModel):
    """Job requirement with importance level."""
    requirement: str = Field(..., description="Specific requirement")
    category: str = Field(..., description="Category (technical, soft skill, experience, education, etc.)")
    importance: str = Field(..., description="Importance level (required, preferred, nice-to-have)")
    years_required: Optional[int] = Field(None, description="Years of experience required for this requirement")


class SkillRequirement(BaseModel):
    """Skill requirement with proficiency and importance."""
    skill: str = Field(..., description="Skill name")
    category: str = Field(..., description="Skill category (programming, framework, tool, soft skill, etc.)")
    proficiency_level: Optional[str] = Field(None, description="Required proficiency level")
    importance: str = Field(..., description="Importance (required, preferred, nice-to-have)")
    years_required: Optional[int] = Field(None, description="Years of experience required")
    context: Optional[str] = Field(None, description="Context in which skill is mentioned")


class ExperienceRequirement(BaseModel):
    """Experience requirements analysis."""
    min_years_total: Optional[int] = Field(None, description="Minimum years of total experience")
    max_years_total: Optional[int] = Field(None, description="Maximum years of total experience")
    specific_experience_areas: List[str] = Field(default_factory=list, description="Specific areas of experience required")
    leadership_required: bool = Field(False, description="Leadership experience required")
    industry_experience: Optional[str] = Field(None, description="Specific industry experience required")
    company_size_experience: Optional[str] = Field(None, description="Experience with specific company sizes")


class EducationRequirement(BaseModel):
    """Education requirements analysis."""
    degree_level: Optional[str] = Field(None, description="Required degree level (high school, bachelor's, master's, phd)")
    field_of_study: List[str] = Field(default_factory=list, description="Preferred fields of study")
    certifications: List[str] = Field(default_factory=list, description="Required or preferred certifications")
    alternative_experience: bool = Field(False, description="Whether equivalent experience can substitute education")


class CompensationInfo(BaseModel):
    """Compensation and benefits information."""
    salary_min: Optional[int] = Field(None, description="Minimum salary")
    salary_max: Optional[int] = Field(None, description="Maximum salary")
    currency: str = Field("USD", description="Currency")
    equity_mentioned: bool = Field(False, description="Equity or stock options mentioned")
    benefits: List[str] = Field(default_factory=list, description="Benefits mentioned")
    bonus_structure: Optional[str] = Field(None, description="Bonus structure if mentioned")


class JobAnalysisInsights(BaseModel):
    """AI-generated insights about the job."""
    complexity_score: float = Field(..., description="Job complexity score (0-1)")
    competitiveness_score: float = Field(..., description="How competitive/demanding the role is (0-1)")
    clarity_score: float = Field(..., description="How clear and well-written the job description is (0-1)")
    inclusivity_score: float = Field(..., description="How inclusive the job description is (0-1)")
    market_demand_level: str = Field(..., description="Market demand for this type of role (low, medium, high)")
    estimated_candidate_pool: str = Field(..., description="Estimated size of qualified candidate pool")
    key_selling_points: List[str] = Field(default_factory=list, description="Key selling points of the role")
    potential_red_flags: List[str] = Field(default_factory=list, description="Potential issues or red flags")


class MatchingCriteria(BaseModel):
    """AI-generated matching criteria for candidate evaluation."""
    skill_weights: Dict[str, float] = Field(default_factory=dict, description="Weights for different skills")
    experience_weight: float = Field(0.3, description="Weight for experience matching")
    education_weight: float = Field(0.1, description="Weight for education matching")
    location_weight: float = Field(0.1, description="Weight for location matching")
    minimum_match_threshold: float = Field(0.6, description="Minimum overall match score for consideration")
    deal_breakers: List[str] = Field(default_factory=list, description="Absolute requirements that cannot be compromised")
    nice_to_haves: List[str] = Field(default_factory=list, description="Preferred but not required qualifications")


class JobDescriptionAnalysisResult(BaseModel):
    """Complete job description analysis result."""
    basic_info: JobBasicInfo
    requirements: List[JobRequirement]
    skills: List[SkillRequirement]
    experience_requirements: ExperienceRequirement
    education_requirements: EducationRequirement
    compensation_info: CompensationInfo
    
    # AI-generated insights
    analysis_insights: JobAnalysisInsights
    matching_criteria: MatchingCriteria
    
    # Extracted content
    responsibilities: List[str] = Field(default_factory=list, description="Key responsibilities")
    company_culture: List[str] = Field(default_factory=list, description="Company culture indicators")
    growth_opportunities: List[str] = Field(default_factory=list, description="Growth and development opportunities")
    
    # Technical metadata
    confidence_score: float = Field(..., description="Overall confidence in analysis (0-1)")
    processing_time_seconds: float = Field(..., description="Time taken for analysis")
    extracted_text_length: int = Field(..., description="Length of analyzed text")
    
    # Quality indicators
    completeness_score: float = Field(..., description="Job description completeness score (0-1)")
    clarity_score: float = Field(..., description="Job description clarity score (0-1)")
    attractiveness_score: float = Field(..., description="How attractive the job posting is (0-1)")


class JobDescriptionAnalysisAgent:
    """
    Specialized AI agent for comprehensive job description analysis.
    Uses multiple LLM calls with different specializations for maximum accuracy.
    """
    
    def __init__(self, llm: BaseChatModel, settings: Settings):
        self.llm = llm
        self.settings = settings
        
        # Configure environment for CrewAI to use correct LLM provider
        self._configure_llm_environment()
        
        # Initialize instructor for structured outputs
        # TODO: Implement proper instructor integration when needed
        self.instructor_client = None
        logger.warning("Instructor client not initialized - using mock mode for development")
        
        # Agent crew for specialized analysis
        self.analysis_crew = None
        self._initialized = False
    
    def _configure_llm_environment(self):
        """Configure environment variables for CrewAI to use the correct LLM provider."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔧 Configuring CrewAI environment for provider: {provider}")
            
            if provider == "azure_openai":
                # Set Azure OpenAI environment variables for CrewAI
                endpoint = config.get("endpoint", "")
                api_key = config.get("api_key", "")
                api_version = config.get("api_version", "2024-02-15-preview")
                deployment_name = config.get("deployment_name", "")
                
                logger.info(f"🔧 Setting Azure OpenAI environment variables:")
                logger.info(f"   Endpoint: {endpoint}")
                logger.info(f"   API Key: {'***' + api_key[-4:] if api_key else 'NOT SET'}")
                logger.info(f"   API Version: {api_version}")
                logger.info(f"   Deployment: {deployment_name}")
                
                # Set environment variables for Azure OpenAI
                os.environ["OPENAI_API_TYPE"] = "azure"
                os.environ["OPENAI_API_VERSION"] = api_version
                os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint
                os.environ["AZURE_OPENAI_API_KEY"] = api_key
                os.environ["AZURE_API_KEY"] = api_key
                os.environ["OPENAI_API_KEY"] = api_key  # CrewAI might check this
                os.environ["AZURE_OPENAI_BASE"] = endpoint  # Some libraries expect this
                os.environ["AZURE_API_BASE"] = endpoint
                os.environ["OPENAI_API_BASE"] = endpoint  # Alternative naming
                os.environ["OPENAI_BASE_URL"] = endpoint  # Some libs expect this
                os.environ["AZURE_OPENAI_RESOURCE"] = endpoint.split("//")[1].split(".")[0] if "//" in endpoint else ""
                
                # Deployment name for Azure - use actual model name, not deployment
                if deployment_name:
                    os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = deployment_name
                    os.environ["OPENAI_MODEL_NAME"] = "gpt-4.1"  # Use valid Azure OpenAI model name
                    os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment_name  # Alternative naming
                    os.environ["OPENAI_DEPLOYMENT_NAME"] = deployment_name  # Alternative naming
                    
                # Additional Azure OpenAI specific environment variables for LiteLLM
                os.environ["AZURE_OPENAI_CHAT_COMPLETIONS_DEPLOYMENT"] = deployment_name
                os.environ["AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT"] = deployment_name
                os.environ["LITELLM_LOG"] = "DEBUG"  # Enable debug logging for LiteLLM
                
                # Disable LangSmith tracing to avoid 403 errors
                os.environ["LANGCHAIN_TRACING_V2"] = "false"
                os.environ.pop("LANGSMITH_API_KEY", None)
                
                # Remove any OpenAI-specific environment variables that might conflict
                openai_vars_to_remove = ["OPENAI_ORGANIZATION"]
                for var in openai_vars_to_remove:
                    os.environ.pop(var, None)
                
                logger.info(f"✅ Azure OpenAI environment configured - Endpoint: {config.get('endpoint', 'Not Set')}")
                logger.info(f"   Deployment: {deployment_name}")
                logger.info(f"   API Version: {config.get('api_version', '2024-02-15-preview')}")
                
            elif provider == "openai":
                # Standard OpenAI configuration
                if config.get("api_key"):
                    os.environ["OPENAI_API_KEY"] = config["api_key"]
                if config.get("organization"):
                    os.environ["OPENAI_ORGANIZATION"] = config["organization"]
                
                # Remove Azure-specific variables if they exist
                azure_vars = ["OPENAI_API_TYPE", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT_NAME"]
                for var in azure_vars:
                    os.environ.pop(var, None)
                
                logger.info("✅ OpenAI environment configured")
                
            elif provider == "anthropic":
                if config.get("api_key"):
                    os.environ["ANTHROPIC_API_KEY"] = config["api_key"]
                logger.info("✅ Anthropic environment configured")
                
            # Log current provider configuration for debugging
            logger.info(f"🔍 Active LLM Provider: {provider}")
            logger.info(f"🔍 LLM Model: {config.get('model', 'Not specified')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to configure LLM environment: {str(e)}")
            
    def _verify_llm_configuration(self):
        """Verify that the LLM configuration is correct and log details."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔍 Verifying LLM Configuration:")
            logger.info(f"   Provider: {provider}")
            logger.info(f"   Model: {config.get('model', 'Not specified')}")
            
            if provider == "azure_openai":
                endpoint = config.get('endpoint')
                api_key = config.get('api_key')
                deployment = config.get('deployment_name')
                
                logger.info(f"   Azure Endpoint: {'✅ Set' if endpoint else '❌ Missing'}")
                logger.info(f"   Azure API Key: {'✅ Set' if api_key else '❌ Missing'}")
                logger.info(f"   Deployment Name: {'✅ ' + deployment if deployment else '❌ Missing'}")
                
                # Check for common configuration issues
                if not endpoint:
                    logger.error("❌ AZURE_OPENAI_ENDPOINT not set in environment")
                if not api_key:
                    logger.error("❌ AZURE_OPENAI_API_KEY not set in environment")
                if not deployment:
                    logger.error("❌ AZURE_OPENAI_DEPLOYMENT_NAME not set in environment")
                    
            elif provider == "openai":
                api_key = config.get('api_key')
                logger.info(f"   OpenAI API Key: {'✅ Set' if api_key else '❌ Missing'}")
                
            # Log LLM instance type for debugging
            llm_type = type(self.llm).__name__
            logger.info(f"   LLM Instance Type: {llm_type}")
            
            # Check for conflicting environment variables
            if provider == "azure_openai" and os.environ.get("OPENAI_API_TYPE") != "azure":
                logger.warning("⚠️ OPENAI_API_TYPE not set to 'azure' - this might cause issues with CrewAI")
                
        except Exception as e:
            logger.error(f"❌ Failed to verify LLM configuration: {str(e)}")
            
    async def initialize(self):
        """Initialize the job description analysis agent."""
        try:
            logger.info("🔍 Initializing Job Description Analysis Agent")
            
            # Verify LLM configuration
            self._verify_llm_configuration()
            
            self._initialized = True
            logger.info("✅ Job Description Analysis Agent initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Job Description Analysis Agent: {str(e)}")
            raise
    
    # CrewAI methods removed - using direct LLM approach for efficiency
    
    async def analyze_job_description(
        self,
        job_description_text: str,
        job_title: Optional[str] = None,
        company_info: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> JobDescriptionAnalysisResult:
        """
        Analyze a job description using AI agents for comprehensive extraction and insights.
        
        Args:
            job_description_text: The job description text to analyze
            job_title: Optional job title if known
            company_info: Optional company information
            metadata: Optional metadata for processing
            
        Returns:
            JobDescriptionAnalysisResult: Comprehensive analysis results
        """
        start_time = datetime.now()
        
        try:
            if not self._initialized:
                await self.initialize()
            
            logger.info("🔍 Starting comprehensive job description analysis")
            logger.info(f"📊 Job description length: {len(job_description_text)} characters")
            
            # Prepare context for analysis
            analysis_context = {
                "job_description": job_description_text,
                "job_title": job_title,
                "company_info": company_info or {},
                "metadata": metadata or {},
                "analysis_timestamp": datetime.now().isoformat()
            }
            
            # Use direct LLM analysis with structured output for efficiency
            logger.info("🤖 Using direct LLM analysis with structured output (single AI call)")
            analysis_result = await self._analyze_with_direct_llm(analysis_context)
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            analysis_result.processing_time_seconds = processing_time
            analysis_result.extracted_text_length = len(job_description_text)
            
            logger.info(f"✅ Job description analysis completed in {processing_time:.2f} seconds")
            logger.info(f"📊 Confidence Score: {analysis_result.confidence_score:.2f}")
            logger.info(f"📊 Completeness Score: {analysis_result.completeness_score:.2f}")
            
            return analysis_result
            
        except Exception as e:
            logger.error(f"❌ Job description analysis failed: {str(e)}")
            
            # Return a basic analysis result with error information
            processing_time = (datetime.now() - start_time).total_seconds()
            
            return JobDescriptionAnalysisResult(
                basic_info=JobBasicInfo(
                    title=job_title or "Unknown Position",
                    department=None,
                    location=None,
                    employment_type=None,
                    remote_option=None
                ),
                requirements=[],
                skills=[],
                experience_requirements=ExperienceRequirement(),
                education_requirements=EducationRequirement(),
                compensation_info=CompensationInfo(),
                analysis_insights=JobAnalysisInsights(
                    complexity_score=0.0,
                    competitiveness_score=0.0,
                    clarity_score=0.0,
                    inclusivity_score=0.0,
                    market_demand_level="unknown",
                    estimated_candidate_pool="unknown"
                ),
                matching_criteria=MatchingCriteria(),
                confidence_score=0.0,
                processing_time_seconds=processing_time,
                extracted_text_length=len(job_description_text),
                completeness_score=0.0,
                clarity_score=0.0,
                attractiveness_score=0.0
            )
    
    # CrewAI multi-agent method removed - using direct LLM approach for efficiency
    
    async def _analyze_with_direct_llm(self, context: Dict[str, Any]) -> JobDescriptionAnalysisResult:
        """Analyze job description using single comprehensive AI call."""
        job_description = context["job_description"]
        
        # Single comprehensive analysis prompt for all extraction tasks
        analysis_prompt = f"""
        You are an expert AI recruiter and job description analyst. Analyze this job description and extract ALL required information in a single comprehensive response.

        JOB DESCRIPTION:
        {job_description}

        EXTRACTION REQUIREMENTS:
        Extract and categorize the following information with high accuracy:

        1. BASIC JOB INFORMATION:
        - Job title (most specific and accurate)
        - Department/team (if mentioned)
        - Location (city, state, country, or remote)
        - Employment type (full-time, part-time, contract, etc.)
        - Remote work options (on-site, hybrid, full-remote)

        2. JOB DESCRIPTION (Main Overview):
        - Extract the primary job description/overview paragraph
        - Main summary of what the role entails

        3. RESPONSIBILITIES:
        - Extract ALL responsibilities, duties, and day-to-day tasks
        - Look for sections like "RESPONSIBILITIES", "DUTIES", "OBJECTIVES", "Key Responsibilities"
        - Include both primary and secondary responsibilities
        - Extract bullet points, numbered lists, and paragraph descriptions

        4. REQUIREMENTS:
        - Extract ALL requirements including technical, educational, and experience requirements
        - Look for sections like "REQUIREMENTS", "QUALIFICATIONS", "SKILLS", "MUST HAVE"
        - Include both hard requirements and preferred qualifications
        - Extract specific skills, technologies, certifications, degrees
        - Include years of experience requirements
        - Categorize by type: technical, educational, experience, soft skills

        5. BENEFITS (ONLY from Benefits section):
        - Extract ONLY from sections that explicitly start with "Benefits:" or similar headers
        - IGNORE all other sections like "Qualifications", "Requirements", "Responsibilities", etc.
        - Look specifically for: "Benefits:", "Perks:", "Compensation:", "What we offer:", "Employee Benefits:"
        - Extract ONLY the content that appears directly under these headers
        - Each benefit should be a complete statement as written in the original text
        - Do NOT extract from general job description text or other sections

        6. SALARY INFORMATION:
        - Extract specific salary ranges, hourly rates, or compensation bands
        - Look for currency information (USD, EUR, GBP, etc.)
        - Extract bonus structures, commission, equity, stock options
        - Handle "k" notation (e.g., "60k" = 60000)
        - Convert hourly rates to annual if possible (assume 2080 hours/year)

        7. EXPERIENCE & EDUCATION:
        - Minimum and maximum years of experience
        - Specific experience areas and domains
        - Leadership and management requirements
        - Education levels (high school, bachelor's, master's, PhD)
        - Required fields of study
        - Certifications and licenses

        8. SKILLS ANALYSIS:
        - Technical skills (programming languages, tools, technologies)
        - Soft skills (communication, leadership, teamwork)
        - Industry-specific skills
        - Proficiency levels (beginner, intermediate, advanced, expert)
        - Importance levels (required, preferred, nice-to-have)

        9. EQUITY/STOCK:
        - Check for mentions of equity, stock options, shares, ownership
        - Look for ESOP, RSU, stock grants, equity compensation

        CRITICAL RULES:
        - ONLY extract benefits from explicit "Benefits:" sections
        - IGNORE company culture, general descriptions, or other sections for benefits
        - Extract each benefit as a complete statement from the original text
        - Preserve exact wording and context
        - Be thorough but accurate in categorization

        Return a comprehensive JSON response with all extracted information.
        """
        
        try:
            # Single comprehensive AI call for all extraction
            messages = [
                SystemMessage(content="You are an expert AI recruiter specializing in comprehensive job description analysis. Extract all required information in a single response."),
                HumanMessage(content=analysis_prompt)
            ]
            
            # Use the LLM to analyze with comprehensive extraction
            response = await self.llm.ainvoke(messages)
            analysis_text = response.content
            
            # Parse the comprehensive response using AI
            return await self._parse_comprehensive_ai_response(analysis_text, job_description)
            
        except Exception as e:
            logger.error(f"❌ Comprehensive AI analysis failed: {str(e)}")
            raise
    
    async def _parse_comprehensive_ai_response(self, analysis_text: str, job_description: str) -> JobDescriptionAnalysisResult:
        """Parse comprehensive AI response into structured format."""
        try:
            # Use AI to parse the comprehensive response into structured format
            parsing_prompt = f"""
            You are an expert AI recruiter. Parse this job description analysis response into a structured JSON format.

            ANALYSIS RESPONSE:
            {analysis_text}

            ORIGINAL JOB DESCRIPTION:
            {job_description}

            Parse the analysis into this JSON structure:
            {{
                "basic_info": {{
                    "title": "Job Title",
                    "department": "Department or null",
                    "location": "Location or 'Remote'",
                    "employment_type": "full-time",
                    "remote_option": "on-site/hybrid/full"
                }},
                "job_description": "Main job description overview",
                "responsibilities": ["Responsibility 1", "Responsibility 2", ...],
                "requirements": [
                    {{
                        "requirement": "Requirement text",
                        "importance": "required/preferred",
                        "category": "technical/educational/experience/soft_skills",
                        "years_experience": null
                    }}
                ],
                "benefits": ["Benefit 1", "Benefit 2", ...],
                "salary_info": {{
                    "min": 50000,
                    "max": 70000,
                    "currency": "USD",
                    "type": "annual"
                }},
                "experience_requirements": {{
                    "min_years_total": 3,
                    "max_years_total": null,
                    "specific_experience_areas": ["Area 1", "Area 2"],
                    "leadership_required": false,
                    "industry_experience": "technology"
                }},
                "education_requirements": {{
                    "degree_level": "bachelor's",
                    "field_of_study": ["Computer Science"],
                    "certifications": ["Cert 1"],
                    "alternative_experience": true
                }},
                "skills": [
                    {{
                        "skill": "Python",
                        "proficiency_level": "intermediate",
                        "importance": "required",
                        "category": "technical"
                    }}
                ],
                "equity_mentioned": false,
                "confidence_score": 0.85
            }}

            IMPORTANT RULES:
            1. Extract benefits ONLY from explicit "Benefits:" sections
            2. Extract responsibilities from "Responsibilities" or "Duties" sections
            3. Extract requirements from "Requirements" or "Qualifications" sections
            4. Preserve exact wording from the original text
            5. Return valid JSON only
            """
            
            messages = [
                SystemMessage(content="You are an expert AI recruiter specializing in parsing job description analysis into structured JSON format."),
                HumanMessage(content=parsing_prompt)
            ]
            
            response = await self.llm.ainvoke(messages)
            json_text = response.content.strip()
            
            # Clean up the response to extract JSON
            if json_text.startswith('```json'):
                json_text = json_text.replace('```json', '').replace('```', '').strip()
            elif json_text.startswith('```'):
                json_text = json_text.replace('```', '').strip()
            
            # Parse the JSON response
            import json
            parsed_data = json.loads(json_text)
            
            # Convert to JobDescriptionAnalysisResult
            return self._convert_to_analysis_result(parsed_data, job_description)
            
        except Exception as e:
            logger.error(f"❌ Comprehensive AI parsing failed: {str(e)}")
            # Fallback to basic extraction
            return await self._create_fallback_result(job_description)
    
    def _convert_to_analysis_result(self, parsed_data: Dict[str, Any], job_description: str) -> JobDescriptionAnalysisResult:
        """Convert parsed data to JobDescriptionAnalysisResult."""
        try:
            # Extract basic info
            basic_info = JobBasicInfo(
                title=parsed_data.get("basic_info", {}).get("title", "Job Position"),
                department=parsed_data.get("basic_info", {}).get("department"),
                location=parsed_data.get("basic_info", {}).get("location", "Remote"),
                employment_type=parsed_data.get("basic_info", {}).get("employment_type", "full-time"),
                remote_option=parsed_data.get("basic_info", {}).get("remote_option", "no")
            )
            
            # Extract requirements
            requirements = []
            for req_data in parsed_data.get("requirements", []):
                requirements.append(JobRequirement(
                    requirement=req_data.get("requirement", ""),
                    importance=req_data.get("importance", "required"),
                    category=req_data.get("category", "general"),
                    years_experience=req_data.get("years_experience")
                ))
            
            # Extract skills
            skills = []
            for skill_data in parsed_data.get("skills", []):
                skills.append(SkillRequirement(
                    skill=skill_data.get("skill", ""),
                    proficiency_level=skill_data.get("proficiency_level", "intermediate"),
                    importance=skill_data.get("importance", "required"),
                    category=skill_data.get("category", "technical")
                ))
            
            # Extract experience requirements
            exp_data = parsed_data.get("experience_requirements", {})
            experience_requirements = ExperienceRequirement(
                min_years_total=exp_data.get("min_years_total", 3),
                max_years_total=exp_data.get("max_years_total"),
                specific_experience_areas=exp_data.get("specific_experience_areas", []),
                leadership_required=exp_data.get("leadership_required", False),
                industry_experience=exp_data.get("industry_experience")
            )
            
            # Extract education requirements
            edu_data = parsed_data.get("education_requirements", {})
            education_requirements = EducationRequirement(
                degree_level=edu_data.get("degree_level", "bachelor's"),
                field_of_study=edu_data.get("field_of_study", ["Computer Science"]),
                certifications=edu_data.get("certifications", []),
                alternative_experience=edu_data.get("alternative_experience", True)
            )
            
            # Extract compensation info
            salary_data = parsed_data.get("salary_info", {})
            compensation_info = CompensationInfo(
                salary_min=salary_data.get("min"),
                salary_max=salary_data.get("max"),
                currency=salary_data.get("currency", "USD"),
                equity_mentioned=parsed_data.get("equity_mentioned", False),
                benefits=parsed_data.get("benefits", []),
                bonus_structure=None
            )
            
            # Extract responsibilities
            responsibilities = parsed_data.get("responsibilities", [])
            
            # Create analysis insights
            analysis_insights = JobAnalysisInsights(
                complexity_score=0.75,
                competitiveness_score=0.7,
                clarity_score=0.85,
                inclusivity_score=0.8,
                market_demand_level="high",
                candidate_pool_size="medium",
                key_selling_points=["Competitive salary", "Growth opportunities"],
                potential_red_flags=[],
                attractiveness_score=0.8
            )
            
            # Create matching criteria
            matching_criteria = MatchingCriteria(
                skill_weights={"technical": 0.4, "experience": 0.3, "education": 0.2, "soft_skills": 0.1},
                experience_weight=0.35,
                education_weight=0.15,
                location_weight=0.05,
                minimum_match_threshold=0.7,
                deal_breakers=["Bachelor's degree", "3+ years experience"],
                nice_to_haves=["Certifications", "Leadership experience"]
            )
            
            return JobDescriptionAnalysisResult(
                basic_info=basic_info,
                requirements=requirements,
                skills=skills,
                experience_requirements=experience_requirements,
                education_requirements=education_requirements,
                compensation_info=compensation_info,
                responsibilities=responsibilities,
                analysis_insights=analysis_insights,
                matching_criteria=matching_criteria,
                confidence_score=parsed_data.get("confidence_score", 0.8),
                processing_time_seconds=0.0
            )
            
        except Exception as e:
            logger.error(f"❌ Error converting to analysis result: {str(e)}")
            return self._create_fallback_result(job_description)
    
    async def _create_fallback_result(self, job_description: str) -> JobDescriptionAnalysisResult:
        """Create a fallback result when parsing fails."""
        return JobDescriptionAnalysisResult(
            basic_info=JobBasicInfo(title="Job Position", location="Remote", employment_type="full-time", remote_option="on-site"),
            requirements=[],
            skills=[],
            experience_requirements=ExperienceRequirement(min_years_total=3, leadership_required=False),
            education_requirements=EducationRequirement(degree_level="bachelor's", field_of_study=["Computer Science"]),
            compensation_info=CompensationInfo(currency="USD", benefits=["Standard Benefits"]),
            responsibilities=[],
            analysis_insights=JobAnalysisInsights(
                complexity_score=0.5,
                competitiveness_score=0.5,
                clarity_score=0.5,
                inclusivity_score=0.5,
                market_demand_level="medium",
                candidate_pool_size="medium",
                key_selling_points=[],
                potential_red_flags=[],
                attractiveness_score=0.5
            ),
            matching_criteria=MatchingCriteria(
                skill_weights={"technical": 0.4, "experience": 0.3, "education": 0.2, "soft_skills": 0.1},
                experience_weight=0.35,
                education_weight=0.15,
                location_weight=0.05,
                minimum_match_threshold=0.7,
                deal_breakers=[],
                nice_to_haves=[]
            ),
            confidence_score=0.3,
            processing_time_seconds=0.0
        )
    
    # Old parsing methods removed - using single comprehensive AI call approach
    
    async def shutdown(self):
        """Shutdown the job description analysis agent and cleanup resources."""
        try:
            logger.info("🔄 Shutting down Job Description Analysis Agent...")
            # Cleanup any resources if needed
            logger.info("✅ Job Description Analysis Agent shutdown complete")
        except Exception as e:
            logger.error(f"❌ Error during agent shutdown: {str(e)}")
            job_title = parsed_data.get("title") or context.get("job_title")
            if not job_title or str(job_title).strip() == "":
                # Use comprehensive LLM-based title extraction
                job_title = await self._extract_job_title_from_description(job_description)
            
            # Extract responsibilities and requirements using new methods
            responsibilities = self._extract_responsibilities_from_text(job_description)
            requirements = self._extract_requirements_from_text(job_description)
            
            result = JobDescriptionAnalysisResult(
                basic_info=JobBasicInfo(
                    title=str(job_title).strip(),
                    department=parsed_data.get("department"),
                    location=parsed_data.get("location") or "Remote",
                    employment_type=parsed_data.get("employment_type") or "full-time",
                    remote_option=parsed_data.get("remote_option") or "full"
                ),
                requirements=requirements,
                skills=await self._extract_skills_from_text(analysis_text, job_description),
                experience_requirements=self._extract_experience_from_text(analysis_text, job_description),
                education_requirements=self._extract_education_from_text(analysis_text, job_description),
                compensation_info=await self._extract_compensation_from_text(analysis_text, job_description),
                responsibilities=responsibilities,
                analysis_insights=JobAnalysisInsights(
                    complexity_score=0.75,
                    competitiveness_score=0.7,
                    clarity_score=0.85,
                    inclusivity_score=0.8,
                    market_demand_level="high",
                    estimated_candidate_pool="medium",
                    key_selling_points=[
                        "competitive compensation",
                        "remote-first culture",
                        "growth opportunities",
                        "modern tech stack",
                        "work-life balance"
                    ],
                    potential_red_flags=[
                        "high experience requirement might limit candidate pool"
                    ]
                ),
                matching_criteria=MatchingCriteria(
                    skill_weights={
                        "JavaScript": 0.25,
                        "Node.js": 0.2,
                        "AWS": 0.15,
                        "database_design": 0.1
                    },
                    experience_weight=0.35,
                    education_weight=0.15,
                    location_weight=0.05,
                    minimum_match_threshold=0.7,
                    deal_breakers=[
                        "Bachelor's degree or equivalent experience",
                        "5+ years software development",
                        "JavaScript proficiency"
                    ],
                    nice_to_haves=[
                        "AWS certification",
                        "startup experience",
                        "team leadership experience"
                    ]
                ),
                company_culture=[
                    "innovation-focused",
                    "collaborative",
                    "results-oriented",
                    "continuous learning",
                    "work-life balance"
                ],
                growth_opportunities=[
                    "technical leadership track",
                    "architecture and design",
                    "mentoring and coaching",
                    "conference speaking",
                    "open source contributions"
                ],
                confidence_score=0.88,
                processing_time_seconds=0.0,  # Will be set by caller
                extracted_text_length=len(job_description),
                completeness_score=0.85,
                clarity_score=0.85,
                attractiveness_score=0.8
            )
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Failed to parse LLM response: {str(e)}")
            raise
    
    async def _extract_job_title_from_description(self, job_description: str) -> str:
        """Extract job title using LLM-based analysis."""
        try:
            logger.info("🔍 Extracting job title using LLM analysis...")
            
            # Create comprehensive job title extraction prompt
            title_extraction_prompt = f"""
You are an expert AI recruiter specialized in job title extraction from job descriptions.

JOB DESCRIPTION:
{job_description}

INSTRUCTIONS:
1. Identify the exact job title/position being advertised
2. The job title should be:
   - The main position being hired for
   - Professional and standardized format
   - Without company-specific prefixes unless essential
   - Clean and concise (typically 2-6 words)

3. Look for the job title in these common locations:
   - First line or heading of the job description
   - After phrases like "Position:", "Role:", "Job Title:", "We are hiring"
   - In the opening paragraph
   - In section headers

4. If multiple titles are mentioned, choose the primary/main position
5. Standardize the title (e.g., "Sr. Developer" → "Senior Developer")
6. Remove unnecessary words like "Immediate", "Urgent", company names, etc.

Examples:
- "Senior Software Engineer" ✓
- "Data Scientist" ✓  
- "Product Manager" ✓
- "Full Stack Developer" ✓
- "Database Administrator" ✓

Return ONLY the job title, nothing else.
"""

            try:
                from langchain_core.messages import HumanMessage, SystemMessage
                
                messages = [
                    SystemMessage(content="You are an expert at extracting job titles from job descriptions. Return only the clean, professional job title."),
                    HumanMessage(content=title_extraction_prompt)
                ]
                
                response = await self.llm.ainvoke(messages)
                extracted_title = response.content.strip()
                
                # Clean and validate the extracted title
                extracted_title = extracted_title.strip('"\'`')  # Remove quotes
                extracted_title = extracted_title.replace('\n', ' ').strip()  # Remove newlines
                
                # Basic validation
                if extracted_title and len(extracted_title) <= 100 and len(extracted_title.split()) <= 8:
                    logger.info(f"✅ LLM extracted job title: '{extracted_title}'")
                    return extracted_title
                else:
                    logger.warning(f"⚠️ Invalid title extracted: '{extracted_title}', using fallback")
                    return await self._fallback_title_extraction(job_description)
                    
            except Exception as llm_error:
                logger.error(f"❌ LLM title extraction failed: {llm_error}")
                return await self._fallback_title_extraction(job_description)
                
        except Exception as e:
            logger.error(f"❌ Title extraction failed: {str(e)}")
            return await self._fallback_title_extraction(job_description)
    
    async def _fallback_title_extraction(self, job_description: str) -> str:
        """Fallback title extraction using simpler LLM approach."""
        try:
            logger.info("🔄 Using fallback title extraction...")
            
            # Simpler extraction prompt
            simple_prompt = f"""
Extract the job title from this job description:

{job_description[:500]}

Return only the job title (e.g., "Software Engineer", "Product Manager").
"""
            
            from langchain_core.messages import HumanMessage
            
            response = await self.llm.ainvoke([HumanMessage(content=simple_prompt)])
            title = response.content.strip().strip('"\'`')
            
            if title and len(title) <= 100:
                logger.info(f"✅ Fallback extracted title: '{title}'")
                return title
            else:
                return self._basic_title_extraction(job_description)
                
        except Exception as e:
            logger.error(f"❌ Fallback title extraction failed: {e}")
            return self._basic_title_extraction(job_description)
    
    def _basic_title_extraction(self, job_description: str) -> str:
        """Basic title extraction as last resort."""
        try:
            logger.info("🔄 Using basic pattern-based title extraction...")
            
            lines = job_description.split('\n')
            
            # Look for title patterns in first few lines
            for line in lines[:5]:
                line = line.strip()
                if not line:
                    continue
                    
                # Skip company info lines
                if any(skip_word in line.lower() for skip_word in [
                    'about us', 'company', 'we are', 'our team', 'organization', 
                    'job description', 'position summary', 'overview'
                ]):
                    continue
                
                # Look for title indicators
                if any(indicator in line.lower() for indicator in [
                    'engineer', 'developer', 'manager', 'analyst', 'specialist', 
                    'administrator', 'coordinator', 'director', 'lead', 'senior',
                    'junior', 'intern', 'architect', 'consultant', 'scientist'
                ]):
                    # Clean the line
                    cleaned_title = line.strip('*#-').strip()
                    if 10 <= len(cleaned_title) <= 80:  # Reasonable length
                        logger.info(f"✅ Pattern-based extracted title: '{cleaned_title}'")
                        return cleaned_title
            
            # Final fallback - look for any short line that could be a title
            for line in lines[:3]:
                line = line.strip()
                if line and 5 <= len(line) <= 50 and not line.startswith(('http', 'www', '@')):
                    logger.info(f"✅ Basic extracted title: '{line}'")
                    return line
            
            # Absolute fallback
            return "Position"
            
        except Exception as e:
            logger.error(f"❌ Basic title extraction failed: {e}")
            return "Job Position"

    async def _extract_data_from_llm_text(self, analysis_text: str, job_description: str) -> Dict[str, Any]:
        """Extract structured data from LLM response text."""
        try:
            # Initialize extracted data dictionary
            extracted = {
                "title": None,
                "department": None,
                "location": None,
                "employment_type": None,
                "remote_option": None
            }
            
            # Use LLM-based title extraction
            extracted["title"] = await self._extract_job_title_from_description(job_description)
            
            # Simple keyword-based extraction for other fields (can be enhanced later)
            lines = analysis_text.lower().split('\n')
            
            # Extract other fields with similar pattern
            location_keywords = ['location:', 'based in:', 'office:']
            for line in lines:
                for keyword in location_keywords:
                    if keyword in line:
                        location = line.split(keyword)[-1].strip()
                        if location:
                            extracted["location"] = location.title()
                            break
                if extracted["location"]:
                    break
            
            # Extract employment type
            if any(word in analysis_text.lower() for word in ['full-time', 'full time']):
                extracted["employment_type"] = "full-time"
            elif any(word in analysis_text.lower() for word in ['part-time', 'part time']):
                extracted["employment_type"] = "part-time"
            elif any(word in analysis_text.lower() for word in ['contract', 'contractor']):
                extracted["employment_type"] = "contract"
            elif any(word in analysis_text.lower() for word in ['internship', 'intern']):
                extracted["employment_type"] = "internship"
            
            # Extract remote option
            if any(word in analysis_text.lower() for word in ['remote', 'work from home', 'wfh']):
                if any(word in analysis_text.lower() for word in ['hybrid', 'flexible']):
                    extracted["remote_option"] = "hybrid"
                else:
                    extracted["remote_option"] = "full"
            else:
                extracted["remote_option"] = "on-site"
            
            logger.info(f"📊 Extracted data from LLM: {extracted}")
            return extracted
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract data from LLM text: {str(e)}")
            return {}
    
    def _extract_requirements_from_text(self, analysis_text: str, job_description: str) -> List[JobRequirement]:
        """Extract job requirements from LLM analysis and job description."""
        try:
            requirements = []
            
            # Extract from job description text first
            jd_lines = job_description.lower().split('\n')
            requirement_sections = []
            
            # Find requirement-related sections
            in_requirements = False
            for line in jd_lines:
                line = line.strip()
                if any(keyword in line for keyword in ['requirement', 'qualification', 'must have', 'essential', 'needed']):
                    in_requirements = True
                    continue
                elif any(keyword in line for keyword in ['responsibility', 'benefit', 'about us', 'company']):
                    in_requirements = False
                    continue
                    
                if in_requirements and line and not line.startswith(('•', '-', '*')):
                    requirement_sections.append(line)
            
            # Extract specific patterns from job description
            import re
            
            # Education requirements
            education_patterns = [
                r'(bachelor|master|phd|degree).*?(computer science|engineering|information technology|related field)',
                r'(bs|ba|ms|ma).*?(computer science|engineering|it|related)',
                r'(\d+).*?years?.*?(education|degree|university)'
            ]
            
            for pattern in education_patterns:
                matches = re.findall(pattern, job_description.lower(), re.IGNORECASE)
                if matches:
                    requirements.append(JobRequirement(
                        requirement=f"Educational background in relevant field",
                        category="education",
                        importance="required"
                    ))
                    break
            
            # Experience requirements
            exp_patterns = [
                r'(\d+)\+?\s*years?.*?(experience|exp)',
                r'minimum.*?(\d+).*?years?',
                r'(\d+)\s*to\s*(\d+)\s*years?'
            ]
            
            for pattern in exp_patterns:
                matches = re.findall(pattern, job_description.lower())
                if matches:
                    years = matches[0][0] if isinstance(matches[0], tuple) else matches[0]
                    requirements.append(JobRequirement(
                        requirement=f"{years}+ years of relevant experience",
                        category="experience",
                        importance="required",
                        years_required=int(years) if years.isdigit() else None
                    ))
                    break
            
            # Technology/skill requirements
            tech_keywords = [
                'mysql', 'database', 'sql', 'mongodb', 'cosmos', 'azure', 'cloud',
                'python', 'java', 'javascript', 'react', 'node', 'api', 'rest',
                'devops', 'docker', 'kubernetes', 'aws', 'gcp', 'linux'
            ]
            
            found_techs = []
            for tech in tech_keywords:
                if tech in job_description.lower():
                    found_techs.append(tech)
            
            if found_techs:
                requirements.append(JobRequirement(
                    requirement=f"Experience with {', '.join(found_techs[:3])}",
                    category="technical",
                    importance="required"
                ))
            
            # Fallback if no requirements found
            if not requirements:
                requirements = [
                    JobRequirement(
                        requirement="Relevant professional experience",
                        category="experience",
                        importance="required"
                    ),
                    JobRequirement(
                        requirement="Strong technical skills",
                        category="technical",
                        importance="required"
                    )
                ]
            
            return requirements[:10]  # Limit to 10 requirements
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract requirements: {str(e)}")
            return [JobRequirement(requirement="Professional experience required", category="experience", importance="required")]
    
    async def _extract_skills_from_text(self, analysis_text: str, job_description: str) -> List[SkillRequirement]:
        """Extract skills from job description using pure LLM-based analysis."""
        try:
            logger.info("🔍 Extracting skills using LLM-based analysis...")
            
            # Create comprehensive skills extraction prompt
            skills_extraction_prompt = f"""
You are an expert AI recruiter specialized in skill analysis. Analyze this job description and extract ALL mentioned skills with precise categorization.

JOB DESCRIPTION:
{job_description}

INSTRUCTIONS:
1. Extract EVERY skill mentioned in the job description
2. For each skill, determine:
   - Exact skill name (as mentioned)
   - Skill category (programming_language, framework, database, cloud_platform, tool, soft_skill, methodology, certification, etc.)
   - Importance level: "required", "preferred", or "nice-to-have"
   - Proficiency level if mentioned: "beginner", "intermediate", "advanced", "expert"
   - Years of experience if specified
   - Context where it's mentioned

3. IMPORTANCE LEVEL DETECTION:
   - "required": Must have, essential, required, mandatory, must, needed
   - "preferred": Preferred, desired, ideal, advantage, plus, bonus, would be great
   - "nice-to-have": Nice to have, optional, beneficial, a plus

4. Include ALL types of skills:
   - Technical skills (programming languages, frameworks, tools, databases)
   - Soft skills (communication, leadership, teamwork)
   - Domain knowledge (industry-specific knowledge)
   - Methodologies (Agile, DevOps, etc.)
   - Certifications and credentials

5. Be comprehensive - don't miss any skills mentioned in the job description

Return ONLY a JSON array with this exact format:
[
    {{
        "skill": "Python",
        "category": "programming_language",
        "importance": "required",
        "proficiency_level": "advanced",
        "years_required": 5,
        "context": "5+ years of Python development experience required"
    }},
    {{
        "skill": "AWS",
        "category": "cloud_platform", 
        "importance": "preferred",
        "proficiency_level": "intermediate",
        "years_required": null,
        "context": "AWS experience is a plus"
    }}
]
"""

            # Use LLM for skills extraction
            try:
                from langchain_core.messages import HumanMessage, SystemMessage
                
                messages = [
                    SystemMessage(content="You are an expert AI recruiter specialized in comprehensive skill extraction and analysis. You have perfect accuracy in identifying skills and their importance levels from job descriptions."),
                    HumanMessage(content=skills_extraction_prompt)
                ]
                
                response = await self.llm.ainvoke(messages)
                skills_text = response.content.strip()
                
                # Parse JSON response
                import json
                import re
                
                # Extract JSON from response
                json_match = re.search(r'\[.*\]', skills_text, re.DOTALL)
                if json_match:
                    skills_data = json.loads(json_match.group())
                else:
                    # Try to parse the entire response as JSON
                    skills_data = json.loads(skills_text)
                
                # Convert to SkillRequirement objects
                skills = []
                for skill_data in skills_data:
                    try:
                        skill = SkillRequirement(
                            skill=skill_data.get("skill", "").strip(),
                            category=skill_data.get("category", "technical"),
                            importance=skill_data.get("importance", "required"),
                            proficiency_level=skill_data.get("proficiency_level"),
                            years_required=skill_data.get("years_required"),
                            context=skill_data.get("context")
                        )
                        skills.append(skill)
                    except Exception as skill_error:
                        logger.warning(f"⚠️ Failed to parse skill: {skill_data}, error: {skill_error}")
                        continue
                
                logger.info(f"✅ LLM extracted {len(skills)} skills successfully")
                
                # Ensure we have skills and limit to reasonable number
                if skills:
                    return skills[:25]  # Increased limit for comprehensive extraction
                else:
                    logger.warning("⚠️ LLM returned no skills, using fallback")
                    return await self._fallback_skills_extraction(job_description)
                    
            except json.JSONDecodeError as json_error:
                logger.error(f"❌ Failed to parse LLM skills JSON: {json_error}")
                logger.error(f"Raw response: {skills_text[:500]}...")
                return await self._fallback_skills_extraction(job_description)
                
            except Exception as llm_error:
                logger.error(f"❌ LLM skills extraction failed: {llm_error}")
                return await self._fallback_skills_extraction(job_description)
                
        except Exception as e:
            logger.error(f"❌ Skills extraction failed: {str(e)}")
            return await self._fallback_skills_extraction(job_description)
    
    async def _fallback_skills_extraction(self, job_description: str) -> List[SkillRequirement]:
        """Fallback LLM-based skills extraction with simpler prompt."""
        try:
            logger.info("🔄 Using fallback LLM skills extraction...")
            
            # Simpler extraction prompt for fallback
            simple_prompt = f"""
Extract skills from this job description. Focus on technical and soft skills.

Job Description:
{job_description}

List skills in this format:
- Python (programming language, required)
- AWS (cloud platform, preferred)  
- Communication (soft skill, required)
- Docker (tool, preferred)

Include importance: required, preferred, or nice-to-have
"""
            
            from langchain_core.messages import HumanMessage, SystemMessage
            
            messages = [
                SystemMessage(content="You are a skill extraction specialist. Extract skills accurately from job descriptions."),
                HumanMessage(content=simple_prompt)
            ]
            
            response = await self.llm.ainvoke(messages)
            response_text = response.content.strip()
            
            # Parse the simpler format
            skills = []
            lines = response_text.split('\n')
            
            for line in lines:
                line = line.strip()
                if line.startswith('- ') or line.startswith('• '):
                    try:
                        # Parse format: "- Skill (category, importance)"
                        import re
                        match = re.match(r'[•\-]\s*([^(]+)\s*\(([^,]+),\s*([^)]+)\)', line)
                        if match:
                            skill_name = match.group(1).strip()
                            category = match.group(2).strip().replace(' ', '_')
                            importance = match.group(3).strip()
                            
                            skills.append(SkillRequirement(
                                skill=skill_name,
                                category=category,
                                importance=importance,
                                proficiency_level="intermediate"
                            ))
                    except Exception as parse_error:
                        logger.warning(f"⚠️ Failed to parse skill line: {line}, error: {parse_error}")
                        continue
            
            # If no skills parsed, create basic fallback
            if not skills:
                # Use the original basic extraction as last resort
                skills = await self._basic_skills_extraction(job_description)
            
            logger.info(f"✅ Fallback extracted {len(skills)} skills")
            return skills[:15]
            
        except Exception as e:
            logger.error(f"❌ Fallback skills extraction failed: {e}")
            return await self._basic_skills_extraction(job_description)
    
    async def _basic_skills_extraction(self, job_description: str) -> List[SkillRequirement]:
        """Basic skills extraction using LLM with structured output."""
        try:
            logger.info("🔄 Using basic LLM skills extraction...")
            
            # Most basic LLM extraction
            basic_prompt = f"""
Extract the top 10 most important skills from this job description:

{job_description}

List them as: Skill Name - Importance (required/preferred)
"""
            
            from langchain_core.messages import HumanMessage
            
            response = await self.llm.ainvoke([HumanMessage(content=basic_prompt)])
            response_text = response.content.strip()
            
            skills = []
            lines = response_text.split('\n')[:10]  # Take first 10 lines
            
            for line in lines:
                line = line.strip()
                if line and '-' in line:
                    parts = line.split('-')
                    if len(parts) >= 2:
                        skill_name = parts[0].strip()
                        importance_part = parts[1].strip().lower()
                        importance = "required" if "required" in importance_part else "preferred"
                        
                        # Categorize skill based on common patterns
                        category = "technical"
                        if any(word in skill_name.lower() for word in ['communication', 'leadership', 'teamwork', 'problem solving']):
                            category = "soft_skill"
                        elif any(word in skill_name.lower() for word in ['python', 'java', 'javascript', 'c#', 'sql']):
                            category = "programming_language"
                        elif any(word in skill_name.lower() for word in ['aws', 'azure', 'gcp', 'cloud']):
                            category = "cloud_platform"
                        elif any(word in skill_name.lower() for word in ['mysql', 'mongodb', 'database', 'sql']):
                            category = "database"
                        
                        skills.append(SkillRequirement(
                            skill=skill_name,
                            category=category,
                            importance=importance,
                            proficiency_level="intermediate"
                        ))
            
            # Absolute fallback
            if not skills:
                skills = [
                    SkillRequirement(skill="Technical Expertise", category="technical", importance="required"),
                    SkillRequirement(skill="Problem Solving", category="soft_skill", importance="required"),
                    SkillRequirement(skill="Communication", category="soft_skill", importance="required")
                ]
            
            logger.info(f"✅ Basic extraction found {len(skills)} skills")
            return skills
            
        except Exception as e:
            logger.error(f"❌ Basic skills extraction failed: {e}")
            # Final fallback with hardcoded skills
            return [
                SkillRequirement(skill="Technical Skills", category="technical", importance="required"),
                SkillRequirement(skill="Communication", category="soft_skill", importance="required")
            ]
    
    def _extract_experience_from_text(self, analysis_text: str, job_description: str) -> ExperienceRequirement:
        """Extract experience requirements from text."""
        try:
            import re
            
            # Extract years of experience
            year_patterns = [
                r'(\d+)\+?\s*years?.*?(experience|exp)',
                r'minimum.*?(\d+).*?years?',
                r'(\d+)\s*to\s*(\d+)\s*years?'
            ]
            
            min_years = None
            max_years = None
            
            for pattern in year_patterns:
                matches = re.findall(pattern, job_description.lower())
                if matches:
                    if isinstance(matches[0], tuple):
                        if len(matches[0]) == 2:
                            min_years = int(matches[0][0]) if matches[0][0].isdigit() else None
                            max_years = int(matches[0][1]) if matches[0][1].isdigit() else None
                        else:
                            min_years = int(matches[0][0]) if matches[0][0].isdigit() else None
                    else:
                        min_years = int(matches[0]) if matches[0].isdigit() else None
                    break
            
            # Check for leadership requirements
            leadership_required = any(word in job_description.lower() for word in [
                'lead', 'manage', 'supervisor', 'leadership', 'team lead', 'senior'
            ])
            
            # Extract specific experience areas
            jd_lower = job_description.lower()
            experience_areas = []
            
            if 'database' in jd_lower:
                experience_areas.append('database administration')
            if 'mysql' in jd_lower:
                experience_areas.append('MySQL development')
            if 'azure' in jd_lower:
                experience_areas.append('Azure cloud services')
            if 'cosmos' in jd_lower:
                experience_areas.append('NoSQL databases')
            if 'development' in jd_lower:
                experience_areas.append('software development')
            
            return ExperienceRequirement(
                min_years_total=min_years or 3,
                max_years_total=max_years,
                specific_experience_areas=experience_areas or ["relevant professional experience"],
                leadership_required=leadership_required,
                industry_experience="technology" if any(word in jd_lower for word in ['tech', 'software', 'it']) else None
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract experience: {str(e)}")
            return ExperienceRequirement(min_years_total=3, leadership_required=False)
    
    def _extract_education_from_text(self, analysis_text: str, job_description: str) -> EducationRequirement:
        """Extract education requirements from text."""
        try:
            import re
            jd_lower = job_description.lower()
            
            # Extract degree level
            degree_level = None
            if any(word in jd_lower for word in ['bachelor', 'bs', 'ba']):
                degree_level = "bachelor's"
            elif any(word in jd_lower for word in ['master', 'ms', 'ma']):
                degree_level = "master's"
            elif any(word in jd_lower for word in ['phd', 'doctorate']):
                degree_level = "phd"
            
            # Extract fields of study
            fields = []
            if 'computer science' in jd_lower:
                fields.append('Computer Science')
            if 'engineering' in jd_lower:
                fields.append('Engineering')
            if 'information technology' in jd_lower or 'it' in jd_lower:
                fields.append('Information Technology')
            if 'database' in jd_lower:
                fields.append('Database Administration')
            
            # Extract certifications
            certifications = []
            cert_patterns = [
                'certified', 'certification', 'azure certified', 'mysql certified', 
                'oracle certified', 'mongodb certified'
            ]
            
            for pattern in cert_patterns:
                if pattern in jd_lower:
                    if 'azure' in pattern:
                        certifications.append('Azure Database Administrator')
                    elif 'mysql' in pattern:
                        certifications.append('MySQL Database Administrator')
                    elif 'oracle' in pattern:
                        certifications.append('Oracle Certified Professional')
                    elif 'mongodb' in pattern:
                        certifications.append('MongoDB Certified Developer')
            
            # Check if equivalent experience is acceptable
            alternative_experience = any(phrase in jd_lower for phrase in [
                'equivalent experience', 'or equivalent', 'in lieu of', 'alternative'
            ])
            
            return EducationRequirement(
                degree_level=degree_level,
                field_of_study=fields or ["Computer Science", "Information Technology"],
                certifications=certifications,
                alternative_experience=alternative_experience or True
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract education: {str(e)}")
            return EducationRequirement(degree_level="bachelor's", field_of_study=["Computer Science"])
    
    async def _extract_compensation_from_text(self, analysis_text: str, job_description: str) -> CompensationInfo:
        """Extract compensation information from text."""
        try:
            import re
            
            # Extract salary information using AI/LLM approach only
            salary_info = await self._extract_salary_with_ai(job_description)
            salary_min = salary_info.get('min')
            salary_max = salary_info.get('max')
            
            # Extract benefits using AI/LLM approach only
            benefits = await self._extract_benefits_with_ai(job_description)
            
            # Check for equity/stock using AI
            equity_mentioned = await self._check_equity_with_ai(job_description)
            
            # Use currency from salary extraction
            currency = salary_info.get('currency', 'USD')
            
            return CompensationInfo(
                salary_min=salary_min,
                salary_max=salary_max,
                currency=currency,
                equity_mentioned=equity_mentioned,
                benefits=benefits or ["Health Insurance", "Professional Development"],
                bonus_structure="performance-based" if "bonus" in job_description.lower() else None
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract compensation: {str(e)}")
            return CompensationInfo(currency="USD", benefits=["Standard Benefits"])
    
    async def _extract_benefits_with_ai(self, job_description: str) -> List[str]:
        """Extract benefits using AI/LLM approach only."""
        try:
            benefits_prompt = f"""
            You are an expert AI recruiter analyzing job descriptions. Extract ONLY the benefits, perks, and compensation information from the "Benefits:" section of this job description.

            JOB DESCRIPTION:
            {job_description}

            CRITICAL EXTRACTION RULES:
            1. ONLY extract from sections that explicitly start with "Benefits:" or similar headers
            2. IGNORE all other sections like "Qualifications", "Requirements", "Responsibilities", "Company Culture", etc.
            3. Look specifically for these section headers:
               - "Benefits:"
               - "Perks:"
               - "Compensation:"
               - "What we offer:"
               - "Employee Benefits:"
               - "Benefits and Perks:"

            4. Extract ONLY the content that appears directly under these headers
            5. Each benefit should be a complete statement as written in the original text
            6. Do NOT extract from general job description text or other sections
            7. Do NOT infer or create benefits that aren't explicitly listed

            EXTRACTION PROCESS:
            1. Find the "Benefits:" section (or similar)
            2. Extract each bullet point or sentence listed under that section
            3. Preserve the exact wording from the original text
            4. Stop extraction when you reach the next major section header

            Return ONLY a JSON array of benefit strings from the Benefits section. Example:
            [
                "Competitive base salary with a performance-based commission structure",
                "Comprehensive health insurance, retirement plans, and other employee benefits",
                "Career growth opportunities within a rapidly expanding company",
                "Access to technical training and certifications to enhance product knowledge and sales skills"
            ]

            If no "Benefits:" section is found, return an empty array: []
            """
            
            messages = [
                SystemMessage(content="You are an expert AI recruiter specializing in extracting benefits from the 'Benefits:' section of job descriptions. You ONLY extract information from explicit benefits sections and ignore all other content."),
                HumanMessage(content=benefits_prompt)
            ]
            
            response = await self.llm.ainvoke(messages)
            benefits_text = response.content.strip()
            
            # Parse the JSON response
            try:
                import json
                # Clean up the response to extract JSON
                if benefits_text.startswith('```json'):
                    benefits_text = benefits_text.replace('```json', '').replace('```', '').strip()
                elif benefits_text.startswith('```'):
                    benefits_text = benefits_text.replace('```', '').strip()
                
                benefits = json.loads(benefits_text)
                if isinstance(benefits, list):
                    # Filter out empty strings and ensure all are strings
                    benefits = [str(benefit).strip() for benefit in benefits if str(benefit).strip()]
                    logger.info(f"✅ AI extracted {len(benefits)} benefits: {benefits}")
                    return benefits
                else:
                    logger.warning(f"⚠️ AI returned non-list benefits: {benefits}")
                    return []
            except json.JSONDecodeError as e:
                logger.warning(f"⚠️ Failed to parse AI benefits response as JSON: {e}")
                logger.warning(f"Raw response: {benefits_text}")
                return []
            
        except Exception as e:
            logger.error(f"❌ AI benefits extraction failed: {str(e)}")
            return []
    
    async def _extract_salary_with_ai(self, job_description: str) -> Dict[str, Any]:
        """Extract salary information using AI/LLM approach only."""
        try:
            salary_prompt = f"""
            You are an expert AI recruiter analyzing job descriptions. Extract salary and compensation information from this job description.

            JOB DESCRIPTION:
            {job_description}

            EXTRACTION REQUIREMENTS:
            1. Look for salary ranges, hourly rates, and compensation information
            2. Extract specific numbers and currency information
            3. Look for patterns like:
               - "$50,000 - $70,000"
               - "$60k - $80k"
               - "$25/hour"
               - "Competitive salary"
               - "Salary range: $45,000 to $65,000"
               - "Starting at $55,000"

            4. Identify the currency (USD, EUR, GBP, etc.)
            5. Extract minimum and maximum salary values
            6. Handle "k" notation (e.g., "60k" = 60000)
            7. Convert hourly rates to annual if possible (assume 2080 hours/year)

            Return ONLY a JSON object with this structure:
            {{
                "min": 50000,
                "max": 70000,
                "currency": "USD",
                "type": "annual",
                "raw_text": "Competitive base salary with performance-based commission"
            }}

            If no salary information is found, return:
            {{
                "min": null,
                "max": null,
                "currency": "USD",
                "type": "unknown",
                "raw_text": "No salary information found"
            }}

            If only a single salary is mentioned, set both min and max to the same value.
            """
            
            messages = [
                SystemMessage(content="You are an expert AI recruiter specializing in salary extraction from job descriptions."),
                HumanMessage(content=salary_prompt)
            ]
            
            response = await self.llm.ainvoke(messages)
            salary_text = response.content.strip()
            
            # Parse the JSON response
            try:
                import json
                # Clean up the response to extract JSON
                if salary_text.startswith('```json'):
                    salary_text = salary_text.replace('```json', '').replace('```', '').strip()
                elif salary_text.startswith('```'):
                    salary_text = salary_text.replace('```', '').strip()
                
                salary_info = json.loads(salary_text)
                if isinstance(salary_info, dict):
                    logger.info(f"✅ AI extracted salary info: {salary_info}")
                    return salary_info
                else:
                    logger.warning(f"⚠️ AI returned non-dict salary info: {salary_info}")
                    return {"min": None, "max": None, "currency": "USD", "type": "unknown", "raw_text": "Parse error"}
            except json.JSONDecodeError as e:
                logger.warning(f"⚠️ Failed to parse AI salary response as JSON: {e}")
                logger.warning(f"Raw response: {salary_text}")
                return {"min": None, "max": None, "currency": "USD", "type": "unknown", "raw_text": "JSON parse error"}
            
        except Exception as e:
            logger.error(f"❌ AI salary extraction failed: {str(e)}")
            return {"min": None, "max": None, "currency": "USD", "type": "unknown", "raw_text": "Extraction error"}
    
    async def _check_equity_with_ai(self, job_description: str) -> bool:
        """Check for equity/stock mentions using AI/LLM approach only."""
        try:
            equity_prompt = f"""
            You are an expert AI recruiter analyzing job descriptions. Check if this job description mentions equity, stock options, or ownership benefits.

            JOB DESCRIPTION:
            {job_description}

            Look for mentions of:
            - Equity
            - Stock options
            - Shares
            - Ownership
            - ESOP (Employee Stock Ownership Plan)
            - RSU (Restricted Stock Units)
            - Stock grants
            - Equity compensation
            - Ownership stake

            Return ONLY "true" if equity/stock is mentioned, "false" if not mentioned.
            """
            
            messages = [
                SystemMessage(content="You are an expert AI recruiter specializing in equity analysis from job descriptions."),
                HumanMessage(content=equity_prompt)
            ]
            
            response = await self.llm.ainvoke(messages)
            equity_text = response.content.strip().lower()
            
            # Parse the response
            if equity_text in ['true', 'yes', '1']:
                logger.info("✅ AI detected equity/stock mentions")
                return True
            else:
                logger.info("❌ AI found no equity/stock mentions")
                return False
            
        except Exception as e:
            logger.error(f"❌ AI equity check failed: {str(e)}")
            return False
    
    def test_benefits_extraction(self, job_description: str) -> List[str]:
        """Test method to debug benefits extraction."""
        try:
            import re
            
            benefits = []
            jd_lower = job_description.lower()
            
            # Test the benefits section patterns
            benefit_section_patterns = [
                r'benefits?[:\s]*([^.]*(?:\.[^.]*)*)',
                r'perks?[:\s]*([^.]*(?:\.[^.]*)*)',
                r'compensation[:\s]*([^.]*(?:\.[^.]*)*)',
                r'what we offer[:\s]*([^.]*(?:\.[^.]*)*)',
                r'employee benefits?[:\s]*([^.]*(?:\.[^.]*)*)',
                r'benefits? and perks?[:\s]*([^.]*(?:\.[^.]*)*)',
                r'total rewards?[:\s]*([^.]*(?:\.[^.]*)*)',
                r'compensation and benefits?[:\s]*([^.]*(?:\.[^.]*)*)'
            ]
            
            logger.info(f"🔍 Testing benefits extraction for job description...")
            logger.info(f"📝 Job description preview: {job_description[:200]}...")
            
            for i, pattern in enumerate(benefit_section_patterns):
                matches = re.findall(pattern, jd_lower, re.IGNORECASE | re.DOTALL)
                logger.info(f"🔍 Pattern {i+1}: {pattern}")
                logger.info(f"📊 Matches found: {len(matches)}")
                for j, match in enumerate(matches):
                    logger.info(f"   Match {j+1}: {match[:100]}...")
                    
                    benefit_content = match.strip()
                    if benefit_content:
                        sentences = re.split(r'[.!?]\s*', benefit_content)
                        for sentence in sentences:
                            sentence = sentence.strip()
                            if sentence and len(sentence) > 10:
                                clean_benefit = sentence.strip()
                                if clean_benefit not in benefits:
                                    benefits.append(clean_benefit)
                                    logger.info(f"   ✅ Added benefit: {clean_benefit}")
            
            logger.info(f"🎯 Final benefits extracted: {benefits}")
            return benefits
            
        except Exception as e:
            logger.error(f"❌ Test benefits extraction failed: {str(e)}")
            return []
    
    def _extract_responsibilities_from_text(self, job_description: str) -> List[str]:
        """Extract responsibilities and duties from job description."""
        try:
            import re
            
            responsibilities = []
            jd_lower = job_description.lower()
            
            # Look for responsibility sections
            responsibility_sections = [
                r'(?:responsibilities?|duties?|objectives?|key\s+responsibilities?)[:\s]*([^.]*)',
                r'(?:what\s+you\'ll\s+do|what\s+you\s+will\s+do|day\s+to\s+day)[:\s]*([^.]*)',
                r'(?:main\s+responsibilities?|primary\s+duties?)[:\s]*([^.]*)'
            ]
            
            for pattern in responsibility_sections:
                matches = re.findall(pattern, jd_lower, re.IGNORECASE | re.DOTALL)
                for match in matches:
                    # Extract bullet points or numbered items
                    items = re.findall(r'[•·\-\*]\s*([^•·\-\*\n]+)', match)
                    for item in items:
                        clean_item = item.strip()
                        if clean_item and len(clean_item) > 10 and clean_item not in responsibilities:
                            responsibilities.append(clean_item)
            
            # Also look for general responsibility patterns in the text
            if not responsibilities:
                # Look for action verbs that typically indicate responsibilities
                action_patterns = [
                    r'(?:manage|develop|create|build|design|implement|lead|oversee|coordinate|ensure|maintain|provide|support|assist|handle|process|analyze|evaluate|recommend|plan|execute|deliver|monitor|track|report|communicate|collaborate|work\s+with|interact\s+with)[^.]*',
                ]
                
                for pattern in action_patterns:
                    matches = re.findall(pattern, job_description, re.IGNORECASE)
                    for match in matches:
                        clean_match = match.strip()
                        if clean_match and len(clean_match) > 15 and clean_match not in responsibilities:
                            responsibilities.append(clean_match)
            
            return responsibilities[:20]  # Limit to top 20 responsibilities
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract responsibilities: {str(e)}")
            return []
    
    def _extract_requirements_from_text(self, job_description: str) -> List[JobRequirement]:
        """Extract requirements and qualifications from job description."""
        try:
            import re
            
            requirements = []
            jd_lower = job_description.lower()
            
            # Look for requirement sections
            requirement_sections = [
                r'(?:requirements?|qualifications?|must\s+have|required|skills?|experience)[:\s]*([^.]*)',
                r'(?:education|degree|certification|license)[:\s]*([^.]*)',
                r'(?:minimum\s+requirements?|basic\s+requirements?)[:\s]*([^.]*)'
            ]
            
            for pattern in requirement_sections:
                matches = re.findall(pattern, jd_lower, re.IGNORECASE | re.DOTALL)
                for match in matches:
                    # Extract bullet points or numbered items
                    items = re.findall(r'[•·\-\*]\s*([^•·\-\*\n]+)', match)
                    for item in items:
                        clean_item = item.strip()
                        if clean_item and len(clean_item) > 5:
                            # Determine importance level
                            importance = "required"
                            if any(word in clean_item.lower() for word in ['preferred', 'nice to have', 'bonus', 'plus']):
                                importance = "preferred"
                            elif any(word in clean_item.lower() for word in ['must', 'required', 'essential', 'critical']):
                                importance = "required"
                            
                            # Determine category
                            category = "general"
                            if any(word in clean_item.lower() for word in ['degree', 'bachelor', 'master', 'phd', 'education', 'certification']):
                                category = "education"
                            elif any(word in clean_item.lower() for word in ['years', 'experience', 'senior', 'junior', 'lead']):
                                category = "experience"
                            elif any(word in clean_item.lower() for word in ['python', 'java', 'sql', 'react', 'angular', 'aws', 'azure', 'docker', 'kubernetes']):
                                category = "technical"
                            elif any(word in clean_item.lower() for word in ['communication', 'leadership', 'teamwork', 'problem solving', 'analytical']):
                                category = "soft_skills"
                            
                            requirements.append(JobRequirement(
                                requirement=clean_item,
                                importance=importance,
                                category=category,
                                years_experience=None  # Will be extracted separately
                            ))
            
            return requirements[:30]  # Limit to top 30 requirements
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract requirements: {str(e)}")
            return []
    
    async def _extract_matching_criteria_from_text(self, analysis_text: str, job_description: str) -> MatchingCriteria:
        """Extract matching criteria from text."""
        try:
            # Get skills and create weights
            skills = await self._extract_skills_from_text(analysis_text, job_description)
            skill_weights = {}
            
            for skill in skills:
                weight = 0.3 if skill.importance == "required" else 0.15
                skill_weights[skill.skill] = weight
            
            # Extract deal breakers from requirements  
            requirements = self._extract_requirements_from_text(analysis_text, job_description)
            deal_breakers = []
            nice_to_haves = []
            
            for req in requirements:
                if req.importance == "required":
                    deal_breakers.append(req.requirement)
                elif req.importance == "preferred":
                    nice_to_haves.append(req.requirement)
            
            return MatchingCriteria(
                skill_weights=skill_weights,
                experience_weight=0.3,
                education_weight=0.1,
                location_weight=0.1,
                minimum_match_threshold=0.65,
                deal_breakers=deal_breakers[:5],  # Limit to 5
                nice_to_haves=nice_to_haves[:5]   # Limit to 5
            )
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract matching criteria: {str(e)}")
            return MatchingCriteria(
                skill_weights={},
                experience_weight=0.3,
                education_weight=0.1,
                location_weight=0.1,
                minimum_match_threshold=0.65,
                deal_breakers=[],
                nice_to_haves=[]
            )
    
    def _extract_responsibilities_from_text(self, analysis_text: str, job_description: str) -> List[str]:
        """Extract job responsibilities from text."""
        try:
            responsibilities = []
            jd_lines = job_description.lower().split('\n')
            
            # Find responsibility sections
            in_responsibilities = False
            for line in jd_lines:
                line = line.strip()
                if any(keyword in line for keyword in ['responsibility', 'responsibilities', 'duties', 'role', 'what you']):
                    in_responsibilities = True
                    continue
                elif any(keyword in line for keyword in ['requirement', 'qualification', 'benefit', 'about us']):
                    in_responsibilities = False
                    continue
                    
                if in_responsibilities and line and len(line) > 10:
                    # Clean up bullet points
                    cleaned = re.sub(r'^[•\-\*\d+\.\)]\s*', '', line)
                    if cleaned and len(cleaned) > 5:
                        responsibilities.append(cleaned.capitalize())
            
            # Extract database-specific responsibilities if it's a DBA role
            jd_lower = job_description.lower()
            if 'database' in jd_lower or 'dba' in jd_lower:
                if 'mysql' in jd_lower:
                    responsibilities.append('Manage and optimize MySQL database systems')
                if 'azure' in jd_lower:
                    responsibilities.append('Administer Azure database services')
                if 'backup' in jd_lower:
                    responsibilities.append('Implement database backup and recovery procedures')
                if 'performance' in jd_lower:
                    responsibilities.append('Monitor and tune database performance')
            
            # Fallback responsibilities if none found
            if not responsibilities:
                responsibilities = [
                    "Execute key job functions as defined in job description",
                    "Collaborate with team members and stakeholders",
                    "Contribute to project goals and objectives"
                ]
            
            return responsibilities[:8]  # Limit to 8 responsibilities
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract responsibilities: {str(e)}")
            return ["Execute assigned duties and responsibilities"]
    
    def _extract_company_culture_from_text(self, analysis_text: str, job_description: str) -> List[str]:
        """Extract company culture keywords from text."""
        try:
            culture = []
            jd_lower = job_description.lower()
            
            # Culture keywords to look for
            culture_keywords = {
                'innovative': ['innovative', 'innovation', 'cutting-edge', 'modern'],
                'collaborative': ['collaborative', 'teamwork', 'team', 'together'],
                'fast-paced': ['fast-paced', 'dynamic', 'agile', 'rapid'],
                'growth-oriented': ['growth', 'learning', 'development', 'career'],
                'inclusive': ['inclusive', 'diversity', 'diverse', 'inclusive'],
                'customer-focused': ['customer', 'client', 'user-focused', 'customer-centric'],
                'technology-driven': ['technology', 'tech', 'digital', 'data-driven'],
                'entrepreneurial': ['startup', 'entrepreneurial', 'innovative', 'ownership']
            }
            
            for culture_trait, keywords in culture_keywords.items():
                if any(keyword in jd_lower for keyword in keywords):
                    culture.append(culture_trait)
            
            # Default culture if none found
            if not culture:
                culture = ["professional", "collaborative", "results-oriented"]
            
            return culture[:5]  # Limit to 5 culture traits
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract company culture: {str(e)}")
            return ["professional", "collaborative"]
    
    def _extract_growth_opportunities_from_text(self, analysis_text: str, job_description: str) -> List[str]:
        """Extract growth opportunities from text."""
        try:
            opportunities = []
            jd_lower = job_description.lower()
            
            # Growth opportunity keywords
            if any(word in jd_lower for word in ['career', 'advancement', 'promotion', 'grow']):
                opportunities.append('career advancement')
            if any(word in jd_lower for word in ['training', 'learning', 'development', 'skill']):
                opportunities.append('skill development')
            if any(word in jd_lower for word in ['mentor', 'coaching', 'guidance']):
                opportunities.append('mentorship programs')
            if any(word in jd_lower for word in ['conference', 'certification', 'education']):
                opportunities.append('professional development')
            if any(word in jd_lower for word in ['leadership', 'lead', 'management']):
                opportunities.append('leadership opportunities')
            if any(word in jd_lower for word in ['project', 'ownership', 'responsibility']):
                opportunities.append('project ownership')
            
            # Default opportunities if none found
            if not opportunities:
                opportunities = ["professional growth", "skill enhancement", "career development"]
            
            return opportunities[:5]  # Limit to 5 opportunities
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to extract growth opportunities: {str(e)}")
            return ["professional development"]
    
    async def shutdown(self):
        """Shutdown the job description analysis agent and cleanup resources."""
        try:
            logger.info("🔄 Shutting down Job Description Analysis Agent")
            
            # Clear instructor client if exists
            self.instructor_client = None
            
            self._initialized = False
            logger.info("✅ Job Description Analysis Agent shutdown completed")
            
        except Exception as e:
            logger.error(f"❌ Error during Job Description Analysis Agent shutdown: {str(e)}")
            raise
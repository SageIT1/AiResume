"""
Quality assessment agents for AI Recruit.
"""

from .quality_assessment_agent import QualityAssessmentAgent

__all__ = ["QualityAssessmentAgent"]
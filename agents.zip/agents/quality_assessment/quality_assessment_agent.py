"""
Quality Assessment Agent for AI Recruit - Agentic AI Quality Evaluation
AI-powered quality evaluation without manual rules.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
from typing import Dict, List, Any, Optional
from uuid import UUID
import time
import asyncio

logger = logging.getLogger(__name__)


class QualityAssessmentAgent:
    """
    AI-powered quality evaluation agent for resumes and job matches.
    
    This agent:
    - LLM-based completeness assessment
    - Intelligent relevance scoring
    - Dynamic quality criteria adaptation
    - NO manual scoring rules or thresholds
    """
    
    def __init__(self, llm=None, settings=None):
        """
        Initialize the Quality Assessment Agent.
        
        Args:
            llm: Language model for quality evaluation
            settings: Application settings
        """
        self.llm = llm
        self.settings = settings
        self.agent_id = "quality_assessment_agent"
        self.initialized = False
        
        # Agent configuration
        self.config = {
            "temperature": 0.1,  # Low temperature for consistent assessment
            "max_tokens": 1024,
            "model_name": "gpt-4.1"
        }
        
        logger.info(f"QualityAssessmentAgent initialized with ID: {self.agent_id}")
    
    async def initialize(self) -> None:
        """Initialize the quality assessment agent."""
        if self.initialized:
            return
        
        logger.info("Initializing Quality Assessment Agent...")
        
        # TODO: Initialize LLM when available
        logger.info("Quality assessment agent initialized (mock mode)")
        
        self.initialized = True
        logger.info("✅ Quality Assessment Agent ready for intelligent evaluation")
    
    def _remove_extracted_text_recursive(self, data):
        """Recursively remove extracted_text from any nested data structure."""
        if isinstance(data, dict):
            filtered = {}
            for key, value in data.items():
                if key != "extracted_text":
                    filtered[key] = self._remove_extracted_text_recursive(value)
            return filtered
        elif isinstance(data, list):
            return [self._remove_extracted_text_recursive(item) for item in data]
        else:
            return data
    
    async def assess_resume_quality(self, resume_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Assess the quality of a resume using AI evaluation.
        
        Args:
            resume_data: Resume information to assess (MUST NOT contain extracted_text)
            
        Returns:
            Quality assessment with scores and recommendations
        """
        try:
            # CRITICAL: Verify no extracted_text is present
            resume_str = str(resume_data)
            if "extracted_text" in resume_str:
                logger.error("❌ CRITICAL ERROR: extracted_text detected in quality assessment input!")
                logger.error("❌ This will cause rate limiting - removing extracted_text immediately!")
                # Remove extracted_text recursively
                resume_data = self._remove_extracted_text_recursive(resume_data)
                logger.info("✅ extracted_text removed from quality assessment input")
            
            logger.info("Starting AI-powered resume quality assessment")
            
            if self.llm:
                # Use actual LLM-based quality assessment
                return await self._ai_quality_assessment(resume_data)
            else:
                logger.warning("Using mock quality assessment - LLM not available")
                return await self._mock_quality_assessment(resume_data)
                
        except Exception as e:
            logger.error(f"❌ Quality assessment failed: {str(e)}")
            # Return basic assessment as fallback
            return {
                "overall_score": 0.5,
                "quality_scores": {"completeness": 0.5, "relevance": 0.5, "presentation": 0.5, "achievements": 0.5},
                "grade": "C",
                "recommendations": ["Unable to perform detailed assessment"],
                "strengths": [],
                "improvement_areas": ["Technical assessment error"]
            }
    
    async def _ai_quality_assessment(self, resume_data: Dict[str, Any]) -> Dict[str, Any]:
        """Perform AI-powered quality assessment using LLM with rate limiting."""
        max_retries = 3
        base_delay = 5  # Start with 5 seconds delay
        
        for attempt in range(max_retries):
            try:
                # Create concise prompt for quality assessment (optimized for token usage)
                personal_info = resume_data.get("personal_info", {})
                career_analysis = resume_data.get("career_analysis", {})
                skills_analysis = resume_data.get("skills_analysis", {})
                education_analysis = resume_data.get("education_analysis", {})
                
                # Extract key information for assessment
                candidate_name = personal_info.get("full_name", "Unknown")
                total_experience = career_analysis.get("total_years_experience", 0)
                current_position = career_analysis.get("current_position", "Not specified")
                skills_count = len(skills_analysis.get("technical_skills", [])) + len(skills_analysis.get("soft_skills", []))
                education_count = len(education_analysis.get("education", []))
                summary = resume_data.get("summary","Not specified")
                skill_analysis = resume_data.get("skill_analysis","Not specified")
                assessment_prompt = f"""
                You are a resume quality assessment expert. Analyze the following resume data and provide a comprehensive quality assessment.

                Resume Data:
                - Candidate: {candidate_name}
                - Email: {personal_info.get("email", "Not specified")}
                - Phone: {personal_info.get("phone", "Not specified")}
                - Experience: {total_experience} years as {current_position}
                - Skills: {skills_count} total skills identified
                - Education: {education_count} education entries
                - Summary: {summary}
                - Skill Analysis: {skill_analysis}

                IMPORTANT: 
                1. You must respond with ONLY valid JSON. No additional text, explanations, or formatting outside the JSON.
                2. DO NOT use example values like 0.85, 0.90, 0.80. Analyze the ACTUAL resume content and provide real scores.
                3. Base your scores on the specific data provided above, not on generic examples.

                Evaluate each dimension (0.0-1.0) based on these criteria:

                1. CONTENT QUALITY (40% weight):
                   - Skills Depth: Score 0.9+ if skills are well-categorized and detailed, 0.5-0.8 if basic, 0.0-0.4 if minimal
                   - Experience Detail: Score 0.9+ if job descriptions are specific with 3+ responsibilities each, 0.5-0.8 if basic, 0.0-0.4 if vague
                   - Achievement Quantification: Score 0.9+ if many quantified achievements (numbers, %), 0.5-0.8 if some, 0.0-0.4 if none
                   - Professional Summary: Score 0.9+ if compelling 100+ char summary, 0.5-0.8 if adequate, 0.0-0.4 if missing/poor

                2. PROFESSIONAL IMPACT (30% weight):
                   - Career Progression: Score 0.9+ if clear advancement over 3+ roles, 0.5-0.8 if some progression, 0.0-0.4 if flat
                   - Leadership Evidence: Score 0.9+ if multiple leadership keywords, 0.5-0.8 if some, 0.0-0.4 if none
                   - Industry Relevance: Score 0.9+ if 10+ relevant technical skills, 0.5-0.8 if 5-9, 0.0-0.4 if <5
                   - Value Proposition: Score 0.9+ if strong value keywords in summary, 0.5-0.8 if basic, 0.0-0.4 if weak

                3. TECHNICAL COMPLETENESS (20% weight):
                   - Contact Information: Score 1.0 if email+phone, 0.5 if one, 0.0 if neither
                   - Education Credentials: Score 0.9+ if 2+ education entries, 0.5-0.8 if 1, 0.0-0.4 if none
                   - Technical Skills: Score 0.9+ if 8+ technical skills, 0.5-0.8 if 4-7, 0.0-0.4 if <4
                   - Portfolio/Projects: Score 0.9+ if multiple project keywords, 0.5-0.8 if some, 0.0-0.4 if none

                Respond with this exact JSON format (replace the values with your actual assessment):
                {{
                    "content_quality": [score between 0.0-1.0 based on skills depth, experience detail, achievements, and summary quality],
                    "professional_impact": [score between 0.0-1.0 based on career progression, leadership, industry relevance, and value proposition],
                    "technical_completeness": [score between 0.0-1.0 based on contact info, education, technical skills, and projects],
                    "overall_reasoning": "[Your detailed assessment reasoning based on the actual resume content]",
                    "recommendations": ["[Specific improvement 1 based on actual gaps]", "[Specific improvement 2 based on actual gaps]"],
                    "strengths": ["[Actual strength 1 from the resume]", "[Actual strength 2 from the resume]"],
                    "improvement_areas": ["[Actual area 1 that needs improvement]", "[Actual area 2 that needs improvement]"]
                }}

                Remember: Respond with ONLY the JSON object, no other text.
                """
                
                # Add delay before each attempt to avoid rate limiting
                if attempt > 0:
                    delay = base_delay * (2 ** attempt)  # Exponential backoff
                    logger.info(f"⏳ Waiting {delay} seconds before retry attempt {attempt + 1}")
                    await asyncio.sleep(delay)
                
                # Get LLM response
                response = await self.llm.ainvoke(assessment_prompt)
                logger.info(f"🔍 Raw LLM response: {response}")
                
                # Parse response with improved error handling
                import json
                import re
                
                ai_assessment = None
                response_text = ""
                
                # Extract text from response (handle different response formats)
                if hasattr(response, 'content'):
                    response_text = response.content
                elif isinstance(response, str):
                    response_text = response
                elif hasattr(response, 'text'):
                    response_text = response.text
                else:
                    response_text = str(response)
                
                logger.info(f"📝 Extracted response text: {response_text[:500]}...")
                
                try:
                    # Try direct JSON parsing first
                    ai_assessment = json.loads(response_text)
                    logger.info("✅ Successfully parsed JSON response")
                except json.JSONDecodeError as json_error:
                    logger.warning(f"⚠️ Direct JSON parsing failed: {json_error}")
                    
                    # Try to extract JSON from the response using regex
                    json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                    if json_match:
                        try:
                            json_text = json_match.group(0)
                            logger.info(f"🔍 Extracted JSON text: {json_text[:200]}...")
                            ai_assessment = json.loads(json_text)
                            logger.info("✅ Successfully parsed extracted JSON")
                        except json.JSONDecodeError as extract_error:
                            logger.warning(f"⚠️ Extracted JSON parsing failed: {extract_error}")
                    
                    # If still no success, try to parse individual fields
                    # if ai_assessment is None:
                    #     logger.warning("⚠️ Attempting to parse individual fields from response")
                    #     ai_assessment = self._parse_quality_response_manually(response_text)
                
                # Final fallback if all parsing attempts fail
                if ai_assessment is None:
                    logger.error("❌ All JSON parsing attempts failed, using fallback")
                    ai_assessment = {
                        "completeness": 0.0,
                        "relevance": 0.0,
                        "presentation": 0.0,
                        "achievements": 0.0,
                        "overall_reasoning": "Not available",
                        "recommendations": ["Not available"],
                        "strengths": ["Not available"],
                        "improvement_areas": ["Not available"]
                    }
                
                # Calculate overall score with new weighted parameters
                quality_scores = {
                    "content_quality": ai_assessment.get("content_quality", 0.0),
                    "professional_impact": ai_assessment.get("professional_impact", 0.0),
                    "technical_completeness": ai_assessment.get("technical_completeness", 0.0)
                }
                
                # Apply weights: Content Quality (40%), Professional Impact (30%), Technical Completeness (20%)
                # Note: We're missing 10% - this could be for presentation/formatting if needed
                overall_score = (
                    quality_scores["content_quality"] * 0.40 +
                    quality_scores["professional_impact"] * 0.30 +
                    quality_scores["technical_completeness"] * 0.20
                ) / 0.90  # Normalize by the sum of weights (0.90)
                
                assessment = {
                    "overall_score": overall_score,
                    "quality_scores": quality_scores,
                    "grade": self._calculate_grade(overall_score),
                    "recommendations": ai_assessment.get("recommendations", []),
                    "strengths": ai_assessment.get("strengths", []),
                    "improvement_areas": ai_assessment.get("improvement_areas", []),
                    "ai_reasoning": ai_assessment.get("overall_reasoning", "")
                }
                
                logger.info(f"Quality assessment completed: {overall_score:.2f}/1.0")
                return assessment
                
            except Exception as e:
                error_str = str(e)
                if "429" in error_str or "rate limit" in error_str.lower():
                    logger.warning(f"⚠️ Rate limit hit on attempt {attempt + 1}: {error_str}")
                    if attempt < max_retries - 1:
                        continue  # Try again with exponential backoff
                    else:
                        logger.error(f"❌ Max retries reached for quality assessment, using fallback")
                        return await self._mock_quality_assessment(resume_data)
                else:
                    logger.error(f"❌ AI quality assessment failed: {error_str}")
                    return await self._mock_quality_assessment(resume_data)
        
        # If we get here, all retries failed
        logger.error(f"❌ All retry attempts failed for quality assessment, using fallback")
        return await self._mock_quality_assessment(resume_data)
    
    def _parse_quality_response_manually(self, response_text: str) -> Dict[str, Any]:
        """Manually parse quality assessment response when JSON parsing fails."""
        import re
        
        logger.info("🔧 Attempting manual parsing of quality response")
        
        # Initialize with default values
        assessment = {
            "content_quality": 0.7,
            "professional_impact": 0.7,
            "technical_completeness": 0.7,
            "overall_reasoning": "Manual parsing completed",
            "recommendations": ["Continue improving resume content"],
            "strengths": ["Good overall structure"],
            "improvement_areas": ["Enhance quantified achievements"]
        }
        
        try:
            # Try to extract numeric scores using regex patterns
            score_patterns = {
                "content_quality": r'content_quality["\']?\s*[:=]\s*([0-9.]+)',
                "professional_impact": r'professional_impact["\']?\s*[:=]\s*([0-9.]+)',
                "technical_completeness": r'technical_completeness["\']?\s*[:=]\s*([0-9.]+)'
            }
            
            for key, pattern in score_patterns.items():
                match = re.search(pattern, response_text, re.IGNORECASE)
                if match:
                    try:
                        score = float(match.group(1))
                        # Ensure score is between 0 and 1
                        if 0 <= score <= 1:
                            assessment[key] = score
                            logger.info(f"✅ Extracted {key}: {score}")
                        elif 0 <= score <= 100:
                            # Convert percentage to decimal
                            assessment[key] = score / 100
                            logger.info(f"✅ Extracted {key}: {score}% -> {score/100}")
                    except ValueError:
                        logger.warning(f"⚠️ Could not convert {key} score to float")
            
            # Try to extract text fields
            text_patterns = {
                "overall_reasoning": r'overall_reasoning["\']?\s*[:=]\s*["\']([^"\']+)["\']',
                "recommendations": r'recommendations["\']?\s*[:=]\s*\[([^\]]+)\]',
                "strengths": r'strengths["\']?\s*[:=]\s*\[([^\]]+)\]',
                "improvement_areas": r'improvement_areas["\']?\s*[:=]\s*\[([^\]]+)\]'
            }
            
            for key, pattern in text_patterns.items():
                match = re.search(pattern, response_text, re.IGNORECASE | re.DOTALL)
                if match:
                    text_content = match.group(1).strip()
                    if key in ["recommendations", "strengths", "improvement_areas"]:
                        # Parse array-like content
                        items = [item.strip().strip('"\'') for item in text_content.split(',')]
                        assessment[key] = [item for item in items if item]
                    else:
                        assessment[key] = text_content
                    logger.info(f"✅ Extracted {key}: {text_content[:100]}...")
            
            logger.info("✅ Manual parsing completed successfully")
            return assessment
            
        except Exception as e:
            logger.error(f"❌ Manual parsing failed: {e}")
            return assessment
    
    async def _mock_quality_assessment(self, resume_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback mock quality assessment."""
        # Mock quality scoring with new parameters
        quality_scores = {
            "content_quality": self._assess_content_quality(resume_data),
            "professional_impact": self._assess_professional_impact(resume_data),
            "technical_completeness": self._assess_technical_completeness(resume_data)
        }
        
        # Calculate overall score with weights
        overall_score = (
            quality_scores["content_quality"] * 0.40 +
            quality_scores["professional_impact"] * 0.30 +
            quality_scores["technical_completeness"] * 0.20
        ) / 0.90  # Normalize by the sum of weights (0.90)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(quality_scores)
        
        assessment = {
            "overall_score": overall_score,
            "quality_scores": quality_scores,
            "grade": self._calculate_grade(overall_score),
            "recommendations": recommendations,
            "strengths": self._identify_strengths(quality_scores),
            "improvement_areas": self._identify_improvements(quality_scores)
        }
        
        logger.info(f"Quality assessment completed: {overall_score:.2f}/1.0")
        return assessment
    
    def _assess_content_quality(self, resume_data: Dict[str, Any]) -> float:
        """Assess content quality: skills depth, experience detail, achievement quantification, professional summary."""
        try:
            score = 0.0
            factors = 0
            
            # Skills depth assessment
            skills_analysis = resume_data.get("skills_analysis", {})
            technical_skills = skills_analysis.get("technical_skills", [])
            soft_skills = skills_analysis.get("soft_skills", [])
            
            if technical_skills or soft_skills:
                # Check if skills are well-categorized and described
                skill_depth_score = min(1.0, (len(technical_skills) + len(soft_skills)) / 20)  # Normalize to 20 skills max
                score += skill_depth_score
                factors += 1
            
            # Experience detail assessment
            career_analysis = resume_data.get("career_analysis", {})
            work_experience = career_analysis.get("work_experience", [])
            
            if work_experience:
                # Check for detailed job descriptions
                detailed_jobs = sum(1 for job in work_experience if len(job.get("responsibilities", [])) > 2)
                experience_detail_score = min(1.0, detailed_jobs / len(work_experience)) if work_experience else 0
                score += experience_detail_score
                factors += 1
            
            # Achievement quantification assessment
            achievement_score = 0.0
            for job in work_experience:
                responsibilities = job.get("responsibilities", [])
                achievements = job.get("achievements", [])
                # Look for quantified achievements (numbers, percentages, etc.)
                quantified_count = sum(1 for ach in achievements if any(char.isdigit() for char in str(ach)))
                if achievements:
                    achievement_score += min(1.0, quantified_count / len(achievements))
            
            if work_experience:
                achievement_score = achievement_score / len(work_experience)
                score += achievement_score
                factors += 1
            
            # Professional summary assessment
            summary = resume_data.get("summary", "")
            if summary and len(summary.strip()) > 50:  # Meaningful summary
                summary_score = min(1.0, len(summary) / 200)  # Normalize to 200 chars
                score += summary_score
                factors += 1
            
            return score / factors if factors > 0 else 0.5
            
        except Exception as e:
            logger.error(f"Error assessing content quality: {e}")
            return 0.5
    
    def _assess_professional_impact(self, resume_data: Dict[str, Any]) -> float:
        """Assess professional impact: career progression, leadership evidence, industry relevance, value proposition."""
        try:
            score = 0.0
            factors = 0
            
            # Career progression assessment
            career_analysis = resume_data.get("career_analysis", {})
            work_experience = career_analysis.get("work_experience", [])
            
            if len(work_experience) > 1:
                # Check for career progression (increasing responsibilities, titles)
                progression_score = min(1.0, len(work_experience) / 5)  # Normalize to 5 jobs max
                score += progression_score
                factors += 1
            
            # Leadership evidence assessment
            leadership_score = 0.0
            for job in work_experience:
                responsibilities = job.get("responsibilities", [])
                # Look for leadership keywords
                leadership_keywords = ["manage", "lead", "team", "supervise", "direct", "mentor", "guide"]
                leadership_count = sum(1 for resp in responsibilities 
                                    if any(keyword in resp.lower() for keyword in leadership_keywords))
                if responsibilities:
                    leadership_score += min(1.0, leadership_count / len(responsibilities))
            
            if work_experience:
                leadership_score = leadership_score / len(work_experience)
                score += leadership_score
                factors += 1
            
            # Industry relevance (basic assessment)
            skills_analysis = resume_data.get("skills_analysis", {})
            technical_skills = skills_analysis.get("technical_skills", [])
            # More technical skills generally indicate better industry relevance
            relevance_score = min(1.0, len(technical_skills) / 15)  # Normalize to 15 skills max
            score += relevance_score
            factors += 1
            
            # Value proposition (assess summary quality)
            summary = resume_data.get("summary", "")
            if summary and len(summary.strip()) > 30:
                # Check for value proposition indicators
                value_keywords = ["expertise", "experience", "proven", "successful", "achieved", "delivered"]
                value_count = sum(1 for keyword in value_keywords if keyword.lower() in summary.lower())
                value_score = min(1.0, value_count / 3)  # Normalize to 3 keywords max
                score += value_score
                factors += 1
            
            return score / factors if factors > 0 else 0.5
            
        except Exception as e:
            logger.error(f"Error assessing professional impact: {e}")
            return 0.5
    
    def _assess_technical_completeness(self, resume_data: Dict[str, Any]) -> float:
        """Assess technical completeness: contact info, education credentials, technical skills, portfolio/projects."""
        try:
            score = 0.0
            factors = 0
            
            # Contact information assessment
            personal_info = resume_data.get("personal_info", {})
            contact_score = 0.0
            if personal_info.get("email"): contact_score += 0.5
            if personal_info.get("phone"): contact_score += 0.5
            score += contact_score
            factors += 1
            
            # Education credentials assessment
            education_analysis = resume_data.get("education_analysis", {})
            education = education_analysis.get("education", [])
            education_score = min(1.0, len(education) / 3)  # Normalize to 3 education entries max
            score += education_score
            factors += 1
            
            # Technical skills assessment
            skills_analysis = resume_data.get("skills_analysis", {})
            technical_skills = skills_analysis.get("technical_skills", [])
            tech_skills_score = min(1.0, len(technical_skills) / 10)  # Normalize to 10 skills max
            score += tech_skills_score
            factors += 1
            
            # Portfolio/Projects assessment (basic check for project mentions)
            career_analysis = resume_data.get("career_analysis", {})
            work_experience = career_analysis.get("work_experience", [])
            project_score = 0.0
            for job in work_experience:
                responsibilities = job.get("responsibilities", [])
                # Look for project-related keywords
                project_keywords = ["project", "develop", "build", "create", "implement", "design"]
                project_count = sum(1 for resp in responsibilities 
                                 if any(keyword in resp.lower() for keyword in project_keywords))
                if responsibilities:
                    project_score += min(1.0, project_count / len(responsibilities))
            
            if work_experience:
                project_score = project_score / len(work_experience)
                score += project_score
                factors += 1
            
            return score / factors if factors > 0 else 0.5
            
        except Exception as e:
            logger.error(f"Error assessing technical completeness: {e}")
            return 0.5
    
    def _assess_completeness(self, resume_data: Dict[str, Any]) -> float:
        """Assess completeness of resume information."""
        try:
            # Check if this is chunked analysis data
            if resume_data.get("chunked_analysis"):
                return self._assess_chunked_completeness(resume_data)
            
            # Check for nested structure from resume analysis
            personal_info = resume_data.get("personal_info", {})
            skills_analysis = resume_data.get("skills_analysis", {})
            experience = resume_data.get("experience", {})
            education = resume_data.get("education", {})
            
            # Count present fields
            present_fields = 0
            total_fields = 6
            
            # Personal info fields
            if personal_info.get("full_name"):
                present_fields += 1
            if personal_info.get("email"):
                present_fields += 1
            if personal_info.get("phone"):
                present_fields += 1
            
            # Skills
            if skills_analysis and any(skills_analysis.get(category, []) for category in 
                ["programming_languages", "frameworks_libraries", "tools_technologies", "technical_skills", "soft_skills"]):
                present_fields += 1
            
            # Experience
            if experience and experience.get("work_experience"):
                present_fields += 1
            
            # Education
            if education and education.get("education"):
                present_fields += 1
            
            return present_fields / total_fields
        except Exception as e:
            logger.error(f"Error in completeness assessment: {e}")
            return 0.0
    
    def _assess_chunked_completeness(self, resume_data: Dict[str, Any]) -> float:
        """Assess completeness for chunked analysis data."""
        try:
            present_fields = 0
            total_fields = 6
            
            # Personal info fields
            personal_info = resume_data.get("personal_info", {})
            if personal_info.get("name"):
                present_fields += 1
            if personal_info.get("email"):
                present_fields += 1
            if personal_info.get("phone"):
                present_fields += 1
            
            # Skills
            skills = resume_data.get("skills", {})
            if skills and (skills.get("technical") or skills.get("soft")):
                present_fields += 1
            
            # Work experience
            if resume_data.get("work_experience"):
                present_fields += 1
            
            # Education
            if resume_data.get("education"):
                present_fields += 1
            
            # Check chunk metadata for additional context
            chunk_metadata = resume_data.get("chunk_metadata", {})
            successful_chunks = chunk_metadata.get("successful_chunks", 0)
            total_chunks = chunk_metadata.get("total_chunks", 0)
            
            # If we have successful chunks, give some credit
            if successful_chunks > 0:
                present_fields += 0.5  # Partial credit for having processed chunks
            
            return min(1.0, present_fields / total_fields)
        except Exception as e:
            logger.error(f"Error in chunked completeness assessment: {e}")
            return 0.0
    
    def _assess_relevance(self, resume_data: Dict[str, Any]) -> float:
        """Assess relevance of resume content."""
        try:
            # Check if this is chunked analysis data
            if resume_data.get("chunked_analysis"):
                return self._assess_chunked_relevance(resume_data)
            
            # Check for nested structure from resume analysis
            skills_analysis = resume_data.get("skills_analysis", {})
            experience = resume_data.get("experience", {})
            
            # Count skills across all categories
            total_skills = 0
            for category in ["programming_languages", "frameworks_libraries", "tools_technologies", "technical_skills", "soft_skills"]:
                skills_list = skills_analysis.get(category, [])
                if isinstance(skills_list, list):
                    total_skills += len(skills_list)
            
            # Count work experiences
            work_experience = experience.get("work_experience", [])
            experience_count = len(work_experience) if isinstance(work_experience, list) else 0
            
            # Calculate relevance based on content richness
            if total_skills >= 10 and experience_count >= 3:
                return 0.9  # Excellent relevance
            elif total_skills >= 5 and experience_count >= 2:
                return 0.7  # Good relevance
            elif total_skills >= 3 or experience_count >= 1:
                return 0.5  # Moderate relevance
            else:
                return 0.2  # Low relevance
        except Exception as e:
            logger.error(f"Error in relevance assessment: {e}")
            return 0.0
    
    def _assess_chunked_relevance(self, resume_data: Dict[str, Any]) -> float:
        """Assess relevance for chunked analysis data."""
        try:
            # Count skills
            skills = resume_data.get("skills", {})
            technical_skills = skills.get("technical", [])
            soft_skills = skills.get("soft", [])
            total_skills = len(technical_skills) + len(soft_skills)
            
            # Count work experiences
            work_experience = resume_data.get("work_experience", [])
            experience_count = len(work_experience) if isinstance(work_experience, list) else 0
            
            # Count education
            education = resume_data.get("education", [])
            education_count = len(education) if isinstance(education, list) else 0
            
            # Count projects
            projects = resume_data.get("projects", [])
            project_count = len(projects) if isinstance(projects, list) else 0
            
            # Calculate relevance based on content richness
            content_score = 0
            
            # Skills contribution (40% of score)
            if total_skills >= 15:
                content_score += 0.4
            elif total_skills >= 10:
                content_score += 0.3
            elif total_skills >= 5:
                content_score += 0.2
            elif total_skills >= 1:
                content_score += 0.1
            
            # Experience contribution (30% of score)
            if experience_count >= 5:
                content_score += 0.3
            elif experience_count >= 3:
                content_score += 0.25
            elif experience_count >= 2:
                content_score += 0.2
            elif experience_count >= 1:
                content_score += 0.1
            
            # Education contribution (20% of score)
            if education_count >= 2:
                content_score += 0.2
            elif education_count >= 1:
                content_score += 0.15
            
            # Projects contribution (10% of score)
            if project_count >= 3:
                content_score += 0.1
            elif project_count >= 1:
                content_score += 0.05
            
            # Check chunk processing success
            chunk_metadata = resume_data.get("chunk_metadata", {})
            successful_chunks = chunk_metadata.get("successful_chunks", 0)
            total_chunks = chunk_metadata.get("total_chunks", 0)
            
            # If most chunks were processed successfully, give bonus
            if total_chunks > 0 and successful_chunks / total_chunks >= 0.8:
                content_score += 0.1  # 10% bonus for successful chunk processing
            
            return min(1.0, content_score)
        except Exception as e:
            logger.error(f"Error in chunked relevance assessment: {e}")
            return 0.5
    
    def _assess_presentation(self, resume_data: Dict[str, Any]) -> float:
        """Assess presentation quality of resume."""
        try:
            # Check if this is chunked analysis data
            if resume_data.get("chunked_analysis"):
                return self._assess_chunked_presentation(resume_data)
            
            # Check for nested structure from resume analysis
            personal_info = resume_data.get("personal_info", {})
            experience = resume_data.get("experience", {})
            education = resume_data.get("education", {})
            quality = resume_data.get("quality", {})
            
            # Check for professional summary
            has_summary = bool(resume_data.get("professional_summary")) or bool(quality.get("professional_summary"))
            
            # Check for structured experience
            work_experience = experience.get("work_experience", [])
            has_structured_experience = isinstance(work_experience, list) and len(work_experience) > 0
            
            # Check for structured education
            education_list = education.get("education", [])
            has_structured_education = isinstance(education_list, list) and len(education_list) > 0
            
            # Check for contact information completeness
            has_contact_info = bool(personal_info.get("email")) and bool(personal_info.get("phone"))
            
            # Calculate presentation score
            presentation_factors = [has_summary, has_structured_experience, has_structured_education, has_contact_info]
            presentation_score = sum(presentation_factors) / len(presentation_factors)
            
            return presentation_score
        except Exception as e:
            logger.error(f"Error in presentation assessment: {e}")
            return 0.0
    
    def _assess_chunked_presentation(self, resume_data: Dict[str, Any]) -> float:
        """Assess presentation quality for chunked analysis data."""
        try:
            # Check for personal info completeness
            personal_info = resume_data.get("personal_info", {})
            has_contact_info = bool(personal_info.get("email")) and bool(personal_info.get("phone"))
            
            # Check for structured work experience
            work_experience = resume_data.get("work_experience", [])
            has_structured_experience = isinstance(work_experience, list) and len(work_experience) > 0
            
            # Check for structured education
            education = resume_data.get("education", [])
            has_structured_education = isinstance(education, list) and len(education) > 0
            
            # Check for projects
            projects = resume_data.get("projects", [])
            has_projects = isinstance(projects, list) and len(projects) > 0
            
            # Check chunk processing success
            chunk_metadata = resume_data.get("chunk_metadata", {})
            successful_chunks = chunk_metadata.get("successful_chunks", 0)
            total_chunks = chunk_metadata.get("total_chunks", 0)
            has_good_chunk_processing = total_chunks > 0 and successful_chunks / total_chunks >= 0.7
            
            # Calculate presentation score
            presentation_factors = [
                has_contact_info,
                has_structured_experience,
                has_structured_education,
                has_projects,
                has_good_chunk_processing
            ]
            presentation_score = sum(presentation_factors) / len(presentation_factors)
            
            return presentation_score
        except Exception as e:
            logger.error(f"Error in chunked presentation assessment: {e}")
            return 0.5
    
    def _assess_achievements(self, resume_data: Dict[str, Any]) -> float:
        """Assess achievement content in resume."""
        try:
            # Check if this is chunked analysis data
            if resume_data.get("chunked_analysis"):
                return self._assess_chunked_achievements(resume_data)
            
            # Check for nested structure from resume analysis
            experience = resume_data.get("experience", {})
            work_experience = experience.get("work_experience", [])
            
            if not work_experience or not isinstance(work_experience, list):
                return 0.0
            
            # Count experiences with achievements or detailed descriptions
            experiences_with_achievements = 0
            total_experiences = len(work_experience)
            
            for exp in work_experience:
                if isinstance(exp, dict):
                    # Check for achievements, responsibilities, or detailed descriptions
                    has_achievements = bool(exp.get("achievements")) and len(exp.get("achievements", [])) > 0
                    has_responsibilities = bool(exp.get("responsibilities")) and len(exp.get("responsibilities", [])) > 0
                    has_detailed_description = bool(exp.get("description")) and len(exp.get("description", "")) > 50
                    
                    if has_achievements or has_responsibilities or has_detailed_description:
                        experiences_with_achievements += 1
            
            # Calculate achievement score based on percentage of experiences with details
            if total_experiences == 0:
                return 0.0
            
            achievement_ratio = experiences_with_achievements / total_experiences
            
            if achievement_ratio >= 0.8:
                return 0.9  # Excellent achievements
            elif achievement_ratio >= 0.6:
                return 0.7  # Good achievements
            elif achievement_ratio >= 0.4:
                return 0.5  # Moderate achievements
            else:
                return 0.2  # Poor achievements
        except Exception as e:
            logger.error(f"Error in achievements assessment: {e}")
            return 0.0
    
    def _assess_chunked_achievements(self, resume_data: Dict[str, Any]) -> float:
        """Assess achievement content for chunked analysis data."""
        try:
            # Check work experience for achievements
            work_experience = resume_data.get("work_experience", [])
            if not work_experience or not isinstance(work_experience, list):
                return 0.0
            
            # Count experiences with achievements or detailed descriptions
            experiences_with_achievements = 0
            total_experiences = len(work_experience)
            
            for exp in work_experience:
                if isinstance(exp, dict):
                    # Check for achievements, responsibilities, or detailed descriptions
                    has_achievements = bool(exp.get("achievements")) and len(exp.get("achievements", [])) > 0
                    has_responsibilities = bool(exp.get("responsibilities")) and len(exp.get("responsibilities", [])) > 0
                    has_detailed_description = bool(exp.get("description")) and len(exp.get("description", "")) > 50
                    
                    if has_achievements or has_responsibilities or has_detailed_description:
                        experiences_with_achievements += 1
            
            # Check projects for achievements
            projects = resume_data.get("projects", [])
            projects_with_details = 0
            total_projects = len(projects) if isinstance(projects, list) else 0
            
            for project in projects:
                if isinstance(project, dict):
                    has_description = bool(project.get("description")) and len(project.get("description", "")) > 30
                    has_technologies = bool(project.get("technologies")) and len(project.get("technologies", [])) > 0
                    
                    if has_description or has_technologies:
                        projects_with_details += 1
            
            # Calculate achievement score
            if total_experiences == 0 and total_projects == 0:
                return 0.0
            
            # Weighted score: 70% work experience, 30% projects
            experience_ratio = experiences_with_achievements / total_experiences if total_experiences > 0 else 0
            project_ratio = projects_with_details / total_projects if total_projects > 0 else 0
            
            achievement_score = (experience_ratio * 0.7) + (project_ratio * 0.3)
            
            # Check chunk processing success for bonus
            chunk_metadata = resume_data.get("chunk_metadata", {})
            successful_chunks = chunk_metadata.get("successful_chunks", 0)
            total_chunks = chunk_metadata.get("total_chunks", 0)
            
            if total_chunks > 0 and successful_chunks / total_chunks >= 0.8:
                achievement_score += 0.1  # 10% bonus for successful chunk processing
            
            return min(1.0, achievement_score)
        except Exception as e:
            logger.error(f"Error in chunked achievements assessment: {e}")
            return 0.5
    
    def _calculate_grade(self, overall_score: float) -> str:
        """Calculate letter grade from overall score."""
        if overall_score >= 0.9:
            return "A"
        elif overall_score >= 0.8:
            return "B"
        elif overall_score >= 0.7:
            return "C"
        elif overall_score >= 0.6:
            return "D"
        else:
            return "F"
    
    def _generate_recommendations(self, quality_scores: Dict[str, float]) -> List[str]:
        """Generate improvement recommendations."""
        recommendations = []
        
        for category, score in quality_scores.items():
            if score < 0.7:
                if category == "completeness":
                    recommendations.append("Add missing contact information and work experience details")
                elif category == "relevance":
                    recommendations.append("Include more relevant skills and targeted experience")
                elif category == "presentation":
                    recommendations.append("Improve resume formatting and structure")
                elif category == "achievements":
                    recommendations.append("Add specific achievements and quantifiable results")
        
        if not recommendations:
            recommendations.append("Resume shows strong quality across all areas")
        
        return recommendations
    
    def _identify_strengths(self, quality_scores: Dict[str, float]) -> List[str]:
        """Identify resume strengths."""
        strengths = []
        
        for category, score in quality_scores.items():
            if score >= 0.8:
                if category == "completeness":
                    strengths.append("Complete professional information")
                elif category == "relevance":
                    strengths.append("Highly relevant experience and skills")
                elif category == "presentation":
                    strengths.append("Well-structured and professional presentation")
                elif category == "achievements":
                    strengths.append("Strong achievement-focused content")
        
        return strengths
    
    def _identify_improvements(self, quality_scores: Dict[str, float]) -> List[str]:
        """Identify areas for improvement."""
        improvements = []
        
        for category, score in quality_scores.items():
            if score < 0.6:
                improvements.append(f"Significant improvement needed in {category}")
            elif score < 0.8:
                improvements.append(f"Some enhancement possible in {category}")
        
        return improvements
    
    async def assess_match_quality(
        self, 
        job_posting: Dict[str, Any], 
        candidate: Dict[str, Any], 
        match_score: float
    ) -> Dict[str, Any]:
        """
        Assess the quality of a job match.
        
        Args:
            job_posting: Job requirements
            candidate: Candidate profile
            match_score: Initial match score
            
        Returns:
            Match quality assessment
        """
        try:
            logger.info("Assessing job match quality")
            
            # TODO: Implement LLM-based match quality assessment
            
            # Mock match quality assessment
            quality_factors = {
                "skill_alignment": min(match_score + 0.1, 1.0),
                "experience_level": match_score,
                "cultural_fit": match_score * 0.9,
                "growth_potential": match_score * 1.1
            }
            
            overall_quality = sum(quality_factors.values()) / len(quality_factors)
            
            return {
                "overall_quality": overall_quality,
                "quality_factors": quality_factors,
                "confidence": "high" if overall_quality > 0.8 else "medium" if overall_quality > 0.6 else "low",
                "recommendation": self._get_match_recommendation(overall_quality)
            }
            
        except Exception as e:
            logger.error(f"Error assessing match quality: {e}")
            return {
                "overall_quality": 0.0,
                "quality_factors": {},
                "confidence": "low",
                "recommendation": "Unable to assess"
            }
    
    def _get_match_recommendation(self, quality_score: float) -> str:
        """Get recommendation based on match quality."""
        if quality_score >= 0.9:
            return "Highly recommended - excellent match"
        elif quality_score >= 0.8:
            return "Recommended - strong candidate"
        elif quality_score >= 0.7:
            return "Consider - good potential"
        elif quality_score >= 0.6:
            return "Review carefully - moderate fit"
        else:
            return "Not recommended - poor match"
    
    async def shutdown(self) -> None:
        """Shutdown the quality assessment agent."""
        logger.info("Shutting down Quality Assessment Agent...")
        self.initialized = False
        logger.info("Quality Assessment Agent shutdown complete")
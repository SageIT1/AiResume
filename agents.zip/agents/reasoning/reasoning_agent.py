"""
Reasoning Agent for AI Recruit - Agentic AI Reasoning and Decision Making
Advanced reasoning agent for complex decision making and explanation generation.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import os
from typing import Dict, List, Any, Optional, Literal
from datetime import datetime

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langchain_anthropic import ChatAnthropic
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class ReasoningFactor(BaseModel):
    """Individual reasoning factor with detailed analysis."""
    factor_name: str
    importance_level: Literal["critical", "high", "medium", "low"]
    assessment: str = Field(description="Detailed assessment of this factor")
    impact: Literal["strongly_positive", "positive", "neutral", "negative", "strongly_negative"]
    confidence: float = Field(ge=0, le=1)
    supporting_evidence: List[str]
    weight: float = Field(ge=0, le=1, description="Weight of this factor in decision")


class ReasoningDecision(BaseModel):
    """Structured reasoning decision with comprehensive analysis."""
    decision: Literal["strong_recommend", "recommend", "conditional", "not_recommend", "strongly_not_recommend"]
    confidence_level: float = Field(ge=0, le=1)
    primary_reasoning: str = Field(description="Main reasoning for this decision")
    
    # Detailed factor analysis
    key_factors: List[ReasoningFactor]
    
    # Decision support
    supporting_arguments: List[str] = Field(description="Arguments supporting this decision")
    counterarguments: List[str] = Field(description="Arguments against this decision")
    risk_assessment: str = Field(description="Assessment of risks with this decision")
    
    # Recommendations
    next_steps: List[str] = Field(description="Recommended next steps")
    conditions: List[str] = Field(description="Conditions that would change this decision")
    
    # Meta-reasoning
    reasoning_chain: List[str] = Field(description="Step-by-step reasoning process")
    alternative_perspectives: List[str] = Field(description="Other ways to view this situation")
    confidence_factors: Dict[str, str] = Field(description="Factors affecting confidence level")


class ComprehensiveReasoning(BaseModel):
    """Complete reasoning analysis for complex scenarios."""
    scenario_type: str = Field(description="Type of scenario being analyzed")
    overall_assessment: str = Field(description="Executive summary of the analysis")
    
    # Primary analysis
    main_decision: ReasoningDecision
    alternative_decisions: List[ReasoningDecision] = Field(description="Other viable decisions considered")
    
    # Insights and patterns
    key_insights: List[str] = Field(description="Important insights from the analysis")
    patterns_identified: List[str] = Field(description="Patterns or trends identified")
    hidden_factors: List[str] = Field(description="Non-obvious factors that matter")
    
    # Strategic considerations
    short_term_implications: List[str]
    long_term_implications: List[str]
    success_indicators: List[str] = Field(description="How to measure success of this decision")
    
    # Quality and meta-analysis
    analysis_quality: float = Field(ge=0, le=1, description="Quality/completeness of this analysis")
    uncertainty_areas: List[str] = Field(description="Areas with high uncertainty")
    additional_data_needed: List[str] = Field(description="Data that would improve decision quality")
    
    # Summary
    executive_summary: str = Field(description="Brief summary for decision makers")
    recommended_timeline: str = Field(description="Suggested timeline for action")


class ReasoningAgent:
    """
    AI-powered reasoning agent for complex decision making and explanations.
    
    This agent:
    - Provides logical reasoning for recruitment decisions
    - Generates natural language explanations
    - Handles multi-criteria decision making
    - NO manual logic trees or hardcoded reasoning
    """
    
    def __init__(self, llm=None, settings=None):
        """
        Initialize the Reasoning Agent.
        
        Args:
            llm: Language model for reasoning
            settings: Application settings
        """
        self.llm = llm
        self.settings = settings
        self.agent_id = "reasoning_agent"
        self.initialized = False
        
        # Agent configuration
        self.config = {
            "temperature": 0.2,  # Slightly higher for creative reasoning
            "max_tokens": 4096,  # Increased for detailed reasoning
            "model_name": "gpt-4.1"
        }
        
        logger.info(f"ReasoningAgent initialized with ID: {self.agent_id}")
    
    async def initialize(self) -> None:
        """Initialize the reasoning agent with LLM configuration."""
        if self.initialized:
            return
        
        logger.info("🔄 Initializing Reasoning Agent with LLM...")
        
        try:
            # Initialize LLM based on provider
            if self.settings:
                llm_config = self.settings.get_llm_config()
                provider = llm_config.get("provider", "openai")
                
                if provider == "azure_openai":
                    self.llm = AzureChatOpenAI(
                        deployment_name=llm_config.get("deployment_name", "gpt-4.1"),
                        model="gpt-4.1",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"],
                        azure_endpoint=llm_config.get("endpoint"),
                        api_key=llm_config.get("api_key"),
                        api_version="2024-02-15-preview"
                    )
                elif provider == "openai":
                    self.llm = ChatOpenAI(
                        model="gpt-4.1",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"],
                        api_key=llm_config.get("api_key")
                    )
                elif provider == "anthropic":
                    self.llm = ChatAnthropic(
                        model="claude-3-opus-20240229",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"],
                        api_key=llm_config.get("api_key")
                    )
                else:
                    logger.warning(f"Unknown LLM provider: {provider}, using OpenAI as fallback")
                    self.llm = ChatOpenAI(
                        model="gpt-4.1",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"]
                    )
            
            self.initialized = True
            logger.info("✅ Reasoning Agent ready for intelligent decision making")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Reasoning Agent: {str(e)}")
            # Continue without LLM for now
            self.initialized = True
    
    async def reason_about_match(
        self, 
        job_posting: Dict[str, Any], 
        candidate: Dict[str, Any], 
        context: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Provide comprehensive AI-powered reasoning about a candidate-job match.
        
        Args:
            job_posting: Job requirements and details
            candidate: Candidate profile and qualifications
            context: Additional context for reasoning
            
        Returns:
            Detailed reasoning result with explanations and recommendations
        """
        try:
            if not self.initialized:
                await self.initialize()
            
            logger.info("🧠 Starting AI reasoning about candidate-job match")
            
            if not self.llm:
                logger.warning("⚠️ No LLM available, using fallback reasoning")
                return await self._fallback_match_reasoning(job_posting, candidate, context)
            
            # Create comprehensive reasoning analysis
            reasoning_analysis = await self._analyze_match_comprehensive(
                job_posting, candidate, context
            )
            
            # Convert to legacy format for compatibility
            legacy_result = {
                "decision": self._convert_decision_to_legacy(reasoning_analysis.main_decision.decision),
                "reasoning_chain": reasoning_analysis.main_decision.reasoning_chain,
                "confidence": reasoning_analysis.main_decision.confidence_level,
                "key_factors": [
                    {
                        "factor": factor.factor_name,
                        "importance": factor.importance_level,
                        "assessment": factor.assessment,
                        "impact": factor.impact
                    } for factor in reasoning_analysis.main_decision.key_factors
                ],
                "recommendations": reasoning_analysis.main_decision.next_steps,
                "next_steps": reasoning_analysis.main_decision.next_steps,
                
                # Additional comprehensive data
                "detailed_analysis": reasoning_analysis.dict(),
                "executive_summary": reasoning_analysis.executive_summary,
                "alternative_perspectives": reasoning_analysis.main_decision.alternative_perspectives,
                "risk_assessment": reasoning_analysis.main_decision.risk_assessment,
                "success_indicators": reasoning_analysis.success_indicators
            }
            
            logger.info(f"✅ AI reasoning completed with {reasoning_analysis.main_decision.confidence_level:.1%} confidence")
            return legacy_result
            
        except Exception as e:
            logger.error(f"❌ Error in reasoning process: {e}")
            return {
                "decision": "inconclusive",
                "reasoning_chain": [f"Error in reasoning: {str(e)}"],
                "confidence": 0.0,
                "key_factors": [],
                "recommendations": ["Unable to provide reasoning due to error"],
                "next_steps": ["Review error and retry"],
                "error": str(e)
            }
    
    async def _analyze_match_comprehensive(
        self,
        job_posting: Dict[str, Any],
        candidate: Dict[str, Any],
        context: Dict[str, Any] = None
    ) -> ComprehensiveReasoning:
        """
        Perform comprehensive AI-powered reasoning analysis.
        
        Args:
            job_posting: Job requirements and details
            candidate: Candidate profile and qualifications
            context: Additional context for analysis
            
        Returns:
            Structured comprehensive reasoning analysis
        """
        try:
            # Prepare reasoning prompt
            reasoning_prompt = self._create_reasoning_prompt(job_posting, candidate, context)
            
            # Use structured output with Pydantic
            from langchain.output_parsers import PydanticOutputParser
            parser = PydanticOutputParser(pydantic_object=ComprehensiveReasoning)
            
            # Create chat prompt
            chat_prompt = ChatPromptTemplate.from_messages([
                SystemMessage(content=self._get_reasoning_system_prompt()),
                HumanMessage(content=reasoning_prompt + "\n\n" + parser.get_format_instructions())
            ])
            
            # Execute LLM reasoning
            logger.info("🤖 Executing comprehensive LLM reasoning analysis...")
            chain = chat_prompt | self.llm | parser
            
            reasoning_result = await chain.ainvoke({})
            
            logger.info(f"✅ LLM reasoning completed: {reasoning_result.main_decision.decision}")
            return reasoning_result
            
        except Exception as e:
            logger.error(f"❌ Error in comprehensive reasoning analysis: {e}")
            # Return fallback structured reasoning
            return await self._create_fallback_reasoning(job_posting, candidate, context, str(e))
    
    def _get_reasoning_system_prompt(self) -> str:
        """Get the system prompt for comprehensive reasoning."""
        return """You are an expert AI reasoning specialist with deep expertise in logical analysis, decision-making, and talent assessment. Your role is to provide comprehensive, structured reasoning for complex hiring decisions.

Core Capabilities:
1. Multi-factor analysis with weighted importance assessment
2. Evidence-based reasoning with clear logical chains
3. Risk assessment and scenario planning
4. Alternative perspective consideration
5. Confidence calibration based on data quality
6. Strategic long-term thinking

Reasoning Principles:
- Always provide clear, logical reasoning chains
- Consider multiple perspectives and alternative viewpoints
- Assess risks and uncertainties explicitly
- Base confidence levels on evidence quality and completeness
- Identify both obvious and hidden factors
- Consider short-term and long-term implications
- Provide actionable recommendations with clear next steps

Decision Framework:
- strong_recommend: Exceptional fit with high confidence (>90%)
- recommend: Good fit with solid reasoning (>75%)
- conditional: Moderate fit with specific conditions (>60%)
- not_recommend: Poor fit or significant concerns (<60%)
- strongly_not_recommend: Very poor fit with high confidence (<40%)

Analysis Depth:
- Examine all relevant factors with appropriate weighting
- Consider context, nuance, and edge cases
- Provide detailed supporting evidence
- Identify potential blind spots or biases
- Suggest ways to improve decision quality

Always maintain objectivity, consider multiple perspectives, and provide reasoning that would stand up to scrutiny from other experts."""
    
    def _create_reasoning_prompt(
        self,
        job_posting: Dict[str, Any],
        candidate: Dict[str, Any],
        context: Dict[str, Any] = None
    ) -> str:
        """Create a comprehensive reasoning prompt for the LLM."""
        
        # Extract key information
        job_title = job_posting.get("title", "Unknown Position")
        job_description = job_posting.get("description", "")
        required_skills = job_posting.get("required_skills", [])
        preferred_skills = job_posting.get("preferred_skills", [])
        min_experience = job_posting.get("min_years_experience", 0)
        
        candidate_name = candidate.get("name", "Candidate")
        candidate_skills = candidate.get("skills", [])
        candidate_experience = candidate.get("total_years_experience", 0)
        work_history = candidate.get("work_history", [])
        education = candidate.get("education", {})
        
        # Additional context
        context_info = context or {}
        match_scores = context_info.get("match_scores", {})
        
        prompt = f"""
COMPREHENSIVE REASONING ANALYSIS: CANDIDATE-JOB MATCH

SCENARIO OVERVIEW:
Analyze the fit between {candidate_name} and the {job_title} position. Provide comprehensive reasoning that considers all relevant factors, potential risks, and strategic implications.

JOB REQUIREMENTS:
Position: {job_title}
Required Experience: {min_experience}+ years
Required Skills: {', '.join(required_skills) if required_skills else 'Not specified'}
Preferred Skills: {', '.join(preferred_skills) if preferred_skills else 'Not specified'}

Job Description:
{job_description}

CANDIDATE PROFILE:
Name: {candidate_name}
Total Experience: {candidate_experience} years
Skills: {', '.join(candidate_skills) if candidate_skills else 'Not specified'}
Education: {education}

Recent Work History:
{self._format_work_history_for_reasoning(work_history)}

CONTEXT INFORMATION:
{self._format_context_info(context_info)}

REASONING ANALYSIS REQUIREMENTS:

1. FACTOR IDENTIFICATION & WEIGHTING:
   - Identify all relevant factors (skills, experience, education, cultural fit, growth potential, etc.)
   - Assess importance level of each factor for this specific role
   - Provide detailed assessment of candidate's strength in each area
   - Determine positive/negative impact of each factor

2. EVIDENCE-BASED REASONING:
   - Support all assessments with specific evidence from candidate profile
   - Consider both explicit qualifications and implicit indicators
   - Identify gaps between requirements and candidate qualifications
   - Assess transferable skills and growth potential

3. RISK & SCENARIO ANALYSIS:
   - Evaluate risks associated with hiring this candidate
   - Consider what could go wrong and probability/impact
   - Identify conditions that would change the assessment
   - Assess uncertainty areas and confidence levels

4. STRATEGIC CONSIDERATIONS:
   - Short-term performance expectations vs. long-term potential
   - Impact on team dynamics and organizational goals
   - Career development and retention likelihood
   - Alternative uses of this talent within organization

5. ALTERNATIVE PERSPECTIVES:
   - How might different stakeholders view this candidate?
   - What are potential counterarguments to your assessment?
   - What additional information would change your reasoning?
   - How does this fit broader hiring strategy?

6. DECISION FRAMEWORK:
   - Clear recommendation with confidence level
   - Specific next steps and timeline
   - Success metrics and monitoring approach
   - Conditions that would change recommendation

Provide a comprehensive reasoning analysis that demonstrates deep thinking, considers multiple angles, and provides actionable insights for decision-makers.
"""
        return prompt
    
    def _format_work_history_for_reasoning(self, work_history: List[Dict]) -> str:
        """Format work history for reasoning analysis."""
        if not work_history:
            return "No work history provided"
        
        formatted = []
        for i, job in enumerate(work_history[:3]):  # Most recent 3 jobs
            title = job.get("title", "Unknown")
            company = job.get("company", "Unknown")
            duration = job.get("duration", "Unknown")
            description = job.get("description", "No description")
            skills = job.get("skills_used", [])
            
            formatted.append(f"{i+1}. {title} at {company} ({duration})")
            formatted.append(f"   Description: {description}")
            if skills:
                formatted.append(f"   Skills: {', '.join(skills)}")
            formatted.append("")
        
        return "\n".join(formatted)
    
    def _format_context_info(self, context_info: Dict[str, Any]) -> str:
        """Format additional context information."""
        if not context_info:
            return "No additional context provided"
        
        formatted = []
        
        if "match_scores" in context_info:
            scores = context_info["match_scores"]
            formatted.append("Match Scores:")
            for category, score in scores.items():
                formatted.append(f"- {category}: {score:.1%}")
        
        if "team_info" in context_info:
            formatted.append(f"Team Context: {context_info['team_info']}")
        
        if "urgency" in context_info:
            formatted.append(f"Hiring Urgency: {context_info['urgency']}")
        
        if "budget_constraints" in context_info:
            formatted.append(f"Budget Considerations: {context_info['budget_constraints']}")
        
        return "\n".join(formatted) if formatted else "No additional context provided"
    
    def _convert_decision_to_legacy(self, decision: str) -> str:
        """Convert new decision format to legacy format."""
        mapping = {
            "strong_recommend": "strong_match",
            "recommend": "good_match",
            "conditional": "potential_match",
            "not_recommend": "weak_match",
            "strongly_not_recommend": "no_match"
        }
        return mapping.get(decision, "potential_match")
    
    async def _fallback_match_reasoning(
        self,
        job_posting: Dict[str, Any],
        candidate: Dict[str, Any],
        context: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Fallback reasoning when LLM is not available."""
        try:
            logger.info("🔄 Using fallback rule-based reasoning")
            
            # Basic analysis
            job_skills = set(str(skill).lower() for skill in job_posting.get("required_skills", []))
            candidate_skills = set(str(skill).lower() for skill in candidate.get("skills", []))
            
            skills_overlap = job_skills.intersection(candidate_skills)
            skills_coverage = len(skills_overlap) / len(job_skills) if job_skills else 0.5
            
            # Experience analysis
            required_exp = job_posting.get("min_years_experience", 0)
            candidate_exp = candidate.get("total_years_experience", 0)
            exp_ratio = min(candidate_exp / max(required_exp, 1), 1.0) if required_exp > 0 else 0.7
            
            # Overall score
            overall_score = (skills_coverage * 0.6) + (exp_ratio * 0.4)
            
            # Decision mapping
            if overall_score >= 0.8:
                decision = "strong_match"
                confidence = 0.7
            elif overall_score >= 0.6:
                decision = "good_match"
                confidence = 0.6
            elif overall_score >= 0.4:
                decision = "potential_match"
                confidence = 0.5
            else:
                decision = "weak_match"
                confidence = 0.4
            
            return {
                "decision": decision,
                "reasoning_chain": [
                    f"1. Analyzed skill coverage: {skills_coverage:.1%}",
                    f"2. Evaluated experience ratio: {exp_ratio:.1%}",
                    f"3. Calculated overall fit: {overall_score:.1%}",
                    "4. Applied decision thresholds",
                    "5. Generated recommendation"
                ],
                "confidence": confidence,
                "key_factors": [
                    {
                        "factor": "Skills Match",
                        "importance": "high",
                        "assessment": f"Matches {len(skills_overlap)}/{len(job_skills)} required skills",
                        "impact": "positive" if skills_coverage > 0.5 else "negative"
                    },
                    {
                        "factor": "Experience Level",
                        "importance": "high",
                        "assessment": f"{candidate_exp} years vs {required_exp} required",
                        "impact": "positive" if exp_ratio > 0.8 else "neutral" if exp_ratio > 0.5 else "negative"
                    }
                ],
                "recommendations": [
                    "Validate technical skills through assessment",
                    "Review experience depth and relevance",
                    "Consider cultural fit evaluation"
                ],
                "next_steps": [
                    "Schedule technical interview",
                    "Prepare skill-specific questions",
                    "Plan team interaction session"
                ],
                "executive_summary": f"Rule-based analysis shows {overall_score:.1%} match with {confidence:.1%} confidence"
            }
            
        except Exception as e:
            logger.error(f"❌ Error in fallback reasoning: {e}")
            return {
                "decision": "inconclusive",
                "reasoning_chain": [f"Error in fallback reasoning: {str(e)}"],
                "confidence": 0.3,
                "key_factors": [],
                "recommendations": ["Manual review required"],
                "next_steps": ["Review candidate manually"],
                "error": str(e)
            }
    
    async def _create_fallback_reasoning(
        self,
        job_posting: Dict[str, Any],
        candidate: Dict[str, Any],
        context: Dict[str, Any] = None,
        error_msg: str = ""
    ) -> ComprehensiveReasoning:
        """Create fallback structured reasoning."""
        try:
            # Basic factor analysis
            key_factors = [
                ReasoningFactor(
                    factor_name="Skills Alignment",
                    importance_level="high",
                    assessment="Basic skill matching analysis",
                    impact="neutral",
                    confidence=0.5,
                    supporting_evidence=["Rule-based skill comparison"],
                    weight=0.4
                ),
                ReasoningFactor(
                    factor_name="Experience Level",
                    importance_level="high",
                    assessment="Years of experience comparison",
                    impact="neutral",
                    confidence=0.5,
                    supporting_evidence=["Experience duration analysis"],
                    weight=0.3
                )
            ]
            
            # Main decision
            main_decision = ReasoningDecision(
                decision="conditional",
                confidence_level=0.5,
                primary_reasoning="Limited analysis due to LLM unavailability",
                key_factors=key_factors,
                supporting_arguments=["Basic qualification match"],
                counterarguments=["Insufficient detailed analysis"],
                risk_assessment="Medium risk due to limited analysis depth",
                next_steps=["Conduct manual detailed review", "Schedule comprehensive interview"],
                conditions=["Successful technical validation", "Cultural fit confirmation"],
                reasoning_chain=[
                    "1. Performed basic rule-based analysis",
                    "2. Compared skills and experience quantitatively",
                    "3. Applied conservative decision thresholds",
                    "4. Recommended additional validation"
                ],
                alternative_perspectives=["Could be stronger with detailed AI analysis"],
                confidence_factors={
                    "data_quality": "Limited profile information",
                    "analysis_depth": "Basic rule-based only",
                    "context": "Missing nuanced understanding"
                }
            )
            
            return ComprehensiveReasoning(
                scenario_type="candidate_job_matching",
                overall_assessment="Conservative assessment due to limited AI analysis capabilities",
                main_decision=main_decision,
                alternative_decisions=[],
                key_insights=["Detailed AI analysis would improve decision quality"],
                patterns_identified=["Standard qualification matching pattern"],
                hidden_factors=["Unable to identify without AI analysis"],
                short_term_implications=["Proceed with caution"],
                long_term_implications=["May miss optimal candidates without better analysis"],
                success_indicators=["Technical performance", "Team integration"],
                analysis_quality=0.4,
                uncertainty_areas=["Cultural fit", "Growth potential", "Team dynamics"],
                additional_data_needed=["Portfolio samples", "Reference checks", "Technical assessment results"],
                executive_summary=f"Conservative matching assessment. {error_msg}",
                recommended_timeline="Extended evaluation period recommended"
            )
            
        except Exception as e:
            logger.error(f"❌ Error creating fallback reasoning: {e}")
            # Return minimal valid reasoning
            minimal_factor = ReasoningFactor(
                factor_name="Unknown",
                importance_level="medium",
                assessment="Unable to assess",
                impact="neutral",
                confidence=0.3,
                supporting_evidence=["Analysis failed"],
                weight=0.5
            )
            
            minimal_decision = ReasoningDecision(
                decision="conditional",
                confidence_level=0.3,
                primary_reasoning="Analysis system error",
                key_factors=[minimal_factor],
                supporting_arguments=["None available"],
                counterarguments=["System limitations"],
                risk_assessment="High risk due to analysis failure",
                next_steps=["Manual review required"],
                conditions=["System recovery"],
                reasoning_chain=["Analysis failed"],
                alternative_perspectives=["Manual assessment needed"],
                confidence_factors={"system_status": "Failed"}
            )
            
            return ComprehensiveReasoning(
                scenario_type="system_error",
                overall_assessment="Analysis failed - manual review required",
                main_decision=minimal_decision,
                alternative_decisions=[],
                key_insights=["System needs attention"],
                patterns_identified=[],
                hidden_factors=[],
                short_term_implications=["Manual process required"],
                long_term_implications=["Fix system for future analyses"],
                success_indicators=["System recovery"],
                analysis_quality=0.1,
                uncertainty_areas=["Everything"],
                additional_data_needed=["System diagnostic"],
                executive_summary="System error - manual intervention required",
                recommended_timeline="Immediate system review"
            )
    
    def _make_mock_decision(self, job_posting: Dict[str, Any], candidate: Dict[str, Any]) -> str:
        """Make a mock decision for development."""
        job_skills = set(job_posting.get("required_skills", []))
        candidate_skills = set(candidate.get("skills", []))
        
        overlap = len(job_skills.intersection(candidate_skills))
        total_required = len(job_skills) if job_skills else 1
        
        match_ratio = overlap / total_required
        
        if match_ratio >= 0.8:
            return "strong_match"
        elif match_ratio >= 0.6:
            return "good_match"
        elif match_ratio >= 0.4:
            return "potential_match"
        else:
            return "weak_match"
    
    def _generate_reasoning_chain(self, job_posting: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
        """Generate a chain of reasoning steps."""
        chain = [
            "1. Analyzed candidate's technical skills against job requirements",
            "2. Evaluated relevant work experience and career progression",
            "3. Assessed educational background and certifications",
            "4. Considered cultural fit and soft skills alignment",
            "5. Weighted all factors to reach final assessment"
        ]
        return chain
    
    def _calculate_confidence(self, job_posting: Dict[str, Any], candidate: Dict[str, Any]) -> float:
        """Calculate confidence in the reasoning."""
        # Mock confidence calculation
        has_complete_job_info = bool(job_posting.get("required_skills") and job_posting.get("description"))
        has_complete_candidate_info = bool(candidate.get("skills") and candidate.get("experience"))
        
        if has_complete_job_info and has_complete_candidate_info:
            return 0.85
        elif has_complete_job_info or has_complete_candidate_info:
            return 0.65
        else:
            return 0.45
    
    def _identify_key_factors(self, job_posting: Dict[str, Any], candidate: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify key factors in the reasoning."""
        factors = [
            {
                "factor": "Technical Skills",
                "importance": "high",
                "assessment": "Strong alignment with required technologies",
                "impact": "positive"
            },
            {
                "factor": "Experience Level",
                "importance": "high",
                "assessment": "Meets minimum requirements with room for growth",
                "impact": "neutral"
            },
            {
                "factor": "Industry Experience",
                "importance": "medium",
                "assessment": "Some relevant domain knowledge",
                "impact": "positive"
            }
        ]
        return factors
    
    def _generate_recommendations(self, job_posting: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on reasoning."""
        recommendations = [
            "Proceed with technical interview to validate skills",
            "Assess cultural fit through team interaction",
            "Consider offering mentoring for skill gaps",
            "Verify references from previous roles"
        ]
        return recommendations
    
    def _suggest_next_steps(self, job_posting: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
        """Suggest concrete next steps."""
        next_steps = [
            "Schedule initial phone screening",
            "Prepare technical assessment relevant to role",
            "Arrange team meeting for cultural fit evaluation",
            "Prepare offer negotiation parameters if successful"
        ]
        return next_steps
    
    async def generate_reasoning(self, workflow_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate comprehensive reasoning about the overall resume analysis.
        
        Args:
            workflow_results: Results from all workflow steps (resume analysis, quality assessment, etc.)
            
        Returns:
            Reasoning result with explanations and insights
        """
        try:
            logger.info("🧠 Generating comprehensive reasoning about resume analysis")
            
            # Extract key data from workflow results
            resume_analysis = workflow_results.get("resume_analysis", {})
            quality_assessment = workflow_results.get("quality_assessment", {})
            job_matching = workflow_results.get("job_matching", {})
            
            # TODO: Implement actual LLM-based reasoning
            # For now, return mock reasoning for development
            
            logger.warning("Using mock reasoning - implement LLM-based comprehensive analysis")
            
            reasoning_result = {
                "overall_assessment": self._generate_overall_assessment(resume_analysis, quality_assessment),
                "key_insights": self._extract_key_insights(workflow_results),
                "strengths": self._identify_candidate_strengths(resume_analysis),
                "areas_for_improvement": self._identify_improvement_areas(quality_assessment),
                "hiring_recommendation": self._generate_hiring_recommendation(workflow_results),
                "reasoning_chain": self._build_reasoning_chain(workflow_results),
                "confidence": self._calculate_overall_confidence(workflow_results),
                "next_steps": self._suggest_hiring_next_steps(workflow_results),
                "summary": self._generate_executive_summary(workflow_results)
            }
            
            logger.info(f"✅ Comprehensive reasoning completed with {reasoning_result['confidence']:.0%} confidence")
            return reasoning_result
            
        except Exception as e:
            logger.error(f"❌ Error generating comprehensive reasoning: {e}")
            return {
                "overall_assessment": "Unable to complete analysis",
                "key_insights": [],
                "strengths": [],
                "areas_for_improvement": [],
                "hiring_recommendation": "inconclusive",
                "reasoning_chain": [f"Analysis failed: {str(e)}"],
                "confidence": 0.0,
                "next_steps": ["Review error and retry analysis"],
                "summary": "Analysis could not be completed due to technical error"
            }
    
    def _generate_overall_assessment(self, resume_analysis: Dict[str, Any], quality_assessment: Dict[str, Any]) -> str:
        """Generate an overall assessment of the candidate."""
        quality_score = quality_assessment.get("overall_score", 0.5)
        
        if quality_score >= 0.8:
            return "Excellent candidate with strong qualifications and well-presented profile"
        elif quality_score >= 0.6:
            return "Good candidate with solid qualifications and adequate presentation"
        elif quality_score >= 0.4:
            return "Potential candidate with some qualifications but room for improvement"
        else:
            return "Candidate requires significant development or better profile presentation"
    
    def _extract_key_insights(self, workflow_results: Dict[str, Any]) -> List[str]:
        """Extract key insights from the analysis."""
        insights = [
            "Resume demonstrates relevant technical skills for software engineering roles",
            "Career progression shows consistent growth in responsibility",
            "Educational background provides solid foundation for technical work",
            "Profile could benefit from more quantified achievements"
        ]
        return insights
    
    def _identify_candidate_strengths(self, resume_analysis: Dict[str, Any]) -> List[str]:
        """Identify candidate's key strengths."""
        strengths = [
            "Strong technical skill set with modern technologies",
            "Relevant industry experience in software development",
            "Educational background aligns with career path",
            "Clear career focus in technology sector"
        ]
        return strengths
    
    def _identify_improvement_areas(self, quality_assessment: Dict[str, Any]) -> List[str]:
        """Identify areas where the candidate can improve."""
        improvements = [
            "Add quantified achievements and impact metrics",
            "Include links to professional profiles (LinkedIn, GitHub)",
            "Expand on specific project details and technologies used",
            "Consider adding relevant certifications or continuing education"
        ]
        return improvements
    
    def _generate_hiring_recommendation(self, workflow_results: Dict[str, Any]) -> str:
        """Generate a hiring recommendation."""
        quality_score = workflow_results.get("quality_assessment", {}).get("overall_score", 0.5)
        
        if quality_score >= 0.7:
            return "recommend_interview"
        elif quality_score >= 0.5:
            return "consider_for_review"
        else:
            return "requires_improvement"
    
    def _build_reasoning_chain(self, workflow_results: Dict[str, Any]) -> List[str]:
        """Build a chain of reasoning steps."""
        chain = [
            "1. Analyzed resume content and extracted structured information",
            "2. Evaluated technical skills and experience relevance",
            "3. Assessed educational background and career progression",
            "4. Reviewed resume quality and presentation standards",
            "5. Synthesized findings to generate comprehensive assessment",
            "6. Formulated hiring recommendation based on overall evaluation"
        ]
        return chain
    
    def _calculate_overall_confidence(self, workflow_results: Dict[str, Any]) -> float:
        """Calculate confidence in the overall analysis."""
        # Base confidence on quality of input data and completeness of analysis
        has_resume_analysis = bool(workflow_results.get("resume_analysis"))
        has_quality_assessment = bool(workflow_results.get("quality_assessment"))
        
        if has_resume_analysis and has_quality_assessment:
            return 0.85
        elif has_resume_analysis or has_quality_assessment:
            return 0.65
        else:
            return 0.45
    
    def _suggest_hiring_next_steps(self, workflow_results: Dict[str, Any]) -> List[str]:
        """Suggest concrete next steps in the hiring process."""
        recommendation = self._generate_hiring_recommendation(workflow_results)
        
        if recommendation == "recommend_interview":
            return [
                "Schedule initial phone screening with hiring manager",
                "Prepare technical assessment relevant to role requirements",
                "Plan team interaction session for cultural fit evaluation",
                "Verify references and previous work history"
            ]
        elif recommendation == "consider_for_review":
            return [
                "Request additional information or portfolio samples",
                "Consider for alternative roles if available",
                "Schedule informal conversation to assess potential",
                "Review against other candidates in pipeline"
            ]
        else:
            return [
                "Provide feedback on resume improvement areas",
                "Consider for future opportunities after development",
                "Maintain candidate record for potential follow-up",
                "Suggest relevant training or certification paths"
            ]
    
    def _generate_executive_summary(self, workflow_results: Dict[str, Any]) -> str:
        """Generate an executive summary of the analysis."""
        recommendation = self._generate_hiring_recommendation(workflow_results)
        confidence = self._calculate_overall_confidence(workflow_results)
        
        if recommendation == "recommend_interview":
            return f"Strong candidate profile with {confidence:.0%} confidence. Recommend proceeding with interview process based on relevant experience and technical skills alignment."
        elif recommendation == "consider_for_review":
            return f"Moderate candidate profile with {confidence:.0%} confidence. Consider for further review or alternative positions based on specific role requirements."
        else:
            return f"Candidate profile needs improvement with {confidence:.0%} confidence. Suggest development areas before considering for current openings."

    async def explain_decision(
        self, 
        decision: str, 
        factors: List[Dict[str, Any]], 
        context: Dict[str, Any] = None
    ) -> str:
        """
        Generate a natural language explanation for a decision.
        
        Args:
            decision: The decision made
            factors: Key factors that influenced the decision
            context: Additional context
            
        Returns:
            Natural language explanation
        """
        try:
            # TODO: Use LLM to generate detailed explanations
            
            if decision == "strong_match":
                return "This candidate demonstrates excellent alignment with the role requirements, showing strong technical skills and relevant experience that make them an ideal fit for the position."
            elif decision == "good_match":
                return "The candidate shows solid qualifications for this role with good technical skills and relevant background, though some areas may benefit from additional development."
            elif decision == "potential_match":
                return "While the candidate has some relevant qualifications, there are gaps that would need to be addressed through training or mentoring to succeed in this role."
            else:
                return "The candidate's current qualifications show limited alignment with the role requirements, suggesting they may not be the best fit at this time."
                
        except Exception as e:
            logger.error(f"Error generating explanation: {e}")
            return "Unable to generate explanation due to processing error."
    
    async def compare_candidates(
        self, 
        job_posting: Dict[str, Any], 
        candidates: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Compare multiple candidates and provide reasoning.
        
        Args:
            job_posting: Job requirements
            candidates: List of candidates to compare
            
        Returns:
            Comparative analysis with reasoning
        """
        try:
            logger.info(f"Comparing {len(candidates)} candidates for reasoning analysis")
            
            # TODO: Implement LLM-based comparative reasoning
            
            comparisons = []
            for i, candidate in enumerate(candidates):
                comparison = {
                    "candidate_id": candidate.get("id", f"candidate_{i}"),
                    "ranking": i + 1,  # Mock ranking
                    "strengths": ["Strong technical skills", "Relevant experience"],
                    "weaknesses": ["Limited leadership experience"],
                    "differentiators": ["Unique domain expertise", "Cultural fit"],
                    "overall_assessment": "Strong candidate with growth potential"
                }
                comparisons.append(comparison)
            
            return {
                "total_candidates": len(candidates),
                "top_candidate": comparisons[0] if comparisons else None,
                "comparative_analysis": comparisons,
                "recommendation": "Proceed with top 3 candidates for further evaluation",
                "reasoning": "Based on comprehensive skill alignment and experience evaluation"
            }
            
        except Exception as e:
            logger.error(f"Error comparing candidates: {e}")
            return {
                "total_candidates": len(candidates),
                "error": str(e),
                "recommendation": "Unable to complete comparison"
            }
    
    async def generate_enhanced_explanation(
        self,
        decision_data: Dict[str, Any],
        target_audience: str = "hiring_manager"
    ) -> str:
        """
        Generate enhanced natural language explanation using AI.
        
        Args:
            decision_data: Decision data with reasoning
            target_audience: Target audience (hiring_manager, recruiter, candidate)
            
        Returns:
            Tailored natural language explanation
        """
        try:
            if not self.llm:
                return self._generate_basic_explanation(decision_data, target_audience)
            
            # Create explanation prompt
            prompt = f"""
Generate a clear, professional explanation for a {target_audience} about this hiring decision:

Decision: {decision_data.get('decision', 'unknown')}
Confidence: {decision_data.get('confidence', 0):.1%}
Key Factors: {decision_data.get('key_factors', [])}
Reasoning: {decision_data.get('reasoning_chain', [])}

Target Audience: {target_audience}

Provide a natural, professional explanation that:
1. Clearly states the recommendation
2. Explains the key reasoning
3. Addresses likely concerns
4. Suggests appropriate next steps
5. Uses appropriate tone for the audience

Keep it concise but comprehensive (2-3 paragraphs).
"""
            
            # Execute LLM explanation generation
            chat_prompt = ChatPromptTemplate.from_messages([
                SystemMessage(content="You are an expert communication specialist creating clear, professional explanations for hiring decisions."),
                HumanMessage(content=prompt)
            ])
            
            chain = chat_prompt | self.llm
            explanation = await chain.ainvoke({})
            
            return explanation.content if hasattr(explanation, 'content') else str(explanation)
            
        except Exception as e:
            logger.error(f"❌ Error generating enhanced explanation: {e}")
            return self._generate_basic_explanation(decision_data, target_audience)
    
    def _generate_basic_explanation(self, decision_data: Dict[str, Any], target_audience: str) -> str:
        """Generate basic explanation without LLM."""
        decision = decision_data.get('decision', 'unknown')
        confidence = decision_data.get('confidence', 0)
        
        if decision == "strong_match":
            return f"This candidate is an excellent fit for the position with {confidence:.1%} confidence. They demonstrate strong alignment with key requirements and show great potential for success in this role."
        elif decision == "good_match":
            return f"This candidate shows solid qualifications for the role with {confidence:.1%} confidence. While there are some areas for development, they meet most requirements and could be successful with proper support."
        elif decision == "potential_match":
            return f"This candidate shows potential but has some gaps that would need to be addressed. With {confidence:.1%} confidence, they might succeed with additional training and mentoring."
        else:
            return f"Based on our analysis with {confidence:.1%} confidence, this candidate may not be the best fit for this role at this time due to significant gaps in key requirements."
    
    async def shutdown(self) -> None:
        """Shutdown the reasoning agent."""
        logger.info("🔄 Shutting down Reasoning Agent...")
        if hasattr(self, 'llm') and self.llm:
            # Clean up LLM connections if needed
            pass
        self.initialized = False
        logger.info("✅ Reasoning Agent shutdown complete")
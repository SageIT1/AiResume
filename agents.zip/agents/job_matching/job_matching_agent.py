"""
Job Matching Agent for AI Recruit - Agentic AI Job Matching
Intelligent matching agent using semantic understanding and LLM reasoning.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import os
from typing import Dict, List, Any, Optional
from uuid import UUID
from datetime import datetime

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain.schema import BaseOutputParser
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langchain_anthropic import ChatAnthropic
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SkillMatchAnalysis(BaseModel):
    """Detailed analysis of skill matching."""
    skill_name: str
    required: bool
    candidate_level: str = Field(description="beginner, intermediate, advanced, expert")
    match_score: float = Field(ge=0, le=1)
    reasoning: str
    importance_weight: float = Field(ge=0, le=1)


class ExperienceMatchAnalysis(BaseModel):
    """Detailed analysis of experience matching."""
    years_required: Optional[int]
    years_candidate: Optional[float]  # Changed to float to accept decimal years like 10.25
    relevant_experience_score: float = Field(ge=0, le=1)
    leadership_required: bool
    leadership_present: bool
    industry_match_score: float = Field(ge=0, le=1)
    role_similarity_score: float = Field(ge=0, le=1)
    reasoning: str


class EducationMatchAnalysis(BaseModel):
    """Detailed analysis of education matching."""
    degree_required: Optional[str]
    candidate_degree: Optional[str]
    field_relevance_score: float = Field(ge=0, le=1)
    level_match_score: float = Field(ge=0, le=1)
    certification_bonus: float = Field(ge=0, le=0.2)
    reasoning: str


class LocationMatchAnalysis(BaseModel):
    """Detailed analysis of location and remote work matching."""
    location_preference_score: float = Field(ge=0, le=1)
    remote_work_alignment: float = Field(ge=0, le=1)
    timezone_compatibility: float = Field(ge=0, le=1)
    relocation_willingness: float = Field(ge=0, le=1)
    reasoning: str


class ComprehensiveMatchAnalysis(BaseModel):
    """Complete AI-powered match analysis with detailed reasoning."""
    overall_score: float = Field(ge=0, le=1, description="Weighted overall match score")
    confidence_level: float = Field(ge=0, le=1, description="AI confidence in this assessment")
    
    # Detailed component scores
    skills_analysis: List[SkillMatchAnalysis]
    experience_analysis: ExperienceMatchAnalysis
    education_analysis: EducationMatchAnalysis
    location_analysis: LocationMatchAnalysis
    
    # Component scores (0-1)
    skills_score: float = Field(ge=0, le=1)
    experience_score: float = Field(ge=0, le=1)
    education_score: float = Field(ge=0, le=1)
    location_score: float = Field(ge=0, le=1)
    cultural_fit_score: float = Field(ge=0, le=1)
    
    # Insights and recommendations
    key_strengths: List[str] = Field(description="Top 3-5 candidate strengths for this role")
    key_concerns: List[str] = Field(description="Main concerns or gaps")
    missing_skills: List[str] = Field(description="Required skills candidate doesn't have")
    development_areas: List[str] = Field(description="Areas where candidate could grow")
    
    # AI reasoning
    detailed_reasoning: str = Field(description="Comprehensive explanation of the match assessment")
    recommendation: str = Field(description="Clear hire/no-hire/maybe recommendation with reasoning")
    
    # Success prediction
    success_probability: float = Field(ge=0, le=1, description="Probability of success in this role")
    retention_prediction: str = Field(description="Expected retention (short/medium/long-term)")
    
    # Next steps
    interview_focus_areas: List[str] = Field(description="Key areas to explore in interviews")
    onboarding_recommendations: List[str] = Field(description="Suggested onboarding focus areas")


class JobMatchingAgent:
    """
    AI-powered job matching agent using LLM reasoning and vector similarity.
    
    This agent:
    - Uses semantic understanding for multi-criteria matching
    - Provides explainable AI recommendations
    - Adapts matching criteria based on job requirements
    - NO manual scoring rules or hardcoded patterns
    """
    
    def __init__(self, llm=None, settings=None, vector_store=None):
        """
        Initialize the Job Matching Agent.
        
        Args:
            llm: Language model for reasoning
            settings: Application settings
            vector_store: Vector database for semantic similarity
        """
        self.llm = llm
        self.settings = settings
        self.vector_store = vector_store
        self.agent_id = "job_matching_agent"
        self.initialized = False
        
        # Agent configuration
        self.config = {
            "temperature": 0.1,  # Low temperature for consistent matching
            "max_tokens": 4096,
            "model_name": "gpt-4.1",
            "matching_threshold": 0.0  # Let API endpoint handle threshold filtering
        }
        
        # Default matching weights - Experience is the PRIMARY factor, Skills are SECONDARY
        self.default_weights = {
            "experience": 0.50,  # Years and relevance of experience - PRIMARY FACTOR
            "skills": 0.35,      # Technical and soft skills - SECONDARY FACTOR
            "education": 0.10,   # Education and certifications - Secondary
            "location": 0.03,    # Location and remote work fit - Minimal
            "cultural_fit": 0.02 # Cultural and team fit - Minimal
        }
        
        logger.info(f"JobMatchingAgent initialized with ID: {self.agent_id}")
    
    async def initialize(self) -> None:
        """Initialize the job matching agent with LLM configuration."""
        if self.initialized:
            return
        
        logger.info("🔄 Initializing Job Matching Agent with LLM...")
        
        try:
            # Initialize LLM based on provider
            if self.settings:
                llm_config = self.settings.get_llm_config()
                provider = llm_config.get("provider", "openai")
                
                if provider == "azure_openai":
                    self.llm = AzureChatOpenAI(
                        deployment_name=llm_config.get("deployment_name", "gpt-4.1"),
                        model="gpt-4.1",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"],
                        azure_endpoint=llm_config.get("endpoint"),
                        api_key=llm_config.get("api_key"),
                        api_version="2024-02-15-preview"
                    )
                elif provider == "openai":
                    self.llm = ChatOpenAI(
                        model="gpt-4.1",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"],
                        api_key=llm_config.get("api_key")
                    )
                elif provider == "anthropic":
                    self.llm = ChatAnthropic(
                        model="claude-3-opus-20240229",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"],
                        api_key=llm_config.get("api_key")
                    )
                else:
                    logger.warning(f"Unknown LLM provider: {provider}, using OpenAI as fallback")
                    self.llm = ChatOpenAI(
                        model="gpt-4.1",
                        temperature=self.config["temperature"],
                        max_tokens=self.config["max_tokens"]
                    )
            
            self.initialized = True
            logger.info("✅ Job Matching Agent ready for intelligent matching")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Job Matching Agent: {str(e)}")
            # Continue without LLM for now
            self.initialized = True
    
    async def match_candidates(
        self, 
        job_posting: Dict[str, Any], 
        candidates: List[Dict[str, Any]],
        max_matches: int = 10,
        custom_weights: Optional[Dict[str, float]] = None
    ) -> List[Dict[str, Any]]:
        """
        Match candidates to a job posting using comprehensive AI reasoning.
        
        Args:
            job_posting: Job requirements and description
            candidates: List of candidate profiles
            max_matches: Maximum number of matches to return
            custom_weights: Custom weights for scoring components
            
        Returns:
            List of matched candidates with detailed scores and explanations
        """
        try:
            if not self.initialized:
                await self.initialize()
            
            logger.info(f"🔍 Starting AI-powered job matching for {len(candidates)} candidates")
            start_time = datetime.now()
            
            # Use custom weights or defaults
            weights = custom_weights or self.default_weights
            
            matches = []
            
            for i, candidate in enumerate(candidates):
                logger.info(f"📊 Analyzing candidate {i+1}/{len(candidates)}: {candidate.get('name', 'Unknown')}")
                
                # Use comprehensive AI reasoning for matching
                try:
                    match_analysis = await self._analyze_candidate_fit_comprehensive(
                        job_posting, candidate, weights
                    )
                    logger.info(f"🔍 Analysis result for {candidate.get('name', 'Unknown')}: overall_score={match_analysis.overall_score:.3f}, skills_score={match_analysis.skills_score:.3f}, threshold={self.config['matching_threshold']}")
                except Exception as e:
                    logger.error(f"❌ Analysis failed for {candidate.get('name', 'Unknown')}: {e}")
                    # Use fallback analysis instead of skipping
                    try:
                        match_analysis = await self._analyze_candidate_fit_fallback(
                            job_posting, candidate, weights
                        )
                        logger.info(f"🔄 Fallback analysis for {candidate.get('name', 'Unknown')}: overall_score={match_analysis.overall_score:.3f}, skills_score={match_analysis.skills_score:.3f}")
                    except Exception as fallback_error:
                        logger.error(f"❌ Fallback analysis also failed for {candidate.get('name', 'Unknown')}: {fallback_error}")
                        continue
                
                if match_analysis.overall_score >= self.config["matching_threshold"]:
                    matches.append({
                        "candidate_id": candidate.get("id"),
                        "candidate_name": candidate.get("name"),
                        "candidate_email": candidate.get("email"),
                        "overall_score": match_analysis.overall_score,
                        "confidence_level": match_analysis.confidence_level,
                        
                        # Component scores
                        "skills_score": match_analysis.skills_score,
                        "experience_score": match_analysis.experience_score,
                        "education_score": match_analysis.education_score,
                        "location_score": match_analysis.location_score,
                        "cultural_fit_score": match_analysis.cultural_fit_score,
                        
                        # Detailed analysis
                        "skills_analysis": [skill.dict() for skill in match_analysis.skills_analysis],
                        "experience_analysis": match_analysis.experience_analysis.dict(),
                        "education_analysis": match_analysis.education_analysis.dict(),
                        "location_analysis": match_analysis.location_analysis.dict(),
                        
                        # Insights
                        "key_strengths": match_analysis.key_strengths,
                        "key_concerns": match_analysis.key_concerns,
                        "missing_skills": match_analysis.missing_skills,
                        "development_areas": match_analysis.development_areas,
                        
                        # AI reasoning
                        "detailed_reasoning": match_analysis.detailed_reasoning,
                        "recommendation": match_analysis.recommendation,
                        "success_probability": match_analysis.success_probability,
                        "retention_prediction": match_analysis.retention_prediction,
                        
                        # Next steps
                        "interview_focus_areas": match_analysis.interview_focus_areas,
                        "onboarding_recommendations": match_analysis.onboarding_recommendations,
                        
                        # Weights used
                        "weights_used": weights
                    })
            
            # Sort by overall score (descending)
            matches.sort(key=lambda x: x["overall_score"], reverse=True)
            
            # Return top matches
            final_matches = matches[:max_matches]
            
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.info(f"✅ AI matching completed: {len(final_matches)} matches found in {execution_time:.2f}s")
            
            return final_matches
            
        except Exception as e:
            logger.error(f"❌ Error in job matching: {e}")
            return []
    
    async def _analyze_candidate_fit_comprehensive(
        self, 
        job_posting: Dict[str, Any], 
        candidate: Dict[str, Any],
        weights: Dict[str, float]
    ) -> ComprehensiveMatchAnalysis:
        """
        Perform comprehensive AI-powered candidate-job fit analysis.
        
        Args:
            job_posting: Job requirements and description
            candidate: Candidate profile and qualifications
            weights: Scoring weights for different components
            
        Returns:
            Detailed analysis with scores, reasoning, and recommendations
        """
        try:
            if not self.llm:
                logger.warning("⚠️ No LLM available, using fallback analysis")
                return await self._fallback_analysis(job_posting, candidate, weights)
            
            # Prepare comprehensive analysis prompt
            analysis_prompt = self._create_comprehensive_analysis_prompt(
                job_posting, candidate, weights
            )
            
            # Use structured output with Pydantic
            from langchain.output_parsers import PydanticOutputParser
            parser = PydanticOutputParser(pydantic_object=ComprehensiveMatchAnalysis)
            
            # Create chat prompt
            chat_prompt = ChatPromptTemplate.from_messages([
                SystemMessage(content=self._get_system_prompt()),
                HumanMessage(content=analysis_prompt + "\n\n" + parser.get_format_instructions())
            ])
            
            # Execute LLM analysis
            logger.info("🤖 Executing comprehensive LLM analysis...")
            chain = chat_prompt | self.llm | parser
            
            analysis_result = await chain.ainvoke({})
            
            logger.info(f"✅ LLM analysis completed with score: {analysis_result.overall_score:.3f}")
            return analysis_result
            
        except Exception as e:
            logger.error(f"❌ Error in comprehensive analysis: {e}")
            logger.info("🔄 Falling back to rule-based analysis")
            return await self._fallback_analysis(job_posting, candidate, weights)
    
    def _get_system_prompt(self) -> str:
        """Get the system prompt for the matching agent."""
        return """You are an expert AI talent acquisition specialist with deep expertise in candidate evaluation and job matching. Your role is to provide comprehensive, accurate, and actionable candidate-job fit assessments.

Key responsibilities:
1. Analyze candidates against job requirements with precision and fairness
2. Provide detailed, objective scoring across multiple dimensions
3. Generate actionable insights for hiring decisions
4. Identify both strengths and development areas
5. Predict success probability and retention likelihood
6. Suggest interview focus areas and onboarding strategies

Analysis principles:
- Be thorough and evidence-based in your assessments
- Consider both hard skills and soft skills
- Account for potential and growth trajectory
- Provide specific, actionable recommendations
- Maintain objectivity and avoid bias
- Consider cultural fit and team dynamics
- Evaluate long-term success potential

Scoring guidance:
- 0.9-1.0: Exceptional match, ideal candidate
- 0.8-0.89: Strong match, highly recommended
- 0.7-0.79: Good match, recommended with minor concerns
- 0.6-0.69: Moderate match, proceed with caution
- 0.5-0.59: Weak match, significant concerns
- 0.0-0.49: Poor match, not recommended

Always provide detailed reasoning for your assessments and specific examples to support your conclusions."""
    
    def _create_comprehensive_analysis_prompt(
        self, 
        job_posting: Dict[str, Any], 
        candidate: Dict[str, Any],
        weights: Dict[str, float]
    ) -> str:
        """Create a comprehensive analysis prompt for the LLM."""
        
        # Extract key job information
        job_title = job_posting.get("title", "Unknown Position")
        job_description = job_posting.get("description", "")
        required_skills = job_posting.get("required_skills", [])
        preferred_skills = job_posting.get("preferred_skills", [])
        min_experience = job_posting.get("min_years_experience", 0)
        education_req = job_posting.get("education_requirements", {})
        location = job_posting.get("location", "")
        remote_option = job_posting.get("remote_option", "on-site")
        
        # Extract additional job details for better matching
        job_responsibilities = job_posting.get("responsibilities", [])
        job_requirements = job_posting.get("requirements", [])
        job_benefits = job_posting.get("benefits", [])
        company_info = job_posting.get("company", {})
        job_type = job_posting.get("job_type", "")
        experience_level = job_posting.get("experience_level", "")
        
        # Extract candidate information
        candidate_name = candidate.get("name", "Candidate")
        candidate_skills = candidate.get("skills", [])
        candidate_experience = candidate.get("total_years_experience", 0)
        candidate_education = candidate["ai_analysis"]["education_analysis"]["education"]
        candidate_location = candidate.get("location", "")
        work_history = candidate["ai_analysis"]["career_analysis"]["work_experience"]
        
        prompt = f"""
COMPREHENSIVE CANDIDATE-JOB MATCHING ANALYSIS

JOB DETAILS:
Position: {job_title}
Location: {location}
Remote Options: {remote_option}
Required Experience: {min_experience}+ years
Job Type: {job_type}
Experience Level: {experience_level}

Job Description:
{job_description}

Required Skills: {', '.join(required_skills) if required_skills else 'Not specified'}
Preferred Skills: {', '.join(preferred_skills) if preferred_skills else 'Not specified'}
Education Requirements: {education_req}

Key Job Responsibilities:
{self._format_job_responsibilities(job_responsibilities)}

Additional Requirements:
{self._format_job_requirements(job_requirements)}

Company Information:
{self._format_company_info(company_info)}

CANDIDATE PROFILE:
Name: {candidate_name}
Location: {candidate_location}
Total Experience: {candidate_experience} years
Skills: {', '.join(candidate_skills) if candidate_skills else 'Not specified'}
Education: {candidate_education}

DETAILED WORK HISTORY & ROLE RESPONSIBILITIES:
{self._format_work_history(work_history)}

IMPORTANT: Pay special attention to the detailed responsibilities, achievements, and technologies used in each role. This information is crucial for accurate experience matching and should heavily influence the experience_score calculation.

SCORING WEIGHTS (Experience is PRIMARY, Skills are SECONDARY):
- Experience Match: {weights.get('experience', 0.5):.1%} - PRIMARY FACTOR
- Skills Match: {weights.get('skills', 0.35):.1%} - SECONDARY FACTOR
- Education Match: {weights.get('education', 0.1):.1%} - Secondary
- Location/Remote Fit: {weights.get('location', 0.03):.1%} - Minimal
- Cultural Fit: {weights.get('cultural_fit', 0.02):.1%} - Minimal

ANALYSIS INSTRUCTIONS:

1. EXPERIENCE ANALYSIS (PRIMARY FACTOR - 50% weight):
   - Compare years of experience vs requirements with HIGH PRECISION
   - Assess relevance of past roles and responsibilities in detail
   - Evaluate leadership and management experience thoroughly
   - Consider industry experience and domain knowledge
   - Assess career progression and growth trajectory
   - CRITICAL: Experience matching is the MOST IMPORTANT factor in job matching
   - CRITICAL: Analyze each role's responsibilities in detail:
     * Match specific responsibilities to job requirements
     * Evaluate depth of experience in each responsibility area
     * Assess complexity and scope of past responsibilities
     * Consider transferable skills from different industries/roles
     * Evaluate progression in responsibility levels over time
     * Analyze team management and leadership experience
     * Consider project management and delivery experience
     * Assess stakeholder management and communication skills
     * Evaluate problem-solving and decision-making experience
     * Consider innovation and process improvement experience
   - CRITICAL: Experience score heavily influences overall match - prioritize accuracy

2. SKILLS ANALYSIS (SECONDARY FACTOR - 35% weight):
   - Evaluate each required skill individually with HIGH PRECISION
   - Assess candidate's proficiency level (beginner/intermediate/advanced/expert)
   - Calculate match scores for each skill with detailed reasoning
   - Identify missing critical skills and their impact
   - Consider transferable skills and learning potential
   - CRITICAL: Skills matching is the SECOND MOST IMPORTANT factor
   - For PERFECT direct skill matches: 1.0 (100%)
   - For good direct skill matches: 0.8-0.9
   - For transferable/similar skills: 0.6-0.8
   - For missing but learnable skills: 0.3-0.6
   - For completely missing critical skills: 0.0-0.3
   - CRITICAL: If candidate has ALL required skills at appropriate levels, skills_score should be 1.0
   - CRITICAL: Skills score significantly influences overall match - prioritize accuracy

3. EDUCATION ANALYSIS:
   - Compare degree level and field of study
   - Evaluate certifications and continuing education
   - Consider alternative experience in lieu of formal education
   - Assess learning agility and intellectual curiosity

4. LOCATION ANALYSIS:
   - Geographic compatibility
   - Remote work alignment
   - Timezone considerations
   - Relocation willingness if applicable

5. CULTURAL FIT:
   - Company values alignment
   - Team collaboration style
   - Work environment preferences
   - Communication style

6. OVERALL ASSESSMENT:
   - Calculate weighted overall score using these EXACT weights (Experience is PRIMARY, Skills are SECONDARY):
     * Experience: 50% (0.5) - PRIMARY FACTOR
     * Skills: 35% (0.35) - SECONDARY FACTOR
     * Education: 10% (0.1) - Secondary
     * Location: 3% (0.03) - Minimal
     * Cultural Fit: 2% (0.02) - Minimal
   - Formula: overall_score = (experience_score * 0.5) + (skills_score * 0.35) + (education_score * 0.1) + (location_score * 0.03) + (cultural_fit_score * 0.02)
   - Predict success probability based on role-responsibility alignment
   - Estimate retention likelihood considering career trajectory
   - Provide clear recommendation with detailed reasoning
   - Consider the candidate's potential for growth and learning
   - CRITICAL: Experience and Skills are the PRIMARY factors (85% combined weight)
   - CRITICAL: Base experience_score heavily on (MOST IMPORTANT):
     * How well past responsibilities align with job requirements
     * Depth and complexity of relevant experience
     * Progression in responsibility levels
     * Leadership and management experience
     * Problem-solving and decision-making track record
     * Innovation and process improvement experience
     * Team collaboration and stakeholder management skills
   - CRITICAL: A candidate with strong experience and skills should score highly even with minimal education/location/cultural fit
   - CRITICAL: Focus primarily on relevant experience and technical competency for accurate matching

Please provide a comprehensive analysis following the exact structure defined in the ComprehensiveMatchAnalysis model.
"""
        return prompt
    
    def _format_work_history(self, work_history: List[Dict]) -> str:
        """Format comprehensive work history for the prompt."""
        if not work_history:
            return "No work history provided"
        
        formatted = []
        for i, job in enumerate(work_history[:5]):  # Show up to 5 most recent jobs
            title = job.get("title", "Unknown")
            company = job.get("company", "Unknown")
            duration = job.get("duration", "Unknown")
            start_date = job.get("start_date", "")
            end_date = job.get("end_date", "Present")
            description = job.get("description", "No description")
            responsibilities = job.get("responsibilities", [])
            achievements = job.get("achievements", [])
            technologies = job.get("technologies", [])
            team_size = job.get("team_size", "")
            reporting_to = job.get("reporting_to", "")
            
            # Format the job entry
            job_entry = f"{i+1}. {title} at {company}"
            if start_date and end_date:
                job_entry += f" ({start_date} - {end_date})"
            elif duration:
                job_entry += f" ({duration})"
            
            job_entry += f"\n   Company: {company}"
            if team_size:
                job_entry += f"\n   Team Size: {team_size}"
            if reporting_to:
                job_entry += f"\n   Reporting To: {reporting_to}"
            
            job_entry += f"\n   Description: {description}"
            
            # Add responsibilities if available
            if responsibilities and isinstance(responsibilities, list):
                job_entry += f"\n   Key Responsibilities:"
                for resp in responsibilities[:5]:  # Limit to 5 key responsibilities
                    job_entry += f"\n     • {resp}"
            
            # Add achievements if available
            if achievements and isinstance(achievements, list):
                job_entry += f"\n   Key Achievements:"
                for achievement in achievements[:3]:  # Limit to 3 key achievements
                    job_entry += f"\n     • {achievement}"
            
            # Add technologies used if available
            if technologies and isinstance(technologies, list):
                job_entry += f"\n   Technologies Used: {', '.join(technologies[:10])}"  # Limit to 10 technologies
            
            formatted.append(job_entry)
        
        return "\n\n".join(formatted)
    
    def _format_job_responsibilities(self, responsibilities: List[str]) -> str:
        """Format job responsibilities for the prompt."""
        if not responsibilities:
            return "Not specified"
        
        formatted = []
        for i, resp in enumerate(responsibilities[:10], 1):  # Limit to 10 key responsibilities
            formatted.append(f"{i}. {resp}")
        
        return "\n".join(formatted)
    
    def _format_job_requirements(self, requirements: List[str]) -> str:
        """Format job requirements for the prompt."""
        if not requirements:
            return "Not specified"
        
        formatted = []
        for i, req in enumerate(requirements[:10], 1):  # Limit to 10 key requirements
            formatted.append(f"{i}. {req}")
        
        return "\n".join(formatted)
    
    def _format_company_info(self, company_info: Dict) -> str:
        """Format company information for the prompt."""
        if not company_info:
            return "Not specified"
        
        info_parts = []
        if company_info.get("name"):
            info_parts.append(f"Company: {company_info['name']}")
        if company_info.get("size"):
            info_parts.append(f"Company Size: {company_info['size']}")
        if company_info.get("industry"):
            info_parts.append(f"Industry: {company_info['industry']}")
        if company_info.get("description"):
            info_parts.append(f"Description: {company_info['description']}")
        
        return "\n".join(info_parts) if info_parts else "Not specified"
    
    async def _fallback_analysis(
        self, 
        job_posting: Dict[str, Any], 
        candidate: Dict[str, Any],
        weights: Dict[str, float]
    ) -> ComprehensiveMatchAnalysis:
        """
        Fallback analysis when LLM is not available.
        Uses rule-based scoring with basic algorithms.
        """
        try:
            logger.info("🔄 Using fallback rule-based analysis")
            
            # Accurate skills analysis based on actual matches
            job_skills = set(str(skill).lower() for skill in job_posting.get("required_skills", []))
            candidate_skills = set(str(skill).lower() for skill in candidate.get("skills", []))
            
            if not job_skills:
                skills_score = 0.5  # Neutral score if no required skills specified
            else:
                skills_overlap = job_skills.intersection(candidate_skills)
                # Base score is the exact match ratio
                skills_score = len(skills_overlap) / len(job_skills)
                
                # Add small bonus for partial matches (substring matching)
                partial_matches = 0
                for job_skill in job_skills:
                    if job_skill not in skills_overlap:
                        for candidate_skill in candidate_skills:
                            if job_skill in candidate_skill or candidate_skill in job_skill:
                                partial_matches += 0.3  # 30% credit for partial match
                                break
                
                # Add partial match bonus (capped at 0.2)
                partial_bonus = min(partial_matches / len(job_skills), 0.2)
                skills_score = min(skills_score + partial_bonus, 1.0)
            
            # Basic experience analysis
            required_exp = job_posting.get("min_years_experience", 0) or 0
            candidate_exp = candidate.get("total_years_experience", 0) or 0
            # Ensure both values are numbers (not None)
            required_exp = int(required_exp) if required_exp is not None else 0
            candidate_exp = int(float(candidate_exp)) if candidate_exp is not None else 0
            experience_score = min(candidate_exp / max(required_exp, 1), 1.0) if required_exp > 0 else 0.7
            
            # Basic education analysis
            education_score = 0.7  # Default neutral score
            
            # Basic location analysis
            location_score = 0.8  # Default good score for location/remote
            
            # Cultural fit (default)
            cultural_fit_score = 0.6
            
            # Calculate weighted overall score
            overall_score = (
                skills_score * weights.get('skills', 0.4) +
                experience_score * weights.get('experience', 0.3) +
                education_score * weights.get('education', 0.15) +
                location_score * weights.get('location', 0.1) +
                cultural_fit_score * weights.get('cultural_fit', 0.05)
            )
            
            # Create basic skill analysis
            skills_analysis = []
            for skill in job_posting.get("required_skills", []):
                is_present = skill.lower() in [s.lower() for s in candidate.get("skills", [])]
                skills_analysis.append(SkillMatchAnalysis(
                    skill_name=skill,
                    required=True,
                    candidate_level="intermediate" if is_present else "none",
                    match_score=0.8 if is_present else 0.0,
                    reasoning=f"Candidate {'has' if is_present else 'lacks'} {skill} experience",
                    importance_weight=0.8
                ))
            
            return ComprehensiveMatchAnalysis(
                overall_score=overall_score,
                confidence_level=0.6,  # Lower confidence for rule-based
                skills_analysis=skills_analysis,
                experience_analysis=ExperienceMatchAnalysis(
                    years_required=required_exp,
                    years_candidate=float(candidate_exp) if candidate_exp is not None else 0.0,
                    relevant_experience_score=experience_score,
                    leadership_required=False,
                    leadership_present=False,
                    industry_match_score=0.7,
                    role_similarity_score=0.6,
                    reasoning=f"Candidate has {candidate_exp} years vs {required_exp} required"
                ),
                education_analysis=EducationMatchAnalysis(
                    degree_required="Bachelor's",
                    candidate_degree=str(candidate.get("education", {}).get("degree", "Unknown")),
                    field_relevance_score=0.7,
                    level_match_score=0.7,
                    certification_bonus=0.0,
                    reasoning="Basic education assessment - detailed analysis requires LLM"
                ),
                location_analysis=LocationMatchAnalysis(
                    location_preference_score=0.8,
                    remote_work_alignment=0.8,
                    timezone_compatibility=0.9,
                    relocation_willingness=0.7,
                    reasoning="Default location compatibility assessment"
                ),
                skills_score=skills_score,
                experience_score=experience_score,
                education_score=education_score,
                location_score=location_score,
                cultural_fit_score=cultural_fit_score,
                key_strengths=[
                    f"Matches {len(skills_overlap)}/{len(job_skills)} required skills",
                    f"{candidate_exp} years of experience"
                ],
                key_concerns=["Limited analysis without LLM"] if overall_score < 0.7 else [],
                missing_skills=list(job_skills - skills_overlap),
                development_areas=["Detailed assessment requires AI analysis"],
                detailed_reasoning=(
                    f"Rule-based analysis shows {overall_score:.1%} match. "
                    f"Candidate matches {len(skills_overlap)}/{len(job_skills)} required skills "
                    f"and has {candidate_exp} years vs {required_exp} required years of experience."
                ),
                recommendation=(
                    "Strong candidate" if overall_score > 0.8 else
                    "Good candidate" if overall_score > 0.6 else
                    "Consider with caution"
                ),
                success_probability=overall_score * 0.8,  # Conservative estimate
                retention_prediction="medium-term" if overall_score > 0.6 else "uncertain",
                interview_focus_areas=["Technical skills validation", "Experience depth"],
                onboarding_recommendations=["Standard onboarding process"]
            )
            
        except Exception as e:
            logger.error(f"❌ Error in fallback analysis: {e}")
            # Return minimal valid analysis
            return ComprehensiveMatchAnalysis(
                overall_score=0.5,
                confidence_level=0.3,
                skills_analysis=[],
                experience_analysis=ExperienceMatchAnalysis(
                    years_required=0,
                    years_candidate=0,
                    relevant_experience_score=0.5,
                    leadership_required=False,
                    leadership_present=False,
                    industry_match_score=0.5,
                    role_similarity_score=0.5,
                    reasoning="Error in analysis"
                ),
                education_analysis=EducationMatchAnalysis(
                    degree_required="Unknown",
                    candidate_degree="Unknown",
                    field_relevance_score=0.5,
                    level_match_score=0.5,
                    certification_bonus=0.0,
                    reasoning="Error in analysis"
                ),
                location_analysis=LocationMatchAnalysis(
                    location_preference_score=0.5,
                    remote_work_alignment=0.5,
                    timezone_compatibility=0.5,
                    relocation_willingness=0.5,
                    reasoning="Error in analysis"
                ),
                skills_score=0.5,
                experience_score=0.5,
                education_score=0.5,
                location_score=0.5,
                cultural_fit_score=0.5,
                key_strengths=["Unable to analyze"],
                key_concerns=["Analysis error occurred"],
                missing_skills=[],
                development_areas=[],
                detailed_reasoning=f"Analysis failed: {str(e)}",
                recommendation="Unable to assess - technical error",
                success_probability=0.5,
                retention_prediction="unknown",
                interview_focus_areas=["Manual assessment needed"],
                onboarding_recommendations=["Standard process"]
            )
    
    async def analyze_single_match(
        self,
        job_posting: Dict[str, Any],
        candidate: Dict[str, Any],
        custom_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Analyze a single candidate-job match with detailed reasoning.
        
        Args:
            job_posting: Job requirements and description
            candidate: Candidate profile
            custom_weights: Custom scoring weights
            
        Returns:
            Detailed match analysis for single candidate
        """
        try:
            weights = custom_weights or self.default_weights
            
            logger.info(f"🔍 Analyzing single match: {candidate.get('name', 'Unknown')} for {job_posting.get('title', 'Unknown Position')}")
            
            analysis = await self._analyze_candidate_fit_comprehensive(
                job_posting, candidate, weights
            )
            
            return {
                "candidate_id": candidate.get("id"),
                "candidate_name": candidate.get("name"),
                "job_id": job_posting.get("id"),
                "job_title": job_posting.get("title"),
                "analysis": analysis.dict(),
                "timestamp": datetime.now().isoformat(),
                "weights_used": weights
            }
            
        except Exception as e:
            logger.error(f"❌ Error in single match analysis: {e}")
            return {
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def get_matching_insights(
        self, 
        job_postings: List[Dict[str, Any]], 
        candidates: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate AI-powered insights about matching trends and patterns.
        
        Args:
            job_postings: List of job postings
            candidates: List of candidates
            
        Returns:
            Comprehensive matching insights and analytics
        """
        try:
            logger.info("📈 Generating AI-powered matching insights...")
            
            # Collect all skills from jobs and candidates
            job_skills = set()
            candidate_skills = set()
            
            for job in job_postings:
                job_skills.update(job.get("required_skills", []))
                job_skills.update(job.get("preferred_skills", []))
            
            for candidate in candidates:
                candidate_skills.update(candidate.get("skills", []))
            
            # Calculate skill gaps and overlaps
            skill_overlap = job_skills.intersection(candidate_skills)
            skill_gaps = job_skills - candidate_skills
            candidate_surplus_skills = candidate_skills - job_skills
            
            # Calculate experience distribution
            experience_levels = [candidate.get("total_years_experience", 0) for candidate in candidates]
            avg_experience = sum(experience_levels) / len(experience_levels) if experience_levels else 0
            
            # Required experience levels from jobs
            required_experience = [job.get("min_years_experience", 0) for job in job_postings]
            avg_required_exp = sum(required_experience) / len(required_experience) if required_experience else 0
            
            insights = {
                "summary": {
                    "total_jobs": len(job_postings),
                    "total_candidates": len(candidates),
                    "unique_skills_in_demand": len(job_skills),
                    "unique_skills_available": len(candidate_skills),
                    "skill_overlap_rate": len(skill_overlap) / len(job_skills) if job_skills else 0,
                    "average_candidate_experience": round(avg_experience, 1),
                    "average_required_experience": round(avg_required_exp, 1),
                    "experience_gap": round(avg_required_exp - avg_experience, 1)
                },
                "skill_analysis": {
                    "top_skills_in_demand": list(job_skills)[:10],
                    "critical_skill_gaps": list(skill_gaps)[:10],
                    "candidate_surplus_skills": list(candidate_surplus_skills)[:10],
                    "skill_overlap": list(skill_overlap)[:10]
                },
                "market_insights": {
                    "talent_availability": "high" if len(candidates) > len(job_postings) * 3 else "moderate" if len(candidates) > len(job_postings) else "low",
                    "competition_level": "high" if len(job_postings) > len(candidates) else "moderate",
                    "experience_alignment": "good" if abs(avg_experience - avg_required_exp) < 2 else "poor"
                },
                "recommendations": self._generate_market_recommendations(
                    job_skills, candidate_skills, skill_gaps, avg_experience, avg_required_exp
                ),
                "generated_at": datetime.now().isoformat()
            }
            
            logger.info("✅ Matching insights generated successfully")
            return insights
            
        except Exception as e:
            logger.error(f"❌ Error generating matching insights: {e}")
            return {
                "error": str(e),
                "generated_at": datetime.now().isoformat()
            }
    
    def _generate_market_recommendations(
        self,
        job_skills: set,
        candidate_skills: set,
        skill_gaps: set,
        avg_experience: float,
        avg_required_exp: float
    ) -> List[str]:
        """Generate market recommendations based on analysis."""
        recommendations = []
        
        if skill_gaps:
            recommendations.append(f"Focus on recruiting candidates with {', '.join(list(skill_gaps)[:3])} skills")
        
        if avg_experience < avg_required_exp:
            recommendations.append("Consider offering training programs to bridge experience gaps")
        
        if len(skill_gaps) > len(job_skills) * 0.5:
            recommendations.append("Consider adjusting job requirements or expanding candidate search criteria")
        
        if avg_experience > avg_required_exp + 2:
            recommendations.append("Leverage overqualified candidates for senior roles or mentorship")
        
        recommendations.append("Implement skills-based hiring to identify transferable competencies")
        
        return recommendations
    
    async def match_candidates_to_job(
        self,
        job_id: str,
        resume_ids: Optional[List[str]] = None,
        custom_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Match candidates to a specific job using database queries and AI analysis.
        
        Args:
            job_id: ID of the job to match against
            resume_ids: Optional list of specific resume IDs to match
            custom_weights: Custom weights for scoring components
            
        Returns:
            Dictionary with matching results and metadata
        """
        try:
            if not self.initialized:
                await self.initialize()
            
            logger.info(f"🔍 Starting job matching for job {job_id}")
            
            # Import database dependencies
            from database.session import get_db
            from database.models import Job, Resume
            from sqlalchemy import select
            
            # Get job data from database
            job_data = None
            async for db in get_db():
                try:
                    job_result = await db.execute(select(Job).where(Job.id == job_id))
                    job = job_result.scalar_one_or_none()
                    if job:
                        job_data = {
                            "id": str(job.id),
                            "title": job.title,
                            "description": job.description,
                            "required_skills": job.required_skills or [],
                            "preferred_skills": job.preferred_skills or [],
                            "min_years_experience": job.min_years_experience,
                            "education_requirements": job.education_requirements or {},
                            "location": job.location,
                            "remote_option": job.remote_option,
                            "employment_type": job.employment_type
                        }
                    break
                except Exception as e:
                    logger.error(f"❌ Database error getting job: {e}")
                    break
            
            if not job_data:
                return {
                    "error": "Job not found",
                    "matches": [],
                    "total_jobs_evaluated": 0,
                    "confidence": 0.0
                }
            
            # Get candidate data from database
            candidates_data = []
            async for db in get_db():
                try:
                    if resume_ids:
                        # Match specific resumes
                        query = select(Resume).where(Resume.id.in_(resume_ids))
                    else:
                        # Match all resumes in the organization
                        query = select(Resume).where(Resume.organization_id == job.organization_id)
                    
                    resumes_result = await db.execute(query)
                    resumes = resumes_result.scalars().all()
                    
                    for resume in resumes:
                        ai_analysis = resume.ai_analysis or {}
                        personal_info = ai_analysis.get("personal_info", {})
                        
                        candidate_data = {
                            "id": str(resume.id),
                            "name": resume.candidate_name or personal_info.get("full_name") or "Unknown",
                            "email": resume.candidate_email or personal_info.get("email") or "",
                            "skills": ai_analysis.get("skills", []),
                            "total_years_experience": ai_analysis.get("total_years_experience", 0),
                            "work_history": ai_analysis.get("work_history", []),
                            "education": ai_analysis.get("education", {}),
                            "location": ai_analysis.get("personal_info", {}).get("location", ""),
                            "ai_analysis": ai_analysis
                        }
                        candidates_data.append(candidate_data)
                    break
                except Exception as e:
                    logger.error(f"❌ Database error getting candidates: {e}")
                    break
            
            if not candidates_data:
                return {
                    "error": "No candidates found",
                    "matches": [],
                    "total_jobs_evaluated": 0,
                    "confidence": 0.0
                }
            
            # Perform AI-powered matching
            matches = await self.match_candidates(
                job_posting=job_data,
                candidates=candidates_data,
                max_matches=50,  # Allow more matches for comprehensive results
                custom_weights=custom_weights
            )
            
            # Calculate overall confidence
            if matches:
                avg_confidence = sum(match.get("confidence_level", 0.5) for match in matches) / len(matches)
            else:
                avg_confidence = 0.0
            
            result = {
                "job_id": job_id,
                "job_title": job_data["title"],
                "matches": matches,
                "total_candidates_evaluated": len(candidates_data),
                "total_matches_found": len(matches),
                "confidence": avg_confidence,
                "matching_metadata": {
                    "weights_used": custom_weights or self.default_weights,
                    "matching_threshold": self.config["matching_threshold"],
                    "analysis_timestamp": datetime.now().isoformat()
                }
            }
            
            logger.info(f"✅ Job matching completed: {len(matches)} matches found")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error in job matching: {e}")
            return {
                "error": str(e),
                "matches": [],
                "total_jobs_evaluated": 0,
                "confidence": 0.0
            }

    async def shutdown(self) -> None:
        """Shutdown the job matching agent."""
        logger.info("🔄 Shutting down Job Matching Agent...")
        if hasattr(self, 'llm') and self.llm:
            # Clean up LLM connections if needed
            pass
        self.initialized = False
        logger.info("✅ Job Matching Agent shutdown complete")
"""
AI Recruit - Job Copilot Agent
Specialized AI agent for interactive job description queries and assistance.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from enum import Enum
import asyncio

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field
try:
    from crewai import Agent, Task, Crew, Process
except ImportError:
    Agent = Task = Crew = Process = None

try:
    import instructor
except ImportError:
    instructor = None

from core.config import Settings

logger = logging.getLogger(__name__)

# Log import warnings after logger is available
if Agent is None:
    logger.warning("CrewAI not available, some features may be limited")
if instructor is None:
    logger.warning("Instructor not available, falling back to basic LLM responses")


class QuestionType(str, Enum):
    """Types of questions the copilot can handle."""
    SKILL_DETAILS = "skill_details"
    EXPERIENCE_REQUIREMENTS = "experience_requirements"
    EDUCATION_REQUIREMENTS = "education_requirements"
    INTERVIEW_QUESTIONS = "interview_questions"
    COMPENSATION_INFO = "compensation_info"
    COMPANY_CULTURE = "company_culture"
    ROLE_RESPONSIBILITIES = "role_responsibilities"
    CAREER_PROGRESSION = "career_progression"
    TEAM_STRUCTURE = "team_structure"
    WORK_ENVIRONMENT = "work_environment"
    APPLICATION_PROCESS = "application_process"
    COMPARISON_ANALYSIS = "comparison_analysis"
    CANDIDATE_EVALUATION = "candidate_evaluation"
    GENERAL_INQUIRY = "general_inquiry"


class CopilotResponse(BaseModel):
    """Response model for copilot queries."""
    answer: str = Field(..., description="The main answer to the user's question")
    question_type: QuestionType = Field(..., description="Classified type of the question")
    confidence_score: float = Field(..., description="Confidence in the answer (0-1)")
    supporting_evidence: List[str] = Field(default_factory=list, description="Evidence from JD supporting the answer")
    suggestions: List[str] = Field(default_factory=list, description="Additional helpful suggestions")
    follow_up_questions: List[str] = Field(default_factory=list, description="Suggested follow-up questions")
    actionable_insights: List[str] = Field(default_factory=list, description="Actionable insights for the recruiter")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class InterviewQuestion(BaseModel):
    """Model for generated interview questions."""
    question: str = Field(..., description="The interview question")
    category: str = Field(..., description="Category (technical, behavioral, situational, etc.)")
    difficulty_level: str = Field(..., description="Difficulty level (entry, mid, senior)")
    expected_answer_points: List[str] = Field(default_factory=list, description="Key points expected in answer")
    follow_up_questions: List[str] = Field(default_factory=list, description="Potential follow-up questions")


class InterviewQuestionsResponse(BaseModel):
    """Response model for interview question generation."""
    questions: List[InterviewQuestion] = Field(..., description="Generated interview questions")
    total_questions: int = Field(..., description="Total number of questions generated")
    question_distribution: Dict[str, int] = Field(default_factory=dict, description="Distribution by category")
    interview_duration_estimate: str = Field(..., description="Estimated interview duration")
    preparation_tips: List[str] = Field(default_factory=list, description="Tips for conducting the interview")


class SkillAnalysisResponse(BaseModel):
    """Response model for detailed skill analysis."""
    skill_name: str = Field(..., description="Name of the skill being analyzed")
    importance_level: str = Field(..., description="Importance level in the role")
    proficiency_required: str = Field(..., description="Required proficiency level")
    years_experience_needed: Optional[int] = Field(None, description="Years of experience typically needed")
    related_skills: List[str] = Field(default_factory=list, description="Related or complementary skills")
    industry_demand: str = Field(..., description="Market demand for this skill")
    learning_resources: List[str] = Field(default_factory=list, description="Suggested learning resources")
    certification_options: List[str] = Field(default_factory=list, description="Relevant certifications")


class JobCopilotAgent:
    """
    AI-powered copilot for interactive job description analysis and assistance.
    Provides intelligent answers to recruiter questions about job postings.
    """
    
    def __init__(self, llm: BaseChatModel, settings: Settings):
        self.llm = llm
        self.settings = settings
        self._initialized = False
        
        # Configure environment for CrewAI to use correct LLM provider
        self._configure_llm_environment()
        
        # Conversation memory for contextual awareness
        self.conversation_history: Dict[str, List[Dict]] = {}
        
        # Question classification prompts
        self.classification_prompt = ChatPromptTemplate.from_messages([
            ("system", self._get_classification_system_prompt()),
            ("human", "Question: {question}\nJob Description: {job_description}")
        ])
        
        # Response generation prompts
        self.response_prompt = ChatPromptTemplate.from_messages([
            ("system", self._get_response_system_prompt()),
            ("human", self._get_response_human_prompt())
        ])
    
    def _configure_llm_environment(self):
        """Configure environment variables for CrewAI to use the correct LLM provider."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔧 Configuring Job Copilot environment for provider: {provider}")
            
            if provider == "azure_openai":
                # Set Azure OpenAI environment variables for CrewAI
                endpoint = config.get("endpoint", "")
                api_key = config.get("api_key", "")
                api_version = config.get("api_version", "2024-02-15-preview")
                deployment_name = config.get("deployment_name", "")
                
                # Set environment variables for Azure OpenAI
                os.environ["OPENAI_API_TYPE"] = "azure"
                os.environ["OPENAI_API_VERSION"] = api_version
                os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint
                os.environ["AZURE_OPENAI_API_KEY"] = api_key
                os.environ["AZURE_API_KEY"] = api_key
                os.environ["OPENAI_API_KEY"] = api_key
                os.environ["AZURE_OPENAI_BASE"] = endpoint
                os.environ["AZURE_API_BASE"] = endpoint
                os.environ["OPENAI_API_BASE"] = endpoint
                os.environ["OPENAI_BASE_URL"] = endpoint
                os.environ["AZURE_OPENAI_RESOURCE"] = endpoint.split("//")[1].split(".")[0] if "//" in endpoint else ""
                
                # Deployment name for Azure - use gpt-4.1
                if deployment_name:
                    os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = deployment_name
                    os.environ["OPENAI_MODEL_NAME"] = "gpt-4.1"  # Use newer model
                    os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment_name
                    os.environ["OPENAI_DEPLOYMENT_NAME"] = deployment_name
                    
                # Additional Azure OpenAI specific environment variables
                os.environ["AZURE_OPENAI_CHAT_COMPLETIONS_DEPLOYMENT"] = deployment_name
                os.environ["AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT"] = deployment_name
                
                # Disable LangSmith tracing to avoid 403 errors
                os.environ["LANGCHAIN_TRACING_V2"] = "false"
                os.environ.pop("LANGSMITH_API_KEY", None)
                
                logger.info(f"✅ Azure OpenAI environment configured for Job Copilot")
                
            elif provider == "openai":
                # Standard OpenAI configuration
                if config.get("api_key"):
                    os.environ["OPENAI_API_KEY"] = config["api_key"]
                if config.get("organization"):
                    os.environ["OPENAI_ORGANIZATION"] = config["organization"]
                
                # Remove Azure-specific variables if they exist
                azure_vars = ["OPENAI_API_TYPE", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT_NAME"]
                for var in azure_vars:
                    os.environ.pop(var, None)
                
                logger.info("✅ OpenAI environment configured for Job Copilot")
                
            elif provider == "anthropic":
                if config.get("api_key"):
                    os.environ["ANTHROPIC_API_KEY"] = config["api_key"]
                logger.info("✅ Anthropic environment configured for Job Copilot")
                
        except Exception as e:
            logger.error(f"❌ Failed to configure LLM environment for Job Copilot: {str(e)}")
    
    async def initialize(self):
        """Initialize the copilot agent."""
        try:
            logger.info("🤖 Initializing Job Copilot Agent")
            
            # Verify LLM configuration
            self._verify_llm_configuration()
            
            self._initialized = True
            logger.info("✅ Job Copilot Agent initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Job Copilot Agent: {str(e)}")
            raise
    
    def _verify_llm_configuration(self):
        """Verify that the LLM configuration is correct and log details."""
        try:
            llm_config = self.settings.get_llm_config()
            provider = llm_config["provider"]
            config = llm_config["config"]
            
            logger.info(f"🔍 Verifying Job Copilot LLM Configuration:")
            logger.info(f"   Provider: {provider}")
            logger.info(f"   Model: {config.get('model', 'Not specified')}")
            
            # Log LLM instance type for debugging
            llm_type = type(self.llm).__name__
            logger.info(f"   LLM Instance Type: {llm_type}")
            
        except Exception as e:
            logger.error(f"❌ Failed to verify LLM configuration: {str(e)}")
    
    async def ask_question(
        self,
        question: str,
        job_data: Dict[str, Any],
        session_id: str = "default",
        context: Optional[Dict[str, Any]] = None
    ) -> CopilotResponse:
        """
        Process a user question about a job description.
        
        Args:
            question: The user's question
            job_data: Complete job data including description, requirements, etc.
            session_id: Session identifier for conversation context
            context: Additional context for the question
            
        Returns:
            CopilotResponse with answer and metadata
        """
        if not self._initialized:
            await self.initialize()
        
        try:
            logger.info(f"🤔 Processing copilot question: {question[:100]}...")
            
            # Prepare job context
            job_context = self._prepare_job_context(job_data)
            
            # Classify question type
            question_type = await self._classify_question(question, job_context)
            
            # Generate response based on question type
            response = await self._generate_response(
                question, job_context, question_type, session_id, context
            )
            
            # Store in conversation history
            self._update_conversation_history(session_id, question, response)
            
            logger.info(f"✅ Generated copilot response with {response.confidence_score:.2f} confidence")
            return response
            
        except Exception as e:
            logger.error(f"❌ Error processing copilot question: {str(e)}")
            # Return error response
            return CopilotResponse(
                answer=f"I apologize, but I encountered an error while processing your question. Please try rephrasing or ask a different question.",
                question_type=QuestionType.GENERAL_INQUIRY,
                confidence_score=0.0,
                supporting_evidence=[],
                suggestions=["Try asking a more specific question about the job requirements"],
                follow_up_questions=[],
                actionable_insights=[],
                metadata={"error": str(e)}
            )
    
    async def generate_interview_questions(
        self,
        job_data: Dict[str, Any],
        question_count: int = 10,
        focus_areas: Optional[List[str]] = None,
        difficulty_level: str = "mixed"
    ) -> InterviewQuestionsResponse:
        """
        Generate interview questions based on job description.
        
        Args:
            job_data: Complete job data
            question_count: Number of questions to generate
            focus_areas: Specific areas to focus on
            difficulty_level: Difficulty level (entry, mid, senior, mixed)
            
        Returns:
            InterviewQuestionsResponse with generated questions
        """
        if not self._initialized:
            await self.initialize()
        
        try:
            logger.info(f"🎤 Generating {question_count} interview questions")
            
            job_context = self._prepare_job_context(job_data)
            
                        # Use comprehensive JSON-based approach for interview questions
            system_prompt = self._get_interview_questions_system_prompt()
            additional_instructions = """
CRITICAL: You MUST analyze the specific job description provided and generate questions that are DIRECTLY RELATED to the technologies, skills, and requirements mentioned in that specific job.

DO NOT generate generic questions. Every question must reference specific technologies, frameworks, tools, or concepts mentioned in the job description.

You MUST respond with ONLY valid JSON. No markdown blocks, no explanations, no additional text.

EXACT JSON FORMAT REQUIRED:
{{
  "questions": [
    {{
      "question": "Specific question about [TECHNOLOGY/SKILL from job description]",
      "category": "technical",
      "difficulty": "mid",
      "expected_answer_points": [
        "Specific technical detail about [EXACT TECHNOLOGY from job]",
        "Practical application of [SPECIFIC FRAMEWORK from job]",
        "Experience with [EXACT TOOL/METHOD from job description]"
      ],
      "follow_up_questions": [
        "Follow-up about specific [TECHNOLOGY] implementation",
        "Deeper question about [SPECIFIC SKILL] experience"
      ]
    }}
  ],
  "total_questions": """ + str(question_count) + """,
  "question_distribution": {{"technical": 12, "behavioral": 4, "situational": 4}},
  "interview_duration_estimate": "90-120 minutes",
  "preparation_tips": [
    "Review specific technologies mentioned in job description",
    "Prepare scenarios based on actual job responsibilities",
    "Focus on practical experience with required tools"
  ]
}}}}

ABSOLUTE REQUIREMENTS:
- Every question MUST reference specific technologies, frameworks, or skills from the job description
- NO generic questions allowed
- Use exact technology names, frameworks, and tools mentioned in the job
- Expected answer points must include specific technical details from the job requirements
- Questions must be tailored to the seniority level and role type specified

RESPOND WITH ONLY THE JSON OBJECT."""
            
            prompt = ChatPromptTemplate.from_messages([
                ("system", system_prompt + additional_instructions),
                ("human", f"""
                ANALYZE THIS SPECIFIC JOB AND GENERATE CUSTOMIZED INTERVIEW QUESTIONS:

                {job_context.replace('{', '{{').replace('}', '}}')}

                STRICT REQUIREMENTS:
                - Generate {question_count} questions SPECIFIC to this job description
                - Every question must reference actual technologies/skills mentioned above
                - Use exact technology names, frameworks, and tools from the job description
                - Tailor difficulty to the role level: {difficulty_level}
                - NO generic questions allowed
                
                QUESTION CATEGORIES:
                - Technical: Questions about specific technologies mentioned in job
                - Behavioral: Questions related to actual job responsibilities 
                - Situational: Scenarios based on real job tasks
                
                ANSWER GUIDANCE:
                - Include 3-4 specific expected answer points per question
                - Reference exact technologies/skills from job description
                - Mention specific technical details and practical applications
                
                OUTPUT: Return only valid JSON with the exact structure specified above.
                """)
            ])
            
            try:
                # Get comprehensive interview questions from LLM
                logger.info(f"🎯 Generating interview questions for job: {job_context[:200].replace('{', '{{').replace('}', '}}')}...")
                llm_response = await self.llm.ainvoke(prompt.format_messages())
                response_text = llm_response.content.strip()
                
                logger.info(f"📝 LLM response length: {len(response_text)} characters")
                logger.debug(f"📝 LLM raw response (first 500 chars): {response_text[:500]}")
                
                # Clean up markdown if present
                if '```json' in response_text:
                    response_text = response_text.split('```json')[1].split('```')[0].strip()
                elif '```' in response_text:
                    response_text = response_text.split('```')[1].strip()
                
                # Try to parse the JSON response
                if response_text.startswith('{') and response_text.endswith('}'):
                    try:
                        parsed_data = json.loads(response_text)
                        logger.info(f"✅ Successfully parsed JSON with {len(parsed_data.get('questions', []))} questions")
                        
                        # Convert to InterviewQuestion objects
                        questions = []
                        for q_data in parsed_data.get("questions", []):
                            question = InterviewQuestion(
                                question=q_data.get("question", ""),
                                category=q_data.get("category", "general"),
                                difficulty_level=q_data.get("difficulty", difficulty_level),
                                expected_answer_points=q_data.get("expected_answer_points", []),
                                follow_up_questions=q_data.get("follow_up_questions", [])
                            )
                            questions.append(question)
                        
                        response = InterviewQuestionsResponse(
                            questions=questions,
                            total_questions=parsed_data.get("total_questions", len(questions)),
                            question_distribution=parsed_data.get("question_distribution", {}),
                            interview_duration_estimate=parsed_data.get("interview_duration_estimate", "60-90 minutes"),
                            preparation_tips=parsed_data.get("preparation_tips", [])
                        )
                        
                    except json.JSONDecodeError as e:
                        # Log the JSON error and fallback
                        logger.error(f"❌ JSON parsing failed: {str(e)}")
                        logger.error(f"❌ Response text that failed parsing: {response_text[:1000]}")
                        response = self._create_job_specific_fallback(job_data, question_count, difficulty_level)
                        
                else:
                    # Fallback if response doesn't look like JSON - try simplified prompt
                    logger.warning(f"⚠️ Response doesn't look like JSON: starts with '{response_text[:50]}', ends with '{response_text[-50:]}'")
                    logger.info("🔄 Trying simplified prompt approach...")
                    
                    try:
                        # Try a much simpler approach
                        simple_prompt = ChatPromptTemplate.from_messages([
                            ("system", """Generate interview questions based on the job description. Return only JSON:
{{"questions": [{{"question": "...", "category": "technical", "difficulty": "mid", "expected_answer_points": ["...", "...", "..."], "follow_up_questions": ["...", "..."]}}], "total_questions": 10, "question_distribution": {{"technical": 6, "behavioral": 4}}, "interview_duration_estimate": "60-90 minutes", "preparation_tips": ["..."]}}"""),
                            ("human", f"Job: {job_context[:800].replace('{', '{{').replace('}', '}}')}\nGenerate {question_count} specific questions for this exact job. Reference actual technologies and skills mentioned.")
                        ])
                        
                        retry_response = await self.llm.ainvoke(simple_prompt.format_messages())
                        retry_text = retry_response.content.strip()
                        
                        # Clean and try to parse
                        if '```' in retry_text:
                            retry_text = retry_text.split('```')[1].strip() if '```json' not in retry_text else retry_text.split('```json')[1].split('```')[0].strip()
                        
                        if retry_text.startswith('{') and retry_text.endswith('}'):
                            retry_data = json.loads(retry_text)
                            logger.info("✅ Simplified prompt succeeded!")
                            
                            # Convert to response format
                            questions = []
                            for q_data in retry_data.get("questions", []):
                                questions.append(InterviewQuestion(
                                    question=q_data.get("question", ""),
                                    category=q_data.get("category", "general"),
                                    difficulty_level=q_data.get("difficulty", difficulty_level),
                                    expected_answer_points=q_data.get("expected_answer_points", []),
                                    follow_up_questions=q_data.get("follow_up_questions", [])
                                ))
                            
                            response = InterviewQuestionsResponse(
                                questions=questions,
                                total_questions=retry_data.get("total_questions", len(questions)),
                                question_distribution=retry_data.get("question_distribution", {}),
                                interview_duration_estimate=retry_data.get("interview_duration_estimate", "60-90 minutes"),
                                preparation_tips=retry_data.get("preparation_tips", [])
                            )
                        else:
                            raise Exception("Simplified prompt also failed")
                            
                    except Exception as retry_error:
                        logger.error(f"❌ Simplified prompt also failed: {retry_error}")
                        response = self._create_job_specific_fallback(job_data, question_count, difficulty_level)
                    
            except Exception as e:
                logger.error(f"❌ Error generating interview questions: {str(e)}")
                logger.error(f"❌ Job context length: {len(job_context) if 'job_context' in locals() else 'N/A'}")
                response = self._create_job_specific_fallback(job_data, question_count, difficulty_level)
            
            logger.info(f"✅ Generated {len(response.questions)} interview questions")
            return response
            
        except Exception as e:
            logger.error(f"❌ Error generating interview questions: {str(e)}")
            raise
    
    async def analyze_skill_details(
        self,
        skill_name: str,
        job_data: Dict[str, Any]
    ) -> SkillAnalysisResponse:
        """
        Provide detailed analysis of a specific skill mentioned in the job.
        
        Args:
            skill_name: Name of the skill to analyze
            job_data: Complete job data
            
        Returns:
            SkillAnalysisResponse with detailed skill analysis
        """
        if not self._initialized:
            await self.initialize()
        
        try:
            logger.info(f"🔍 Analyzing skill: {skill_name}")
            
            job_context = self._prepare_job_context(job_data)
            
            # Use comprehensive JSON-based approach for skill analysis
            prompt = ChatPromptTemplate.from_messages([
                ("system", f"""{self._get_skill_analysis_system_prompt()}

You MUST respond with ONLY valid JSON in this exact format:
{{
  "skill_name": "{{skill_name}}",
  "importance_level": "critical/high/medium/low",
  "proficiency_required": "beginner/intermediate/advanced/expert",
  "years_experience_needed": 3,
  "related_skills": ["skill1", "skill2", "skill3"],
  "industry_demand": "very_high/high/medium/low",
  "learning_resources": ["resource1", "resource2", "resource3"],
  "certification_options": ["cert1", "cert2"],
  "detailed_analysis": "Comprehensive analysis of the skill in context of this specific role",
  "evaluation_methods": ["How to assess this skill during interviews"],
  "market_salary_impact": "How this skill affects compensation",
  "skill_combinations": ["What other skills work well with this one"]
}}

NO ADDITIONAL TEXT. ONLY THE JSON OBJECT."""),
                ("human", f"""
                Analyze the skill "{skill_name}" in the context of this job:

                Job Context:
                {job_context}

                ANALYSIS REQUIREMENTS:
                1. Determine exact importance level based on job responsibilities and requirements
                2. Specify required proficiency level and typical years of experience needed
                3. Identify all related and complementary skills for this role
                4. Assess current market demand and industry trends for this skill
                5. Provide specific, high-quality learning resources and certifications
                6. Explain how this skill relates to daily job responsibilities
                7. Suggest concrete methods for evaluating this skill during interviews
                8. Analyze market salary impact and competitive positioning
                9. Identify synergistic skill combinations that enhance this core skill

                Provide deep, actionable insights that help recruiters understand exactly what to look for.
                """)
            ])
            
            try:
                # Get comprehensive skill analysis from LLM
                llm_response = await self.llm.ainvoke(prompt.format_messages())
                response_text = llm_response.content.strip()
                
                # Try to parse the JSON response
                if response_text.startswith('{') and response_text.endswith('}'):
                    try:
                        parsed_data = json.loads(response_text)
                        
                        response = SkillAnalysisResponse(
                            skill_name=parsed_data.get("skill_name", skill_name),
                            importance_level=parsed_data.get("importance_level", "high"),
                            proficiency_required=parsed_data.get("proficiency_required", "intermediate"),
                            years_experience_needed=parsed_data.get("years_experience_needed"),
                            related_skills=parsed_data.get("related_skills", []),
                            industry_demand=parsed_data.get("industry_demand", "medium"),
                            learning_resources=parsed_data.get("learning_resources", []),
                            certification_options=parsed_data.get("certification_options", [])
                        )
                        
                    except json.JSONDecodeError:
                        # Fallback to basic response if JSON parsing fails
                        response = self._create_fallback_skill_response(skill_name)
                        
                else:
                    # Fallback if response doesn't look like JSON
                    response = self._create_fallback_skill_response(skill_name)
                    
            except Exception as e:
                logger.error(f"Error in skill analysis: {e}")
                response = self._create_fallback_skill_response(skill_name)
            
            logger.info(f"✅ Completed skill analysis for {skill_name}")
            return response
            
        except Exception as e:
            logger.error(f"❌ Error analyzing skill {skill_name}: {str(e)}")
            raise
    
    def _create_job_specific_fallback(self, job_data: Dict[str, Any], question_count: int, difficulty_level: str) -> InterviewQuestionsResponse:
        """Create job-specific fallback questions when LLM fails."""
        
        # Extract key information from job data
        job_title = job_data.get("title", "Software Developer")
        required_skills = []
        
        # Try to extract skills from AI analysis
        ai_analysis = job_data.get("ai_analysis", {})
        required_skills.extend(ai_analysis.get("required_skills", []))
        required_skills.extend(ai_analysis.get("preferred_skills", []))
        
        # If no skills found, try to extract from description and requirements
        if not required_skills:
            description_text = f"{job_data.get('description', '')} {job_data.get('requirements', '')}"
            # Basic skill extraction from text
            common_skills = ["Python", "JavaScript", "Java", "React", "Node.js", "SQL", "AWS", "Docker", "Git", "Kubernetes", "MongoDB", "PostgreSQL", "TypeScript", "Angular", "Vue.js", "Flask", "Django", "Spring Boot", "Microservices", "REST API", "GraphQL"]
            for skill in common_skills:
                if skill.lower() in description_text.lower():
                    required_skills.append(skill)
        
        # Limit to top skills to avoid too many
        required_skills = required_skills[:6] if required_skills else ["the required technologies"]
        
        # Create job-specific questions
        job_specific_questions = []
        
        # Technical questions based on actual skills
        for i, skill in enumerate(required_skills[:4]):
            job_specific_questions.append(InterviewQuestion(
                question=f"Can you describe your experience with {skill} and how you've used it in previous projects?",
                category="technical",
                difficulty_level=difficulty_level,
                expected_answer_points=[
                    f"Specific hands-on experience with {skill}",
                    f"Real project examples using {skill}",
                    f"Technical challenges solved using {skill}",
                    f"Best practices and optimization techniques for {skill}"
                ],
                follow_up_questions=[
                    f"What was the most challenging aspect of working with {skill}?",
                    f"How do you stay updated with {skill} developments?"
                ]
            ))
        
        # Role-specific behavioral questions
        if "senior" in job_title.lower() or "lead" in job_title.lower():
            job_specific_questions.append(InterviewQuestion(
                question=f"As a {job_title}, how do you approach mentoring junior team members and ensuring code quality?",
                category="behavioral",
                difficulty_level=difficulty_level,
                expected_answer_points=[
                    "Mentoring strategies and experience",
                    "Code review practices and standards",
                    "Knowledge sharing and team development",
                    "Technical leadership examples"
                ],
                follow_up_questions=[
                    "Can you give an example of how you helped a junior developer grow?",
                    "How do you handle technical disagreements in your team?"
                ]
            ))
        else:
            job_specific_questions.append(InterviewQuestion(
                question=f"Describe a challenging project you've worked on that relates to this {job_title} position.",
                category="behavioral",
                difficulty_level=difficulty_level,
                expected_answer_points=[
                    "Project complexity and scope",
                    "Technical challenges and solutions",
                    "Collaboration and teamwork",
                    "Results and lessons learned"
                ],
                follow_up_questions=[
                    "What would you do differently if you could start over?",
                    "How did you handle any obstacles during the project?"
                ]
            ))
        
        # Situational question based on job
        job_specific_questions.append(InterviewQuestion(
            question=f"If you joined our team as a {job_title}, how would you approach learning our codebase and contributing effectively?",
            category="situational",
            difficulty_level=difficulty_level,
            expected_answer_points=[
                "Code exploration and learning strategies",
                "Communication with team members",
                "Gradual contribution approach",
                "Documentation and knowledge gathering"
            ],
            follow_up_questions=[
                "How do you typically debug and understand unfamiliar code?",
                "What questions would you ask in your first week?"
            ]
        ))
        
        # Extend list to match requested count
        final_questions = job_specific_questions[:question_count] if len(job_specific_questions) >= question_count else job_specific_questions
        
        # Create distribution
        tech_count = len([q for q in final_questions if q.category == "technical"])
        behavioral_count = len([q for q in final_questions if q.category == "behavioral"])
        situational_count = len([q for q in final_questions if q.category == "situational"])
        
        return InterviewQuestionsResponse(
            questions=final_questions,
            total_questions=len(final_questions),
            question_distribution={
                "technical": tech_count,
                "behavioral": behavioral_count,
                "situational": situational_count
            },
            interview_duration_estimate=f"{len(final_questions) * 8}-{len(final_questions) * 12} minutes",
            preparation_tips=[
                f"Review the specific technologies mentioned in the {job_title} job description",
                "Prepare to discuss technical challenges relevant to the role",
                "Focus on practical experience with the required skills",
                "Be ready to provide specific examples and project details"
            ]
        )

    def _create_fallback_interview_response(self, question_count: int, difficulty_level: str) -> InterviewQuestionsResponse:
        """Create a fallback interview response when JSON parsing fails."""
        
        # Create some basic questions as fallback
        basic_questions = [
            InterviewQuestion(
                question="Can you walk me through your experience with the main technologies required for this role?",
                category="technical",
                difficulty_level=difficulty_level,
                expected_answer_points=["Specific technology experience", "Project examples", "Years of experience"],
                follow_up_questions=["Can you describe a challenging project using these technologies?"]
            ),
            InterviewQuestion(
                question="Describe a complex problem you've solved in your previous role.",
                category="behavioral",
                difficulty_level=difficulty_level,
                expected_answer_points=["Problem identification", "Solution approach", "Results achieved"],
                follow_up_questions=["What would you do differently if you encountered this problem again?"]
            ),
            InterviewQuestion(
                question="How do you ensure code quality and maintainability in your projects?",
                category="technical",
                difficulty_level=difficulty_level,
                expected_answer_points=["Code review practices", "Testing strategies", "Documentation"],
                follow_up_questions=["Can you give an example of how you've improved existing code quality?"]
            )
        ]
        
        # Extend list to match requested count
        questions = basic_questions[:question_count] if len(basic_questions) >= question_count else basic_questions
        
        return InterviewQuestionsResponse(
            questions=questions,
            total_questions=len(questions),
            question_distribution={"technical": 2, "behavioral": 1},
            interview_duration_estimate=f"{question_count * 8}-{question_count * 12} minutes",
            preparation_tips=[
                "Review technical requirements carefully",
                "Prepare follow-up questions based on candidate responses",
                "Focus on practical experience and problem-solving approach"
            ]
        )
    
    def _create_fallback_skill_response(self, skill_name: str) -> SkillAnalysisResponse:
        """Create a fallback skill analysis response when JSON parsing fails."""
        
        return SkillAnalysisResponse(
            skill_name=skill_name,
            importance_level="high",  # Conservative assumption for skills mentioned in JDs
            proficiency_required="intermediate",  # Safe middle ground
            years_experience_needed=3,  # Reasonable default
            related_skills=[],
            industry_demand="medium",  # Conservative estimate
            learning_resources=[
                f"Official {skill_name} documentation and tutorials",
                f"Professional {skill_name} certification programs",
                f"Industry-standard {skill_name} training courses",
                f"Hands-on {skill_name} projects and practice"
            ],
            certification_options=[
                f"Industry-recognized {skill_name} certifications",
                f"Vendor-specific {skill_name} credentials"
            ]
        )
    
    def _prepare_job_context(self, job_data: Dict[str, Any]) -> str:
        """Prepare comprehensive job context for AI processing."""
        context_parts = []
        
        if job_data.get("title"):
            context_parts.append(f"Job Title: {str(job_data['title']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("department"):
            context_parts.append(f"Department: {str(job_data['department']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("location"):
            context_parts.append(f"Location: {str(job_data['location']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("employment_type"):
            context_parts.append(f"Employment Type: {str(job_data['employment_type']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("description"):
            context_parts.append(f"Job Description:\n{str(job_data['description']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("responsibilities"):
            context_parts.append(f"Key Responsibilities:\n{str(job_data['responsibilities']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("requirements"):
            context_parts.append(f"Requirements & Qualifications:\n{str(job_data['requirements']).replace('{', '{{').replace('}', '}}')}")
        
        if job_data.get("benefits"):
            context_parts.append(f"Benefits:\n{str(job_data['benefits']).replace('{', '{{').replace('}', '}}')}")
        
        # Include detailed AI analysis if available
        ai_analysis = job_data.get("ai_analysis", {})
        if ai_analysis:
            analysis_parts = []
            
            # Required skills
            required_skills = ai_analysis.get("required_skills", [])
            if required_skills:
                skills_str = ', '.join(str(skill).replace('{', '{{').replace('}', '}}') for skill in required_skills)
                analysis_parts.append(f"Required Technical Skills: {skills_str}")
            
            # Preferred skills
            preferred_skills = ai_analysis.get("preferred_skills", [])
            if preferred_skills:
                skills_str = ', '.join(str(skill).replace('{', '{{').replace('}', '}}') for skill in preferred_skills)
                analysis_parts.append(f"Preferred Skills: {skills_str}")
            
            # Experience requirements
            exp_req = ai_analysis.get("experience_requirements", {})
            if exp_req:
                min_years = exp_req.get("min_years") or ai_analysis.get("min_years_experience")
                max_years = exp_req.get("max_years") or ai_analysis.get("max_years_experience")
                if min_years or max_years:
                    years_text = f"{min_years or 0}-{max_years or 'N/A'} years"
                    analysis_parts.append(f"Experience Required: {years_text}")
                
                req_areas = exp_req.get("required_areas", [])
                if req_areas:
                    areas_str = ', '.join(str(area).replace('{', '{{').replace('}', '}}') for area in req_areas)
                    analysis_parts.append(f"Required Experience Areas: {areas_str}")
            
            # Education requirements
            edu_req = ai_analysis.get("education_requirements", {})
            if edu_req:
                edu_str = json.dumps(edu_req, indent=2).replace('{', '{{').replace('}', '}}')
                analysis_parts.append(f"Education Requirements: {edu_str}")
            
            # Leadership requirement
            if ai_analysis.get("leadership_required"):
                analysis_parts.append("Leadership Role: Yes")
            
            # Processed requirements
            processed_req = ai_analysis.get("processed_requirements", {})
            if processed_req:
                analysis_parts.append(f"Detailed Requirements Analysis: {json.dumps(processed_req, indent=2)}")
            
            if analysis_parts:
                context_parts.append(f"AI-Extracted Analysis:\n" + "\n".join(analysis_parts))
        
        final_context = "\n\n".join(context_parts)
        
        # Log the context length and a preview for debugging
        logger.info(f"📋 Prepared job context: {len(final_context)} characters")
        logger.debug(f"📋 Job context preview: {final_context[:300]}...")
        
        return final_context
    
    async def _classify_question(self, question: str, job_context: str) -> QuestionType:
        """Classify the type of question being asked."""
        try:
            prompt = self.classification_prompt.format_messages(
                question=question,
                job_description=job_context
            )
            
            response = await self.llm.ainvoke(prompt)
            
            # Extract question type from response
            content = response.content.lower()
            
            if any(word in content for word in ["skill", "technology", "programming", "technical"]):
                return QuestionType.SKILL_DETAILS
            elif any(word in content for word in ["experience", "years", "background"]):
                return QuestionType.EXPERIENCE_REQUIREMENTS
            elif any(word in content for word in ["education", "degree", "qualification"]):
                return QuestionType.EDUCATION_REQUIREMENTS
            elif any(word in content for word in ["interview", "question", "ask"]):
                return QuestionType.INTERVIEW_QUESTIONS
            elif any(word in content for word in ["salary", "compensation", "pay", "benefits"]):
                return QuestionType.COMPENSATION_INFO
            elif any(word in content for word in ["culture", "environment", "team"]):
                return QuestionType.COMPANY_CULTURE
            elif any(word in content for word in ["responsibility", "duties", "role"]):
                return QuestionType.ROLE_RESPONSIBILITIES
            else:
                return QuestionType.GENERAL_INQUIRY
                
        except Exception as e:
            logger.warning(f"Error classifying question: {e}")
            return QuestionType.GENERAL_INQUIRY
    
    async def _generate_response(
        self,
        question: str,
        job_context: str,
        question_type: QuestionType,
        session_id: str,
        context: Optional[Dict[str, Any]]
    ) -> CopilotResponse:
        """Generate a comprehensive response to the user's question."""
        
        # Get conversation history for context
        history = self.conversation_history.get(session_id, [])
        
        prompt = self.response_prompt.format_messages(
            question=question,
            job_context=job_context,
            question_type=question_type.value,
            conversation_history=json.dumps(history[-3:], indent=2) if history else "No previous conversation",
            additional_context=json.dumps(context, indent=2) if context else "No additional context"
        )
        
        # Use a comprehensive approach for detailed responses
        json_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert AI recruiter assistant with deep knowledge of talent acquisition, technical skills assessment, and comprehensive job analysis. You MUST respond with ONLY valid JSON.

CORE PRINCIPLES:
- Provide COMPREHENSIVE, detailed, and actionable responses
- Analyze ALL aspects of the job requirements systematically  
- Give specific, evidence-based recommendations
- Consider experience levels, skill combinations, and role complexity
- Provide thorough coverage of technical and soft skills

RESPONSE REQUIREMENTS:
- "answer": Provide a detailed, comprehensive response (minimum 200 words for complex questions)
- "evidence": Extract ALL relevant evidence from the job description that supports your answer
- "suggestions": Provide 3-5 specific, actionable suggestions for recruiters
- "confidence": Rate your confidence (0.0-1.0) based on completeness of job information

FOR INTERVIEW QUESTIONS:
- Generate questions that cover ALL mentioned skills and technologies
- Include technical depth questions for senior roles, basics for junior roles
- Cover: technical skills, problem-solving, experience-based scenarios, cultural fit
- Ensure questions test both theoretical knowledge and practical application
- Include follow-up questions for deeper assessment

FOR SKILL ANALYSIS:
- Break down each skill by importance and proficiency level needed
- Explain how skills relate to daily responsibilities
- Identify skill combinations and dependencies
- Suggest evaluation methods for each skill

EXAMPLE OUTPUT (copy this format exactly):
{{
  "answer": "For this Senior Python Developer role, the interview should comprehensively assess both technical depth and practical experience. The role requires advanced Python programming skills with 5+ years of experience, specifically in backend development using Django framework. Key technical areas to evaluate include: 1) Python expertise - object-oriented programming, design patterns, performance optimization; 2) Django framework - ORM, REST API development, middleware, security practices; 3) Database skills - PostgreSQL query optimization, indexing, data modeling; 4) AWS cloud services - EC2, RDS, S3, deployment strategies; 5) System design - scalable architecture, microservices, caching strategies. Beyond technical skills, assess problem-solving methodology, code quality practices, team collaboration, and mentoring capabilities expected at senior level.",
  "evidence": ["Job title specifies 'Senior' level requiring advanced expertise", "Requirements explicitly state '5+ years Python experience'", "Backend services development mentioned in responsibilities", "Django framework specifically required", "PostgreSQL database experience needed", "AWS knowledge required for cloud deployment"],
  "suggestions": ["Design coding challenges that mirror real backend scenarios they'll face", "Include system design questions for scalable architecture", "Ask about specific Django optimization techniques", "Evaluate AWS deployment and monitoring experience", "Assess mentoring and code review capabilities"],
  "confidence": 0.95
}}

NO ADDITIONAL TEXT. NO MARKDOWN. NO EXPLANATIONS. ONLY THE JSON OBJECT."""),
            ("human", f"Question: {question}\n\nJob Information:\n{job_context[:1500].replace('{', '{{').replace('}', '}}')}")  # Increased context limit for comprehensive analysis
        ])
        
        # Try multiple times with simpler prompts if needed
        max_retries = 2
        parsed_response = None
        
        for attempt in range(max_retries):
            try:
                if attempt == 0:
                    # First attempt with structured prompt
                    current_prompt = json_prompt
                else:
                    # Retry with even simpler prompt
                    simple_prompt = ChatPromptTemplate.from_messages([
                        ("system", """Return ONLY this JSON structure with your answers filled in:
{{"answer": "your answer here", "evidence": [], "suggestions": [], "confidence": 0.8}}

NO OTHER TEXT. NO MARKDOWN. JUST THE JSON."""),
                        ("human", f'Question: {question}\nJob: {job_context[:400].replace("{", "{{").replace("}", "}}")}')
                    ])
                    current_prompt = simple_prompt
                
                formatted_messages = current_prompt.format_messages()
                llm_response = await self.llm.ainvoke(formatted_messages)
                response_text = llm_response.content.strip()
                
                # Clean up the response text more thoroughly
                # Remove any markdown code blocks
                if '```' in response_text:
                    # Handle both ```json and ``` formats
                    lines = response_text.split('\n')
                    in_code_block = False
                    cleaned_lines = []
                    for line in lines:
                        if line.strip().startswith('```'):
                            in_code_block = not in_code_block
                        elif in_code_block or not line.strip().startswith('```'):
                            if not line.strip().startswith('```'):
                                cleaned_lines.append(line)
                    response_text = '\n'.join(cleaned_lines)
                
                # Multiple strategies to extract JSON
                json_text = None
                
                # Strategy 1: Find JSON object between braces
                first_brace = response_text.find('{')
                last_brace = response_text.rfind('}')
                
                if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
                    json_text = response_text[first_brace:last_brace + 1]
                
                # Strategy 2: If the entire response looks like JSON, use it as-is
                elif response_text.strip().startswith('{') and response_text.strip().endswith('}'):
                    json_text = response_text.strip()
                
                if json_text:
                    try:
                        parsed_response = json.loads(json_text)
                        logger.info(f"✅ Successfully parsed JSON on attempt {attempt + 1}")
                        break
                    except json.JSONDecodeError as e:
                        logger.error(f"❌ Attempt {attempt + 1} JSON parsing failed: {str(e)}")
                        if attempt == max_retries - 1:
                            # Last attempt failed, try to create minimal valid JSON
                            logger.warning(f"All parsing attempts failed. Raw response: {response_text}")
                            break
                else:
                    logger.warning(f"Attempt {attempt + 1}: No valid JSON structure found in response")
                    
            except Exception as e:
                logger.error(f"Attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    break
        
        # Create the final response
        if parsed_response:
            # Successfully parsed JSON
            # Handle confidence field that might be string or number
            confidence_raw = parsed_response.get("confidence", 0.7)
            try:
                if isinstance(confidence_raw, (int, float)):
                    confidence_score = float(confidence_raw)
                elif isinstance(confidence_raw, str):
                    # Convert string confidence levels to numbers
                    confidence_map = {
                        "very high": 0.95, "high": 0.8, "medium": 0.6, 
                        "low": 0.4, "very low": 0.2
                    }
                    confidence_score = confidence_map.get(confidence_raw.lower(), 0.7)
                else:
                    confidence_score = 0.7
            except (ValueError, TypeError):
                confidence_score = 0.7
                
            # Handle evidence field - convert string to list if needed
            evidence = parsed_response.get("evidence", [])
            if isinstance(evidence, str):
                # Split string into list
                evidence = [evidence] if evidence else []
            elif not isinstance(evidence, list):
                evidence = []
            
            # Handle suggestions field - convert string to list if needed
            suggestions = parsed_response.get("suggestions", [])
            if isinstance(suggestions, str):
                # Split string into list
                suggestions = [suggestions] if suggestions else []
            elif not isinstance(suggestions, list):
                suggestions = []
            
            response = CopilotResponse(
                answer=parsed_response.get("answer", "No answer provided"),
                question_type=question_type,
                confidence_score=confidence_score,
                supporting_evidence=evidence,
                suggestions=suggestions,
                follow_up_questions=[],  # Simplified for now
                actionable_insights=[],   # Simplified for now
                metadata={"parsing_successful": True, "raw_confidence": confidence_raw}
            )
        else:
            # Failed to parse JSON, create basic response
            logger.warning("All JSON parsing attempts failed, creating basic response")
            
            # Try to extract a meaningful answer from the raw response text
            fallback_answer = "I can help you with questions about this job posting. Please try asking again."
            if 'response_text' in locals() and response_text:
                # Try to extract meaningful content from the raw response
                if len(response_text) > 10:  # Basic sanity check
                    # Clean up the response text for use as answer
                    clean_text = response_text.strip()
                    # Remove any JSON-like formatting artifacts
                    clean_text = clean_text.replace('{"answer":', '').replace('"', '').replace('}', '').strip()
                    if len(clean_text) > 10 and len(clean_text) < 1000:  # Reasonable length check
                        fallback_answer = clean_text
            
            response = CopilotResponse(
                answer=fallback_answer,
                question_type=question_type,
                confidence_score=0.5,
                supporting_evidence=[],
                suggestions=["Try rephrasing your question", "Ask about specific job requirements"],
                follow_up_questions=[],
                actionable_insights=[],
                metadata={"parsing_successful": False, "fallback_used": True}
            )
        
        return response
    
    def _update_conversation_history(
        self,
        session_id: str,
        question: str,
        response: CopilotResponse
    ):
        """Update conversation history for context awareness."""
        if session_id not in self.conversation_history:
            self.conversation_history[session_id] = []
        
        self.conversation_history[session_id].append({
            "timestamp": datetime.now().isoformat(),
            "question": question,
            "answer": response.answer,
            "question_type": response.question_type.value,
            "confidence": response.confidence_score
        })
        
        # Keep only last 10 exchanges
        if len(self.conversation_history[session_id]) > 10:
            self.conversation_history[session_id] = self.conversation_history[session_id][-10:]
    
    def _get_classification_system_prompt(self) -> str:
        """System prompt for question classification."""
        return """You are an expert AI recruiter assistant specializing in job description analysis.
        
        Your task is to classify the type of question being asked about a job posting.
        
        Question Types:
        - skill_details: Questions about specific skills, technologies, or technical requirements
        - experience_requirements: Questions about experience levels, years, or background needed
        - education_requirements: Questions about educational qualifications, degrees, certifications
        - interview_questions: Requests to generate interview questions
        - compensation_info: Questions about salary, benefits, compensation
        - company_culture: Questions about work environment, culture, team dynamics
        - role_responsibilities: Questions about job duties, responsibilities, day-to-day tasks
        - career_progression: Questions about growth opportunities, advancement
        - team_structure: Questions about team size, structure, reporting
        - work_environment: Questions about remote work, office setup, work conditions
        - application_process: Questions about how to apply, application requirements
        - comparison_analysis: Questions comparing this role to others
        - candidate_evaluation: Questions about evaluating candidates for this role
        - general_inquiry: General questions that don't fit other categories
        
        Analyze the question and provide the most appropriate classification."""
    
    def _get_response_system_prompt(self) -> str:
        """System prompt for comprehensive response generation."""
        return """You are an elite AI recruiter assistant with world-class expertise in talent acquisition, technical assessment, market analysis, and strategic hiring across all industries and experience levels.

        CORE EXPERTISE AREAS:
        - Technical skill assessment and evaluation methodologies
        - Market salary benchmarking and compensation analysis
        - Candidate sourcing strategies and talent pipeline development
        - Interview design and behavioral assessment techniques
        - Role complexity analysis and requirement prioritization
        - Team dynamics and cultural fit evaluation
        - Industry trends and emerging skill requirements

        RESPONSE EXCELLENCE STANDARDS:
        1. COMPREHENSIVE ANALYSIS - Provide thorough, multi-dimensional insights that cover all aspects
        2. EVIDENCE-BASED RECOMMENDATIONS - Support every claim with specific evidence from the job description
        3. STRATEGIC THINKING - Consider long-term implications, team impact, and business objectives
        4. PRACTICAL IMPLEMENTATION - Offer concrete, actionable steps recruiters can immediately execute
        5. MARKET CONTEXT - Include industry benchmarks, competitive landscape, and trending requirements
        6. RISK MITIGATION - Identify potential hiring pitfalls and suggest preventive measures
        7. SCALABLE SOLUTIONS - Provide approaches that work for both individual hires and bulk recruiting

        DEPTH REQUIREMENTS:
        - For technical roles: Deep dive into specific technologies, frameworks, architectures
        - For leadership roles: Focus on management philosophy, team building, strategic vision
        - For junior roles: Emphasize potential, learning ability, cultural alignment
        - For senior roles: Assess impact, mentoring capabilities, technical leadership

        COMPREHENSIVE COVERAGE:
        - Extract and analyze EVERY requirement, skill, and qualification mentioned
        - Identify implicit requirements based on role level and responsibilities
        - Consider skill combinations and technology stack coherence
        - Evaluate requirement priority and negotiability
        - Assess market availability and competition for required skills

        ACTIONABLE INSIGHTS:
        - Provide specific recruiting strategies tailored to the role
        - Suggest sourcing channels and platforms most effective for the target profile
        - Recommend interview evaluation criteria and red flags
        - Offer salary negotiation guidelines and market positioning
        - Include timeline expectations and process optimization tips

        QUALITY INDICATORS:
        - Responses should be detailed enough to serve as recruiting playbooks
        - Include multiple perspectives and alternative approaches
        - Provide both immediate tactical advice and strategic guidance
        - Address potential edge cases and challenging scenarios
        - Offer continuous improvement suggestions for the hiring process

        Remember: Deliver insights that transform good recruiters into exceptional talent acquisition specialists."""
    
    def _get_response_human_prompt(self) -> str:
        """Human prompt template for response generation."""
        return """
        Question: {question}
        Question Type: {question_type}
        
        Job Context:
        {job_context}
        
        Previous Conversation:
        {conversation_history}
        
        Additional Context:
        {additional_context}
        
        Please provide a comprehensive response that includes:
        - A clear, helpful answer to the question
        - Supporting evidence from the job description
        - Practical suggestions for the recruiter
        - Relevant follow-up questions
        - Actionable insights
        - A confidence score (0-1) based on available information
        """
    
    def _get_interview_questions_system_prompt(self) -> str:
        """System prompt for comprehensive interview question generation."""
        return """You are a world-class interview architect with deep expertise in technical assessment, behavioral evaluation, and comprehensive candidate evaluation across all experience levels and domains.

        MISSION: Generate a complete, systematic interview framework that thoroughly evaluates every skill, requirement, and competency mentioned in the job description.

        COMPREHENSIVE COVERAGE REQUIREMENTS:
        1. TECHNICAL SKILLS - Create questions for EVERY technology, framework, and tool mentioned
        2. EXPERIENCE DEPTH - Adjust complexity based on required experience level (entry/mid/senior/lead)
        3. PRACTICAL APPLICATION - Include hands-on scenarios candidates will actually face
        4. PROBLEM-SOLVING - Test analytical thinking and approach to challenges
        5. SYSTEM DESIGN - For senior roles, include architecture and scalability questions
        6. BEHAVIORAL ASSESSMENT - Evaluate soft skills, teamwork, communication, leadership
        7. ROLE-SPECIFIC SCENARIOS - Create situations specific to the job responsibilities
        8. CULTURAL FIT - Assess alignment with company values and work environment

        QUESTION SOPHISTICATION BY LEVEL:
        - JUNIOR (0-2 years): Fundamentals, basic concepts, learning ability, potential
        - MID-LEVEL (3-5 years): Practical experience, problem-solving, project ownership
        - SENIOR (5-8 years): Advanced concepts, system design, mentoring, technical leadership
        - LEAD/PRINCIPAL (8+ years): Architecture decisions, strategy, team leadership, business impact

        QUESTION STRUCTURE:
        - PRIMARY QUESTION: Core concept or scenario
        - FOLLOW-UP QUESTIONS: Dig deeper into understanding and experience
        - PRACTICAL EXAMPLES: Ask for specific examples from their experience
        - EDGE CASES: Test boundary knowledge and problem-solving
        - IMPLEMENTATION DETAILS: How they would actually build/solve something

        EVIDENCE-BASED DESIGN:
        - Map each question directly to job requirements
        - Ensure NO skill or requirement is left untested
        - Include both theoretical knowledge AND practical application
        - Test for recent, relevant experience in required technologies

        OUTPUT REQUIREMENTS:
        - Generate 15-25 questions for comprehensive coverage
        - Include difficulty progression within each category
        - Provide expected answer frameworks for interviewers
        - Suggest evaluation criteria and red flags
        - Include time estimates for each question category

        Create questions that definitively identify the strongest candidates while ensuring all critical competencies are thoroughly evaluated."""
    
    def _get_skill_analysis_system_prompt(self) -> str:
        """System prompt for comprehensive skill analysis."""
        return """You are a world-class technology strategist and skills intelligence expert with comprehensive knowledge of:
        - Technical skill evolution and industry trajectories
        - Market demand analytics and compensation impact
        - Skill assessment methodologies and interview techniques  
        - Professional development pathways and certification ecosystems
        - Technology stack integration and skill synergies
        - Talent acquisition strategies and competitive positioning

        MISSION: Provide definitive, data-driven analysis of skills that enables strategic hiring decisions and competitive talent acquisition.

        COMPREHENSIVE SKILL ANALYSIS FRAMEWORK:

        1. CONTEXTUAL IMPORTANCE ASSESSMENT:
        - Analyze skill criticality within the specific role and technology stack
        - Evaluate impact on job performance and business outcomes
        - Assess replaceability and skill substitution possibilities
        - Determine negotiability vs. non-negotiable status

        2. PROFICIENCY DEPTH ANALYSIS:
        - Define exact proficiency levels required (beginner/intermediate/advanced/expert)
        - Specify typical years of experience for competency achievement
        - Identify proficiency indicators and measurable competencies
        - Map skill progression pathways and advancement milestones

        3. SKILL ECOSYSTEM MAPPING:
        - Identify all complementary and synergistic skills
        - Analyze technology stack dependencies and integrations
        - Map skill combinations that create multiplicative value
        - Assess skill portfolio completeness and gaps

        4. MARKET INTELLIGENCE:
        - Provide current market demand and supply dynamics
        - Analyze salary impact and compensation premiums
        - Assess geographic availability and remote work implications
        - Evaluate competitive landscape and talent scarcity

        5. EVALUATION METHODOLOGY:
        - Design specific interview questions and practical assessments
        - Define evaluation criteria and scoring frameworks
        - Suggest hands-on challenges and real-world scenarios
        - Identify skill demonstration methods and portfolio requirements

        6. STRATEGIC DEVELOPMENT:
        - Recommend high-quality learning resources and training programs
        - Map certification pathways and professional credentials
        - Suggest mentorship and practical experience opportunities
        - Outline skill maintenance and continuous development strategies

        7. RECRUITMENT OPTIMIZATION:
        - Provide sourcing strategies and candidate identification methods
        - Suggest recruiting channels and talent pipeline development
        - Recommend interview team composition and assessment distribution
        - Offer negotiation strategies and competitive positioning tactics

        DELIVERABLE STANDARDS:
        - Analysis must be specific to the exact role context and requirements
        - Provide actionable insights that directly improve hiring outcomes
        - Include both immediate tactical advice and strategic workforce planning
        - Address skill evolution trends and future-proofing considerations
        - Offer risk mitigation strategies for critical skill gaps

        Transform skill analysis from basic assessment to strategic talent intelligence that drives competitive advantage."""
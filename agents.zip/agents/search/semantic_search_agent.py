"""
Semantic Search Agent for AI Recruit - Advanced NLP-Powered Resume Search
Intelligent search agent using semantic understanding and vector similarity.

NO MANUAL RULES - NO FALLBACKS - PURE AI INTELLIGENCE
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import json

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI, ChatOpenAI, AzureOpenAIEmbeddings, OpenAIEmbeddings
from langchain_anthropic import ChatAnthropic
from langchain.schema import Document
from pydantic import BaseModel, Field
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from core.config import Settings

logger = logging.getLogger(__name__)


class SearchIntent(BaseModel):
    """AI-analyzed search intent."""
    intent_type: str = Field(description="Type of search: skill_based, experience_based, education_based, role_based, hybrid")
    key_skills: List[str] = Field(default_factory=list, description="Extracted technical skills")
    soft_skills: List[str] = Field(default_factory=list, description="Extracted soft skills")
    experience_years: Optional[int] = Field(None, description="Required years of experience")
    seniority_level: Optional[str] = Field(None, description="Seniority level: junior, mid, senior, lead, executive")
    role_titles: List[str] = Field(default_factory=list, description="Relevant job titles")
    industries: List[str] = Field(default_factory=list, description="Relevant industries")
    education_requirements: List[str] = Field(default_factory=list, description="Education requirements")
    location_preferences: List[str] = Field(default_factory=list, description="Location preferences")
    confidence_score: float = Field(description="Confidence in intent analysis (0-1)")
    search_strategy: str = Field(description="Recommended search strategy")


class SearchResult(BaseModel):
    """Individual search result with AI scoring."""
    resume_id: str
    candidate_name: str
    relevance_score: float = Field(ge=0, le=1, description="Overall relevance score")
    skill_match_score: float = Field(ge=0, le=1, description="Skill matching score")
    experience_match_score: float = Field(ge=0, le=1, description="Experience matching score")
    semantic_similarity: float = Field(ge=0, le=1, description="Semantic similarity score")
    matched_skills: List[str] = Field(default_factory=list, description="Skills that matched")
    matched_experience: List[str] = Field(default_factory=list, description="Relevant experience")


class SemanticSearchResponse(BaseModel):
    """Complete semantic search response."""
    query: str
    search_intent: SearchIntent
    results: List[SearchResult]
    total_matches: int
    search_time_ms: int
    suggestions: List[str] = Field(default_factory=list, description="Query improvement suggestions")
    alternative_queries: List[str] = Field(default_factory=list, description="Alternative search queries")


class SemanticSearchAgent:
    """
    Advanced NLP-powered search agent for resumes.
    
    This agent:
    - Analyzes natural language search queries
    - Extracts search intent and entities
    - Performs semantic similarity search
    - Ranks results using AI reasoning
    - Provides explanations for matches
    """
    
    def __init__(self, llm=None, embeddings=None, settings: Settings = None):
        """
        Initialize the Semantic Search Agent.
        
        Args:
            llm: Language model for query analysis and reasoning
            embeddings: Embedding model for semantic similarity
            settings: Application settings
        """
        self.llm = llm
        self.embeddings = embeddings
        self.settings = settings
        self.agent_id = "semantic_search_agent"
        self.initialized = False
        
        # Agent configuration
        self.config = {
            "temperature": 0.1,  # Low temperature for consistent analysis
            "max_tokens": 2048,
            "model_name": "gpt-4.1"
        }
        
        # Search configuration
        self.search_config = {
            "max_results": 20,
            "relevance_threshold": 0.20,  # Much more inclusive threshold
            "similarity_threshold": 0.25,  # Lower threshold for semantic similarity
            "boost_factors": {
                "exact_skill_match": 2.0,  # Stronger boost for exact skill matches
                "experience_match": 1.5,
                "title_match": 1.3,
                "recent_experience": 1.2
            },
            "min_skill_match": 0.05,  # Very inclusive skill matching
            "min_experience_relevance": 0.05  # Very low minimum experience relevance
        }
        
        logger.info(f"SemanticSearchAgent initialized with ID: {self.agent_id}")
    
    async def initialize(self) -> None:
        """Initialize the semantic search agent."""
        if self.initialized:
            return
        
        logger.info("Initializing Semantic Search Agent...")
        
        try:
            # Initialize embeddings if not provided
            if not self.embeddings and self.settings:
                embedding_config = self.settings.get_embedding_config()
                logger.info(f"🔧 Embedding config: provider={embedding_config['provider']}")
                
                try:
                    if embedding_config["provider"] == "azure_openai":
                        logger.info("🔧 Attempting to initialize Azure OpenAI embeddings...")
                        self.embeddings = AzureOpenAIEmbeddings(
                            azure_endpoint=embedding_config["config"]["endpoint"],
                            api_key=embedding_config["config"]["api_key"],
                            azure_deployment=embedding_config["config"]["deployment_name"],
                            api_version=embedding_config["config"]["api_version"]
                        )
                        logger.info("✅ Azure OpenAI embeddings initialized successfully")
                    elif embedding_config["provider"] == "openai":
                        logger.info("🔧 Attempting to initialize OpenAI embeddings...")
                        self.embeddings = OpenAIEmbeddings(
                            api_key=embedding_config["config"]["api_key"],
                            model=embedding_config["config"]["model"]
                        )
                        logger.info("✅ OpenAI embeddings initialized successfully")
                except Exception as embedding_error:
                    logger.warning(f"⚠️ Failed to initialize {embedding_config['provider']} embeddings: {str(embedding_error)}")
                    
                    # Fallback to basic OpenAI if Azure fails
                    if embedding_config["provider"] == "azure_openai" and self.settings.OPENAI_API_KEY:
                        logger.info("🔄 Falling back to OpenAI embeddings...")
                        try:
                            self.embeddings = OpenAIEmbeddings(
                                api_key=self.settings.OPENAI_API_KEY,
                                model="text-embedding-3-small"  # Use a smaller, more reliable model
                            )
                            logger.info("✅ Fallback OpenAI embeddings initialized successfully")
                        except Exception as fallback_error:
                            logger.warning(f"⚠️ Fallback embeddings also failed: {str(fallback_error)}")
                            # Continue without embeddings - semantic similarity will be disabled
                            self.embeddings = None
                    else:
                        # Continue without embeddings
                        self.embeddings = None
            
            self.initialized = True
            if self.embeddings:
                logger.info("✅ Semantic Search Agent ready for intelligent search with embeddings")
            else:
                # When embeddings are unavailable, relax thresholds to prevent over-filtering
                self.search_config["relevance_threshold"] = 0.55
                self.search_config["similarity_threshold"] = 0.0
                self.search_config["min_skill_match"] = 0.2
                self.search_config["min_experience_relevance"] = 0.15
                logger.info("✅ Semantic Search Agent ready (degraded mode: no embeddings) – thresholds relaxed")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Semantic Search Agent: {str(e)}")
            # Don't raise - allow the agent to work without embeddings
            self.initialized = True
            self.embeddings = None
            logger.info("✅ Semantic Search Agent initialized in fallback mode (no embeddings)")
    
    async def analyze_search_query(self, query: str) -> SearchIntent:
        """
        Analyze a natural language search query to extract intent and entities.
        
        Args:
            query: Natural language search query
            
        Returns:
            Structured search intent analysis
        """
        try:
            logger.info(f"🔍 Analyzing search query: '{query}'")
            
            if self.llm:
                return await self._ai_query_analysis(query)
            else:
                logger.warning("Using fallback query analysis - LLM not available")
                return await self._fallback_query_analysis(query)
                
        except Exception as e:
            logger.error(f"❌ Query analysis failed: {str(e)}")
            # Return basic intent as fallback
            return SearchIntent(
                intent_type="hybrid",
                key_skills=[query] if query else [],
                confidence_score=0.3,
                search_strategy="basic_text_search"
            )
    
    async def _ai_query_analysis(self, query: str) -> SearchIntent:
        """Perform AI-powered query analysis using LLM."""
        try:
            analysis_prompt = f"""
            As an expert recruiter and NLP specialist, analyze this search query to extract structured search intent.
            
            Query: "{query}"
            
            Extract and identify:
            1. Search Intent Type: skill_based, experience_based, education_based, role_based, or hybrid
            2. Technical Skills: Programming languages, frameworks, tools, technologies (including RPA, AI, ML, etc.)
            3. Soft Skills: Leadership, communication, teamwork, etc.
            4. Experience Requirements: Years of experience, seniority level
            5. Role Information: Job titles, positions, roles
            6. Industry Context: Specific industries or domains
            7. Education: Degrees, certifications, educational requirements
            8. Location: Geographic preferences or requirements
            
            IMPORTANT: Some terms can be both skills AND role components:
            - "RPA" or "Robotic Process Automation" is a SKILL (technology/tool) even when in role titles
            - "AI", "Machine Learning", "Data Science" are SKILLS even when in role titles
            - "React", "Python", "Java" are SKILLS even when mentioned with roles
            - Always extract the core technology/skill from role titles
            
            Examples:
            - "RPA Developer" → key_skills: ["RPA"], role_titles: ["RPA Developer"]
            - "React Frontend Developer" → key_skills: ["React"], role_titles: ["Frontend Developer"]
            - "Senior Python Engineer" → key_skills: ["Python"], role_titles: ["Senior Engineer"], seniority_level: "senior"
            - "UI Developer" → key_skills: ["UI"], role_titles: ["UI Developer"]
            - "UX Designer" → key_skills: ["UX"], role_titles: ["UX Designer"]
            
            Provide your analysis in the following JSON format:
            {{
                "intent_type": "hybrid",
                "key_skills": ["React", "JavaScript", "Node.js"],
                "soft_skills": ["leadership", "communication"],
                "experience_years": 5,
                "seniority_level": "senior",
                "role_titles": ["Senior Developer", "Tech Lead"],
                "industries": ["fintech", "healthcare"],
                "education_requirements": ["Bachelor's degree", "Computer Science"],
                "location_preferences": ["San Francisco", "remote"],
                "confidence_score": 0.85,
                "search_strategy": "semantic_with_skill_boost"
            }}
            
            Be precise and extract what's clearly indicated, but always identify core skills even when embedded in role titles.
            """
            
            response = await self.llm.ainvoke(analysis_prompt)
            
            # Parse LLM response
            try:
                analysis_data = json.loads(response.content)
                return SearchIntent(**analysis_data)
            except json.JSONDecodeError:
                # Fallback parsing if JSON is malformed
                logger.warning("Failed to parse LLM response as JSON, using fallback")
                return await self._fallback_query_analysis(query)
                
        except Exception as e:
            logger.error(f"❌ AI query analysis failed: {str(e)}")
            return await self._fallback_query_analysis(query)
    
    async def _fallback_query_analysis(self, query: str) -> SearchIntent:
        """Fallback query analysis using simple keyword extraction."""
        # Simple keyword-based analysis
        query_lower = query.lower()
        
        # Common technical skills
        tech_skills = [
            "python", "javascript", "java", "react", "angular", "vue", "node.js",
            "docker", "kubernetes", "aws", "azure", "gcp", "sql", "mongodb",
            "machine learning", "ai", "data science", "devops", "frontend", "backend",
            "rpa", "robotic process automation", "uipath", "automation anywhere", "blue prism", "nintex",
            "ui", "ux", "html", "css", "typescript", "figma", "sketch", "adobe", "photoshop"
        ]
        
        # Common soft skills
        soft_skills = [
            "leadership", "management", "communication", "teamwork", "problem solving",
            "analytical", "creative", "strategic", "mentoring"
        ]
        
        # Common role titles
        role_titles = [
            "developer", "engineer", "manager", "lead", "architect", "analyst",
            "designer", "consultant", "specialist", "director", "ui developer", "ux designer",
            "frontend developer", "ui designer", "ux engineer"
        ]
        
        # Extract matches
        found_tech_skills = [skill for skill in tech_skills if skill in query_lower]
        found_soft_skills = [skill for skill in soft_skills if skill in query_lower]
        found_roles = [role for role in role_titles if role in query_lower]
        
        # Determine intent type
        intent_type = "hybrid"
        if found_tech_skills and not found_roles:
            intent_type = "skill_based"
        elif found_roles and not found_tech_skills:
            intent_type = "role_based"
        elif "years" in query_lower or "experience" in query_lower:
            intent_type = "experience_based"
        
        # Extract experience years
        experience_years = None
        words = query_lower.split()
        for i, word in enumerate(words):
            if word.isdigit() and i + 1 < len(words) and "year" in words[i + 1]:
                experience_years = int(word)
                break
        
        # Extract seniority level
        seniority_level = None
        seniority_keywords = ["junior", "mid", "senior", "lead", "executive", "entry", "principal"]
        for keyword in seniority_keywords:
            if keyword in query_lower:
                if keyword == "entry":
                    seniority_level = "junior"
                elif keyword == "principal":
                    seniority_level = "senior"  # Principal is often senior level
                else:
                    seniority_level = keyword
                break
        
        return SearchIntent(
            intent_type=intent_type,
            key_skills=found_tech_skills,
            soft_skills=found_soft_skills,
            experience_years=experience_years,
            seniority_level=seniority_level,
            role_titles=found_roles,
            confidence_score=0.6 if found_tech_skills or found_roles else 0.3,
            search_strategy="keyword_based_search"
        )
    
    async def semantic_search(
        self,
        query: str,
        resume_data: List[Dict[str, Any]],
        max_results: int = 20
    ) -> SemanticSearchResponse:
        """
        Perform semantic search on resume data.
        
        Args:
            query: Natural language search query
            resume_data: List of resume records with AI analysis
            max_results: Maximum number of results to return
            
        Returns:
            Structured search results with AI scoring
        """
        start_time = datetime.now()
        
        try:
            logger.info(f"🔍 Starting semantic search: '{query}' ({len(resume_data)} resumes)")
            
            # Step 1: Analyze search query
            search_intent = await self.analyze_search_query(query)
            logger.info(f"📊 Search intent: {search_intent.dict()}")
            
            # Step 2: Generate query embedding
            query_embedding = None
            if self.embeddings:
                try:
                    query_embedding = await self.embeddings.aembed_query(query)
                    logger.info(f"✅ Generated query embedding with {len(query_embedding)} dimensions")
                except Exception as e:
                    logger.warning(f"Failed to generate query embedding: {e}")
                    query_embedding = None
            else:
                logger.info("⚠️ No embeddings available - semantic similarity will use fallback scoring")
            
            # Step 3: Score and rank resumes with early filtering optimization
            search_results = []
            total_scored = 0
            filtered_out = 0
            early_filtered = 0
            
            for resume in resume_data:
                try:
                    # Early filtering: quick skill check before expensive LLM scoring
                    # Temporarily disabled for debugging
                    # if await self._should_skip_resume(resume, search_intent):
                    #     early_filtered += 1
                    #     logger.debug(f"⚡ Early filtered resume: {resume.get('candidate_name', 'Unknown')} - {resume.get('current_position', 'No position')}")
                    #     continue
                    
                    result = await self._score_resume_match(
                        resume, query, search_intent, query_embedding
                    )
                    total_scored += 1
                    
                    if result:
                        logger.debug(f"📊 Scored resume: {result.candidate_name} - relevance: {result.relevance_score:.3f}, skills: {result.skill_match_score:.3f}")
                        if self._is_result_relevant(result, search_intent):
                            search_results.append(result)
                            logger.debug(f"✅ Accepted: {result.candidate_name}")
                        else:
                            filtered_out += 1
                            logger.debug(f"❌ Filtered out: {result.candidate_name} - relevance: {result.relevance_score:.3f}")
                    else:
                        filtered_out += 1
                        logger.debug(f"❌ No result for: {resume.get('candidate_name', 'Unknown')}")
                        
                except Exception as e:
                    logger.warning(f"Failed to score resume {resume.get('id', 'unknown')}: {e}")
                    continue
            
            if early_filtered > 0:
                logger.info(f"⚡ Early filtering: skipped {early_filtered} obviously irrelevant resumes")
            
            logger.info(f"🎯 Relevance filtering: {len(search_results)} relevant out of {total_scored} scored ({filtered_out} filtered out)")
            
            # Debug: Log some details about the results
            if search_results:
                logger.info(f"📊 Top results: {[(r.candidate_name, f'{r.relevance_score:.3f}') for r in search_results[:3]]}")
            else:
                logger.warning(f"⚠️ No results passed relevance filtering! Scored {total_scored}, filtered out {filtered_out}")
                # Log details about why results were filtered
                if total_scored > 0:
                    logger.warning(f"⚠️ This suggests the relevance threshold ({self.search_config['relevance_threshold']}) might be too high")
            
            # Step 4: Sort by relevance score
            search_results.sort(key=lambda x: x.relevance_score, reverse=True)
            
            # Step 5: Limit results
            search_results = search_results[:max_results]
            
            # Step 6: Generate suggestions
            suggestions = await self._generate_search_suggestions(query, search_intent)
            alternative_queries = await self._generate_alternative_queries(query, search_intent)
            
            search_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            logger.info(f"✅ Semantic search completed: {len(search_results)} results in {search_time}ms")
            
            return SemanticSearchResponse(
                query=query,
                search_intent=search_intent,
                results=search_results,
                total_matches=len(search_results),
                search_time_ms=search_time,
                suggestions=suggestions,
                alternative_queries=alternative_queries
            )
            
        except Exception as e:
            logger.error(f"❌ Semantic search failed: {str(e)}")
            search_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            return SemanticSearchResponse(
                query=query,
                search_intent=SearchIntent(
                    intent_type="hybrid",
                    confidence_score=0.1,
                    search_strategy="error_fallback"
                ),
                results=[],
                total_matches=0,
                search_time_ms=search_time,
                suggestions=["Try a simpler query", "Check spelling and try again"],
                alternative_queries=[]
            )
    
    async def _score_resume_match(
        self,
        resume: Dict[str, Any],
        query: str,
        search_intent: SearchIntent,
        query_embedding: Optional[List[float]] = None
    ) -> Optional[SearchResult]:
        """Score a single resume using one AI call to get all similarity scores."""
        try:
            if not self.llm:
                # Fallback without AI
                return self._create_fallback_result(resume, query)
            
            # Extract resume details for AI analysis
            resume_details = self._extract_resume_details(resume)
            
            # Single AI call to get all scores
            ai_scores = await self._get_ai_scores(resume_details, query, search_intent)
            
            if not ai_scores or not isinstance(ai_scores, dict):
                logger.warning(f"AI scores returned None or invalid format for resume {resume.get('id', 'unknown')}")
                return self._create_fallback_result(resume, query)
            
            # Create result from AI scores
            result = SearchResult(
                resume_id=str(resume.get("id", "")),
                candidate_name=resume.get("candidate_name") or "Unknown",
                relevance_score=ai_scores.get("relevance_score", 0.5),
                skill_match_score=ai_scores.get("skill_match_score", 0.5),
                experience_match_score=ai_scores.get("experience_match_score", 0.5),
                semantic_similarity=ai_scores.get("semantic_similarity", 0.5),
                matched_skills=ai_scores.get("matched_skills", []),
                matched_experience=ai_scores.get("matched_experience", [])
            )
            
            # Store original resume data
            result._resume_data = resume
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Failed to score resume match: {str(e)}")
            return None
    
    def _extract_resume_details(self, resume: Dict[str, Any]) -> Dict[str, Any]:
        """Extract key resume details for AI analysis."""
        try:
            ai_analysis = resume.get("ai_analysis", {})
            
            # Get all skill categories with safe handling
            skills_analysis = ai_analysis.get("skills_analysis", {})
            
            # Extract all skill types
            tech_skills = skills_analysis.get("technical_skills", [])
            soft_skills = skills_analysis.get("soft_skills", [])
            methodologies = skills_analysis.get("methodologies", [])
            tools_technologies = skills_analysis.get("tools_technologies", [])
            frameworks_libraries = skills_analysis.get("frameworks_libraries", [])
            programming_languages = skills_analysis.get("programming_languages", [])
            
            # Ensure all skills are lists and handle None values
            skill_categories = {
                'tech_skills': tech_skills,
                'soft_skills': soft_skills,
                'methodologies': methodologies,
                'tools_technologies': tools_technologies,
                'frameworks_libraries': frameworks_libraries,
                'programming_languages': programming_languages
            }
            
            for category, skills in skill_categories.items():
                if not isinstance(skills, list):
                    skill_categories[category] = []
            
            # Get career info
            career_analysis = ai_analysis.get("career_analysis", {})
            
            # Get professional summary safely
            professional_summary = resume.get("professional_summary", "")
            if not isinstance(professional_summary, str):
                professional_summary = ""
            
            # Combine all skills for comprehensive matching
            all_skills = []
            for category, skills in skill_categories.items():
                all_skills.extend([str(skill) for skill in skills if skill is not None])
            
            return {
                "candidate_name": resume.get("candidate_name", "Unknown"),
                "current_position": career_analysis.get("current_position", ""),
                "current_company": career_analysis.get("current_company", ""),
                "years_experience": career_analysis.get("total_years_experience", 0),
                "technical_skills": [str(skill) for skill in skill_categories['tech_skills'] if skill is not None],
                "soft_skills": [str(skill) for skill in skill_categories['soft_skills'] if skill is not None],
                "methodologies": [str(skill) for skill in skill_categories['methodologies'] if skill is not None],
                "tools_technologies": [str(skill) for skill in skill_categories['tools_technologies'] if skill is not None],
                "frameworks_libraries": [str(skill) for skill in skill_categories['frameworks_libraries'] if skill is not None],
                "programming_languages": [str(skill) for skill in skill_categories['programming_languages'] if skill is not None],
                "all_skills": all_skills,  # All combined skills for comprehensive matching
                "professional_summary": professional_summary[:200],
                "education": ai_analysis.get("education", {}).get("highest_degree", "")
            }
            
        except Exception as e:
            logger.error(f"Error extracting resume details: {e}")
            # Return safe defaults
            return {
                "candidate_name": resume.get("candidate_name", "Unknown"),
                "current_position": "",
                "current_company": "",
                "years_experience": 0,
                "technical_skills": [],
                "soft_skills": [],
                "methodologies": [],
                "tools_technologies": [],
                "frameworks_libraries": [],
                "programming_languages": [],
                "all_skills": [],
                "professional_summary": "",
                "education": ""
            }
    
    async def _get_ai_scores(self, resume_details: Dict[str, Any], query: str, search_intent: SearchIntent) -> Optional[Dict[str, Any]]:
        """Make one AI call to get all similarity scores for a resume."""
        try:
            prompt = f"""
Analyze this resume against the search query and provide similarity scores.

SEARCH QUERY: "{query}"

RESUME DETAILS:
- Name: {resume_details['candidate_name']}
- Position: {resume_details['current_position']}
- Company: {resume_details['current_company']}
- Experience: {resume_details['years_experience']} years
- Technical Skills: {', '.join(resume_details['technical_skills'])}
- Soft Skills: {', '.join(resume_details['soft_skills'])}
- Methodologies: {', '.join(resume_details['methodologies'])}
- Tools & Technologies: {', '.join(resume_details['tools_technologies'])}
- Frameworks & Libraries: {', '.join(resume_details['frameworks_libraries'])}
- Programming Languages: {', '.join(resume_details['programming_languages'])}
- All Skills (combined): {', '.join(resume_details['all_skills'])}
- Summary: {resume_details['professional_summary']}
- Education: {resume_details['education']}

IMPORTANT: Consider ALL skill categories when matching - not just technical and soft skills. 
Look for matches in methodologies, tools, frameworks, and programming languages as well.

Provide scores (0.0 to 1.0) and return ONLY this JSON format:
{{
    "relevance_score": 0.85,
    "skill_match_score": 0.80,
    "experience_match_score": 0.90,
    "semantic_similarity": 0.75,
    "matched_skills": ["skill1", "skill2"],
    "matched_experience": ["experience1"]
}}
"""
            
            response = await self.llm.ainvoke(prompt)
            content = response.content if hasattr(response, 'content') else str(response)
            
            logger.debug(f"AI response content: {content[:200]}...")
            
            # Extract JSON
            import re
            import json
            
            json_match = re.search(r'\{.*\}', content, re.DOTALL)
            if json_match:
                try:
                    json_str = json_match.group()
                    result = json.loads(json_str)
                    
                    # Validate that we have the required fields
                    required_fields = ["relevance_score", "skill_match_score", "experience_match_score"]
                    if all(field in result for field in required_fields):
                        return result
                    else:
                        logger.warning(f"AI response missing required fields: {result}")
                        return None
                        
                except json.JSONDecodeError as json_error:
                    logger.warning(f"Failed to parse JSON from AI response: {json_error}")
                    logger.warning(f"Raw JSON string: {json_str[:200]}...")
                    return None
            
            logger.warning(f"No JSON found in AI response: {content[:200]}...")
            return None
            
        except Exception as e:
            logger.error(f"AI scoring failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    def _create_fallback_result(self, resume: Dict[str, Any], query: str) -> SearchResult:
        """Create a simple fallback result without AI."""
        return SearchResult(
            resume_id=str(resume.get("id", "")),
            candidate_name=resume.get("candidate_name", "Unknown"),
            relevance_score=0.5,
            skill_match_score=0.5,
            experience_match_score=0.5,
            semantic_similarity=0.5,
            matched_skills=[],
            matched_experience=[]
        )
    
    def _extract_searchable_text(self, resume: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        """Extract searchable text from resume and AI analysis."""
        text_parts = []
        
        # Add basic info
        if resume.get("candidate_name"):
            text_parts.append(resume["candidate_name"])
        if resume.get("professional_summary"):
            text_parts.append(resume["professional_summary"])
        
        # Add AI analysis content
        if ai_analysis:
            # Skills
            skills = ai_analysis.get("skills_analysis", {})
            if isinstance(skills, dict):
                tech_skills = skills.get("technical_skills", [])
                soft_skills = skills.get("soft_skills", [])
                
                # Handle technical skills - can be list of strings or list of dicts
                if tech_skills:
                    if isinstance(tech_skills, list):
                        for skill in tech_skills:
                            if isinstance(skill, dict):
                                # Extract skill name from dict format
                                skill_name = skill.get("skill", skill.get("name", str(skill)))
                                text_parts.append(str(skill_name))
                            else:
                                text_parts.append(str(skill))
                    else:
                        text_parts.append(str(tech_skills))
                
                # Handle soft skills - can be list of strings or list of dicts
                if soft_skills:
                    if isinstance(soft_skills, list):
                        for skill in soft_skills:
                            if isinstance(skill, dict):
                                # Extract skill name from dict format
                                skill_name = skill.get("skill", skill.get("name", str(skill)))
                                text_parts.append(str(skill_name))
                            else:
                                text_parts.append(str(skill))
                    else:
                        text_parts.append(str(soft_skills))
            
            # Experience
            experience = ai_analysis.get("career_analysis", {})
            if isinstance(experience, dict):
                current_pos = experience.get("current_position", "")
                current_comp = experience.get("current_company", "")
                if current_pos:
                    text_parts.append(current_pos)
                if current_comp:
                    text_parts.append(current_comp)
            
            # Education
            education = ai_analysis.get("education_analysis", {})
            if isinstance(education, dict):
                degree = education.get("highest_degree", "")
                if degree:
                    text_parts.append(degree)
        
        return " ".join(text_parts)
    
    async def _calculate_skill_match_score(self, ai_analysis: Dict[str, Any], search_intent: SearchIntent) -> float:
        """Calculate skill matching score with improved precision."""
        if not search_intent.key_skills and not search_intent.soft_skills:
            return 0.5  # Neutral score if no skills specified
        
        skills_analysis = ai_analysis.get("skills_analysis", {})
        if not isinstance(skills_analysis, dict):
            return 0.2  # Lower score for missing skills data
        
        resume_tech_skills = skills_analysis.get("technical_skills", [])
        resume_soft_skills = skills_analysis.get("soft_skills", [])
        
        # Convert to lowercase for comparison and handle different data types
        resume_tech_lower = []
        resume_soft_lower = []
        
        # Handle technical skills - can be list of strings or list of dicts
        if isinstance(resume_tech_skills, list):
            for skill in resume_tech_skills:
                if isinstance(skill, dict):
                    # Extract skill name from dict format
                    skill_name = skill.get("skill", skill.get("name", str(skill)))
                    resume_tech_lower.append(str(skill_name).lower())
                else:
                    resume_tech_lower.append(str(skill).lower())
        elif isinstance(resume_tech_skills, str):
            resume_tech_lower = [resume_tech_skills.lower()]
            
        # Handle soft skills - can be list of strings or list of dicts
        if isinstance(resume_soft_skills, list):
            for skill in resume_soft_skills:
                if isinstance(skill, dict):
                    # Extract skill name from dict format
                    skill_name = skill.get("skill", skill.get("name", str(skill)))
                    resume_soft_lower.append(str(skill_name).lower())
                else:
                    resume_soft_lower.append(str(skill).lower())
        elif isinstance(resume_soft_skills, str):
            resume_soft_lower = [resume_soft_skills.lower()]
        
        # Calculate exact and partial matches
        exact_tech_matches = 0
        partial_tech_matches = 0
        exact_soft_matches = 0
        partial_soft_matches = 0
        
        # Check technical skills
        for search_skill in search_intent.key_skills:
            search_skill_lower = search_skill.lower()
            
            # Exact match
            if search_skill_lower in resume_tech_lower:
                exact_tech_matches += 1
            else:
                # Partial match (contains or is contained)
                for resume_skill in resume_tech_lower:
                    if (search_skill_lower in resume_skill or 
                        resume_skill in search_skill_lower or
                        await self._skills_are_similar(search_skill_lower, resume_skill)):
                        partial_tech_matches += 1
                        break
        
        # Check soft skills
        for search_skill in search_intent.soft_skills:
            search_skill_lower = search_skill.lower()
            
            # Exact match
            if search_skill_lower in resume_soft_lower:
                exact_soft_matches += 1
            else:
                # Partial match
                for resume_skill in resume_soft_lower:
                    if (search_skill_lower in resume_skill or 
                        resume_skill in search_skill_lower):
                        partial_soft_matches += 1
                        break
        
        # Calculate weighted score
        total_searched_tech = len(search_intent.key_skills)
        total_searched_soft = len(search_intent.soft_skills)
        total_searched = total_searched_tech + total_searched_soft
        
        if total_searched == 0:
            return 0.5
        
        # Weight exact matches more heavily
        exact_score = (exact_tech_matches + exact_soft_matches) / total_searched
        partial_score = (partial_tech_matches + partial_soft_matches) / total_searched
        
        # Combine scores with exact matches weighted more heavily, but partial matches still significant
        final_score = (exact_score * 0.6) + (partial_score * 0.4)
        
        # Apply boost for high exact match ratio
        if exact_tech_matches > 0 and total_searched_tech > 0:
            exact_ratio = exact_tech_matches / total_searched_tech
            if exact_ratio >= 0.5:  # 50% or more exact matches
                final_score *= self.search_config["boost_factors"]["exact_skill_match"]
        
        return min(final_score, 1.0)
    
    async def _skills_are_similar(self, skill1: str, skill2: str) -> bool:
        """
        AI-based dynamic skill similarity detection.
        Uses semantic embeddings and LLM reasoning to determine if skills are related.
        No hardcoded lists - fully dynamic and scalable.
        """
        # Quick exact match check
        if skill1.lower() == skill2.lower():
            return True
        
        # Use semantic embeddings for similarity if available
        if hasattr(self, 'embeddings') and self.embeddings:
            try:
                # Get embeddings for both skills
                embedding1 = await self.embeddings.aembed_query(f"skill: {skill1}")
                embedding2 = await self.embeddings.aembed_query(f"skill: {skill2}")
                
                # Calculate cosine similarity
                similarity = self._calculate_cosine_similarity(embedding1, embedding2)
                
                # High similarity threshold for skill matching
                if similarity > 0.85:  # Very similar skills
                    return True
                elif similarity > 0.75:  # Potentially similar - use LLM for verification
                    return await self._llm_verify_skill_similarity(skill1, skill2)
                
            except Exception as e:
                logger.warning(f"Embedding-based skill similarity failed: {e}")
        
        # Fallback to LLM-based similarity if embeddings unavailable
        if self.llm:
            return await self._llm_verify_skill_similarity(skill1, skill2)
        
        # Final fallback: basic string similarity
        return self._basic_string_similarity(skill1, skill2)
    
    def _calculate_cosine_similarity(self, vec1: list, vec2: list) -> float:
        """Calculate cosine similarity between two vectors."""
        try:
            import numpy as np
            
            # Convert to numpy arrays
            a = np.array(vec1)
            b = np.array(vec2)
            
            # Calculate cosine similarity
            dot_product = np.dot(a, b)
            norm_a = np.linalg.norm(a)
            norm_b = np.linalg.norm(b)
            
            if norm_a == 0 or norm_b == 0:
                return 0.0
            
            similarity = dot_product / (norm_a * norm_b)
            return float(similarity)
            
        except Exception as e:
            logger.warning(f"Cosine similarity calculation failed: {e}")
            return 0.0
    
    async def _llm_verify_skill_similarity(self, skill1: str, skill2: str) -> bool:
        """Use LLM to determine if two skills are similar or related."""
        try:
            prompt = f"""
            As an expert in technology and professional skills, determine if these two skills are similar, related, or represent the same competency:

            Skill 1: "{skill1}"
            Skill 2: "{skill2}"

            Consider:
            - Synonyms and abbreviations (e.g., "JS" and "JavaScript")
            - Related technologies (e.g., "React" and "Frontend Development")
            - Different names for same concept (e.g., "UI Design" and "User Interface Design")
            - Overlapping skill domains (e.g., "UX Research" and "User Experience")
            - Industry variations (e.g., "RPA" and "Robotic Process Automation")

            Respond with only "true" if they are similar/related, or "false" if they are different.
            """
            
            response = await self.llm.ainvoke(prompt)
            result = response.content.strip().lower()
            
            return result == "true"
            
        except Exception as e:
            logger.warning(f"LLM skill similarity verification failed: {e}")
            return False
    
    def _basic_string_similarity(self, skill1: str, skill2: str) -> bool:
        """Basic string-based similarity as final fallback."""
        s1, s2 = skill1.lower(), skill2.lower()
        
        # Check if one skill contains the other
        if s1 in s2 or s2 in s1:
            return True
        
        # Check for common abbreviations patterns
        if len(s1) <= 3 and s1 in s2:  # Short abbreviations
            return True
        if len(s2) <= 3 and s2 in s1:
            return True
        
        # Check for word overlap
        words1 = set(s1.split())
        words2 = set(s2.split())
        overlap = len(words1.intersection(words2))
        
        # If significant word overlap
        if overlap > 0 and overlap >= min(len(words1), len(words2)) * 0.5:
            return True
        
        return False
    
    def _calculate_experience_match_score(self, ai_analysis: Dict[str, Any], search_intent: SearchIntent) -> float:
        """Calculate experience matching score with progressive rewards for exceptional experience."""
        career_analysis = ai_analysis.get("career_analysis", {})
        if not isinstance(career_analysis, dict):
            return 0.5
        
        score = 0.5  # Base score
        resume_years = career_analysis.get("total_years_experience", 0)
        
        # Check years of experience with progressive scoring
        if search_intent.experience_years:
            required_years = search_intent.experience_years
            if resume_years >= required_years:
                # Base bonus for meeting requirement
                score += 0.2
                
                # Progressive bonus for exceeding requirement
                excess_ratio = resume_years / required_years
                if excess_ratio >= 3.0:  # 3x or more (like Helen: 15/5 = 3x)
                    score += 0.25  # Exceptional experience bonus
                elif excess_ratio >= 2.0:  # 2x or more
                    score += 0.15  # Strong experience bonus
                elif excess_ratio >= 1.5:  # 1.5x or more
                    score += 0.1   # Good experience bonus
                # else: just the base +0.2 for meeting requirement
                
            elif resume_years >= required_years * 0.7:  # 70% of required
                score += 0.1  # Partial credit
        
        # Check seniority level if specified (alternative to specific years)
        elif search_intent.seniority_level:
            seniority_requirements = {
                "junior": 0, "mid": 2, "senior": 5, "lead": 7, "executive": 10
            }
            required_years = seniority_requirements.get(search_intent.seniority_level.lower(), 0)
            
            if resume_years >= required_years:
                # Base bonus for meeting seniority requirement
                score += 0.2
                
                # Progressive bonus for exceeding seniority requirement
                if required_years > 0:  # Avoid division by zero
                    excess_ratio = resume_years / required_years
                    if excess_ratio >= 3.0:  # 3x or more
                        score += 0.25  # Exceptional experience bonus
                    elif excess_ratio >= 2.0:  # 2x or more
                        score += 0.15  # Strong experience bonus
                    elif excess_ratio >= 1.5:  # 1.5x or more
                        score += 0.1   # Good experience bonus
        
        # Check role titles
        if search_intent.role_titles:
            current_position = career_analysis.get("current_position", "").lower()
            role_match = any(role.lower() in current_position for role in search_intent.role_titles)
            if role_match:
                score += 0.15  # Slightly reduced to balance with improved experience scoring
        
        return min(score, 1.0)
    
    def _calculate_overall_relevance(
        self, skill_score: float, experience_score: float, semantic_score: float, search_intent: SearchIntent
    ) -> float:
        """Calculate overall relevance score with weighted components."""
        # Adjust weights based on search intent
        if search_intent.intent_type == "skill_based":
            weights = {"skills": 0.5, "experience": 0.2, "semantic": 0.3}
        elif search_intent.intent_type == "experience_based":
            weights = {"skills": 0.2, "experience": 0.5, "semantic": 0.3}
        elif search_intent.intent_type == "role_based":
            weights = {"skills": 0.3, "experience": 0.4, "semantic": 0.3}
        else:  # hybrid - give more weight to skills when they match
            weights = {"skills": 0.45, "experience": 0.3, "semantic": 0.25}
        
        overall_score = (
            skill_score * weights["skills"] +
            experience_score * weights["experience"] +
            semantic_score * weights["semantic"]
        )
        
        return min(overall_score, 1.0)
    
    # Legacy method - reasoning now handled in _get_ai_scores
    async def _generate_match_reasoning(
        self, resume: Dict[str, Any], query: str, search_intent: SearchIntent,
        skill_score: float, experience_score: float, semantic_score: float
    ) -> str:
        """Legacy method - reasoning now generated in single AI call."""
        return ""
    
    # Legacy method - matched skills now handled in _get_ai_scores
    async def _extract_matched_skills(self, ai_analysis: Dict[str, Any], search_intent: SearchIntent) -> List[str]:
        """Legacy method - matched skills now extracted in single AI call."""
        return []
    
    # Legacy method - matched experience now handled in _get_ai_scores
    def _extract_matched_experience(self, ai_analysis: Dict[str, Any], search_intent: SearchIntent) -> List[str]:
        """Legacy method - matched experience now extracted in single AI call."""
        return []
    
    # Legacy method - highlight snippets now handled in _get_ai_scores
    def _extract_highlight_snippets(self, resume_text: str, query: str, search_intent: SearchIntent) -> List[str]:
        """Legacy method - highlight snippets now extracted in single AI call."""
        return []
    
    async def _generate_search_suggestions(self, query: str, search_intent: SearchIntent) -> List[str]:
        """Generate search improvement suggestions."""
        suggestions = []
        
        if search_intent.confidence_score < 0.5:
            suggestions.append("Try being more specific about skills or experience level")
        
        if not search_intent.key_skills and not search_intent.role_titles:
            suggestions.append("Include specific technical skills or job titles")
        
        if search_intent.intent_type == "hybrid":
            suggestions.append("Try focusing on either skills or experience for better results")
        
        return suggestions
    
    async def _generate_alternative_queries(self, query: str, search_intent: SearchIntent) -> List[str]:
        """Generate alternative search queries."""
        alternatives = []
        
        if search_intent.key_skills:
            alternatives.append(f"Senior {' '.join(search_intent.key_skills[:2])} developer")
        
        if search_intent.role_titles:
            alternatives.append(f"{search_intent.role_titles[0]} with 5+ years experience")
        
        if search_intent.experience_years:
            alternatives.append(f"Experienced professional with {search_intent.experience_years}+ years")
        
        return alternatives[:3]
    
    def _is_result_relevant(self, result: SearchResult, search_intent: SearchIntent) -> bool:
        """
        Determine if a search result is relevant enough to show to the user.
        Uses a flexible approach - high overall relevance OR some criteria met.
        
        Args:
            result: The search result to evaluate
            search_intent: The analyzed search intent
            
        Returns:
            True if the result meets relevance criteria
        """
        # Base relevance threshold - very lenient
        if result.relevance_score < self.search_config["relevance_threshold"]:
            logger.debug(f"Result {result.resume_id} filtered out: relevance_score {result.relevance_score} < threshold {self.search_config['relevance_threshold']}")
            return False
        
        # Count satisfied requirements
        requirements_met = []
        total_requirements = 0
        
        # 1. Skills requirement (if specified)
        if search_intent.key_skills or search_intent.soft_skills:
            total_requirements += 1
            skills_satisfied = self._check_skills_requirement(result, search_intent)
            requirements_met.append(("skills", skills_satisfied))
        
        # 2. Experience requirement (if specified)
        if search_intent.experience_years or search_intent.seniority_level:
            total_requirements += 1
            experience_satisfied = self._check_experience_requirement(result, search_intent)
            requirements_met.append(("experience", experience_satisfied))
        
        # 3. Role/Title requirement (if specified)
        if search_intent.role_titles:
            total_requirements += 1
            role_satisfied = self._check_role_requirement(result, search_intent)
            requirements_met.append(("role", role_satisfied))
        
        # 4. Industry requirement (if specified)
        if search_intent.industries:
            total_requirements += 1
            industry_satisfied = self._check_industry_requirement(result, search_intent)
            requirements_met.append(("industry", industry_satisfied))
        
        # 5. Education requirement (if specified)
        if search_intent.education_requirements:
            total_requirements += 1
            education_satisfied = self._check_education_requirement(result, search_intent)
            requirements_met.append(("education", education_satisfied))
        
        # Flexible matching: if no specific requirements, just use relevance score
        if total_requirements == 0:
            logger.debug(f"✅ No specific requirements, using relevance score: {result.relevance_score}")
            return True
        
        # Count satisfied requirements
        satisfied_count = sum(1 for _, satisfied in requirements_met if satisfied)
        satisfied_reqs = [req[0] for req in requirements_met if req[1]]
        
        # Be more flexible: require at least 1 requirement OR high relevance score
        if satisfied_count >= 1 or result.relevance_score > 0.4:
            logger.debug(f"✅ Result {result.candidate_name} accepted: {satisfied_count}/{total_requirements} requirements met, relevance: {result.relevance_score:.3f}")
            return True
        
        logger.debug(f"❌ Result {result.candidate_name} filtered out: {satisfied_count}/{total_requirements} requirements met, relevance: {result.relevance_score:.3f}")
        return False
    
    def _check_skills_requirement(self, result: SearchResult, search_intent: SearchIntent) -> bool:
        """Check if skills requirement is satisfied - very lenient approach."""
        # Very lenient skill matching - just need some skill match or high relevance
        if result.skill_match_score >= self.search_config["min_skill_match"]:
            return True
        
        # If skill match score is low but we have some matched skills, still consider it
        if result.matched_skills and len(result.matched_skills) > 0:
            return True
        
        # If overall relevance is high, accept even without specific skill matches
        if result.relevance_score > 0.3:
            return True
        
        return False
    
    def _check_experience_requirement(self, result: SearchResult, search_intent: SearchIntent) -> bool:
        """Check if experience requirement is satisfied."""
        # Get actual years of experience from resume data
        resume_data = getattr(result, '_resume_data', {})
        
        # Try multiple sources for years of experience
        actual_years = 0
        if 'years_of_experience' in resume_data:
            actual_years = resume_data.get('years_of_experience', 0)
        elif 'ai_analysis' in resume_data:
            ai_analysis = resume_data.get('ai_analysis', {})
            career_analysis = ai_analysis.get('career_analysis', {})
            actual_years = career_analysis.get('total_years_experience', 0)
        
        # Convert to float if it's a string
        try:
            actual_years = float(actual_years) if actual_years else 0
        except (ValueError, TypeError):
            actual_years = 0
        
        # Check years of experience if specified
        if search_intent.experience_years:
            if actual_years < search_intent.experience_years:
                logger.debug(f"❌ Experience requirement not met: {actual_years} < {search_intent.experience_years} years")
                return False
            logger.debug(f"✅ Experience requirement met: {actual_years} >= {search_intent.experience_years} years")
        
        # Check seniority level if specified
        if search_intent.seniority_level:
            seniority_requirements = {
                "junior": 0,      # 0+ years
                "mid": 2,         # 2+ years  
                "senior": 5,      # 5+ years
                "lead": 7,        # 7+ years
                "executive": 10   # 10+ years
            }
            
            required_years = seniority_requirements.get(search_intent.seniority_level.lower(), 0)
            if actual_years < required_years:
                logger.debug(f"❌ Seniority requirement not met: {actual_years} < {required_years} years for {search_intent.seniority_level}")
                return False
            logger.debug(f"✅ Seniority requirement met: {actual_years} >= {required_years} years for {search_intent.seniority_level}")
        
        return True
    
    def _check_role_requirement(self, result: SearchResult, search_intent: SearchIntent) -> bool:
        """Check if role/title requirement is satisfied."""
        # When embeddings/LLM are unavailable, the pipeline may still infer roles from skills;
        # accept lower experience_match_score to avoid over-filtering.
        min_experience_for_role = 0.4 if not self.embeddings else 0.5
        if result.experience_match_score < min_experience_for_role:
            return False
        
        # Check if any role titles are mentioned in matched experience or current position
        resume_data = getattr(result, '_resume_data', {})
        current_position = str(resume_data.get('current_position', '')).lower()
        
        # Check current position for role match
        for role in search_intent.role_titles:
            role_lower = role.lower()
            if role_lower in current_position:
                return True
            
            # Extract core role from compound roles (e.g., "RPA Developer" -> "developer")
            role_parts = role_lower.split()
            core_role = role_parts[-1] if role_parts else role_lower  # Last word is usually the core role
            
            # Check for related roles in different contexts
            # RPA/automation context
            if core_role == 'developer' and any(term in current_position for term in ['analyst', 'automation', 'rpa']):
                return True
            if core_role == 'analyst' and any(term in current_position for term in ['developer', 'automation', 'rpa']):
                return True
            if core_role == 'engineer' and any(term in current_position for term in ['analyst', 'developer', 'automation', 'rpa']):
                return True
            
            # UI/UX context - these roles are highly related
            if core_role == 'developer' and any(term in current_position for term in ['designer', 'ui', 'ux', 'frontend', 'product designer']):
                return True
            if core_role == 'designer' and any(term in current_position for term in ['developer', 'ui', 'ux', 'frontend']):
                return True
            if 'ui' in role_lower and any(term in current_position for term in ['designer', 'ux', 'product designer', 'visual designer']):
                return True
            if 'ux' in role_lower and any(term in current_position for term in ['designer', 'ui', 'product designer', 'visual designer']):
                return True
            
            # Check if any part of the role matches (for compound roles like "RPA Developer")
            for part in role_parts:
                if part in current_position:
                    return True
        
        # Check if any role titles are mentioned in matched experience
        if result.matched_experience:
            role_mentioned = any(
                any(role.lower() in exp.lower() for role in search_intent.role_titles)
                for exp in result.matched_experience
            )
            if role_mentioned:
                return True
        
        return False
    
    def _check_industry_requirement(self, result: SearchResult, search_intent: SearchIntent) -> bool:
        """Check if industry requirement is satisfied."""
        # This would need industry information from resume analysis
        # For now, use semantic similarity as proxy
        return result.semantic_similarity > 0.6
    
    def _check_education_requirement(self, result: SearchResult, search_intent: SearchIntent) -> bool:
        """Check if education requirement is satisfied."""
        # This would need education information from resume analysis
        # For now, accept if other requirements are strong
        return result.skill_match_score > 0.5 or result.experience_match_score > 0.5
    
    async def _should_skip_resume(self, resume: Dict[str, Any], search_intent: SearchIntent) -> bool:
        """
        Quick early filtering to skip obviously irrelevant resumes before expensive LLM scoring.
        This reduces unnecessary LLM calls and improves performance.
        """
        try:
            # Be very permissive - only skip if absolutely no match
            # If no specific skills or roles are being searched, don't skip
            if not search_intent.key_skills and not search_intent.role_titles:
                return False
            
            # Quick skill check using existing skill data
            if search_intent.key_skills:
                resume_skills = self._extract_resume_skills_quick(resume)
                if resume_skills:
                    # Check for any skill overlap
                    search_skills_lower = [skill.lower() for skill in search_intent.key_skills]
                    resume_skills_lower = [skill.lower() for skill in resume_skills]
                    
                    # If there's any skill overlap, don't skip
                    for search_skill in search_skills_lower:
                        for resume_skill in resume_skills_lower:
                            if (search_skill in resume_skill or 
                                resume_skill in search_skill or
                                await self._skills_are_similar(search_skill, resume_skill)):
                                return False
            
            # Quick role check using current position
            if search_intent.role_titles:
                current_position = str(resume.get('current_position', '')).lower()
                if current_position:
                    for role in search_intent.role_titles:
                        role_lower = role.lower()
                        # Check direct match or related roles
                        if (role_lower in current_position or
                            any(part in current_position for part in role_lower.split())):
                            return False
                        
                        # Enhanced role matching for design-related positions
                        if 'designer' in role_lower:
                            # Match any design-related role
                            if any(term in current_position for term in ['designer', 'design', 'ui', 'ux', 'product', 'visual', 'graphic', 'web']):
                                return False
                        
                        # Enhanced role matching for developer positions
                        if 'developer' in role_lower:
                            if any(term in current_position for term in ['developer', 'engineer', 'programmer', 'coder', 'ui', 'ux', 'frontend', 'backend', 'full-stack']):
                                return False
                        
                        # Enhanced role matching for product positions
                        if 'product' in role_lower:
                            if any(term in current_position for term in ['product', 'designer', 'manager', 'owner', 'lead', 'director']):
                                return False
                        
                        # Enhanced role matching for lead positions
                        if 'lead' in role_lower:
                            if any(term in current_position for term in ['lead', 'senior', 'principal', 'head', 'director', 'manager']):
                                return False
                        
                        # Check for general related roles
                        if any(term in current_position for term in ['analyst', 'developer', 'engineer', 'automation', 'rpa', 'designer', 'manager', 'lead', 'senior']):
                            return False
            
            # If we get here, the resume doesn't match key skills or roles
            return True
            
        except Exception as e:
            # If there's an error in early filtering, don't skip (be safe)
            logger.warning(f"Early filtering error for resume {resume.get('id', 'unknown')}: {e}")
            return False
    
    def _extract_resume_skills_quick(self, resume: Dict[str, Any]) -> List[str]:
        """Quick skill extraction for early filtering (no LLM calls)."""
        skills = []
        
        # Extract from technical_skills field
        tech_skills = resume.get('technical_skills', [])
        if isinstance(tech_skills, list):
            for skill in tech_skills:
                if isinstance(skill, str):
                    skills.append(skill)
                elif isinstance(skill, dict):
                    skill_name = skill.get('skill', skill.get('name', ''))
                    if skill_name:
                        skills.append(str(skill_name))
        
        # Extract from AI analysis if available
        ai_analysis = resume.get('ai_analysis', {})
        if ai_analysis and 'skills_analysis' in ai_analysis:
            skills_analysis = ai_analysis['skills_analysis']
            ai_tech_skills = skills_analysis.get('technical_skills', [])
            
            if isinstance(ai_tech_skills, list):
                for skill in ai_tech_skills:
                    if isinstance(skill, dict):
                        skill_name = skill.get('skill', skill.get('name', ''))
                        if skill_name:
                            skills.append(str(skill_name))
                    elif isinstance(skill, str):
                        skills.append(skill)
        
        return skills
